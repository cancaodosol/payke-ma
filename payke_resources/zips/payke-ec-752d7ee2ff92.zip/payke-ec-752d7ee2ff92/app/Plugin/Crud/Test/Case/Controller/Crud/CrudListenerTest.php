<?php

/**
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 */
class CrudListenerTest extends CakeTestCase {

/**
 * Not much going on here at the moment
 * Everything is tested through the other classes
 * depending on this one
 */
	public function testNothing() {
		$this->assertTrue(true);
	}

}

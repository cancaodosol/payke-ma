<?php
App::uses('ApiAppController', 'Api.Controller');

/**
 * AffiliateResults Controller
 *
 * @property AffiliateResult $AffiliateResult
 */
class AffiliateResultsController extends ApiAppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'AffiliateResult', // デフォルトの Api.AffiliateResult ではなく App の AffiliateResult を使う
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'contain' => [
			'Affiliate' => [
				'fields' => [],
				'Profile' => ['fields' => ['full_name']],
			],
			'AffiliatePayout' => [
				'fields' => ['payment_status'],
			],
			'Order' => [
				'fields' => ['product_id', 'name'],
			],
		],
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://crud.readthedocs.io/en/cake3/configuration.html#disabling-loaded-actions
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Crud->disable(['view', 'add', 'edit', 'delete']); // 無効化する Crud アクションを指定
	}

/**
 * index method
 *
 * @return CakeResponse
 * @link https://crud.readthedocs.io/en/cake3/actions/index.html
 */
	public function index() {
		$this->Crud->on('afterPaginate', function(CakeEvent $event) {
			// 取得結果を整形
			$this->_formatAffiliateResults($event->subject->items);
		});

		return $this->Crud->execute();
	}
}

<?php

App::uses('Controller', 'Controller');
App::uses('CrudControllerTrait', 'Crud.Lib');

/**
 * Api Application Controller
 *
 * 画面向け処理を多く含む AppController を継承せずに、 Controller を継承した。
 *
 * @property Crud.Crud $Crud
 * @property RequestHandlerComponent $RequestHandler
 */
class ApiAppController extends Controller {

	use CrudControllerTrait;

/**
 * コントローラで使うコンポーネントをセットする。
 * ここで与えられたクラスはコントローラの中でクラス変数として有効になる (例えば $this->Crud) 。
 * 継承された値とマージされる。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$components
 * @link https://book.cakephp.org/2/ja/controllers/components.html#configuring-components
 */
	public $components = [
		'Crud.Crud' => [
			'actions' => [
				'index' => 'Crud.Index',
				'view' => [
					'className' => 'Api.CustomView', // Crud/Action/CustomViewCrudAction
				],
				'add' => 'Crud.Add',
				'edit' => 'Crud.Edit',
				'delete' => 'Crud.Delete', // TODO: 削除失敗時の動作に不具合がありそうなのでカスタマイズが必要かも
			],
			'listeners' => [
				'Api' => [
					'className' => 'Api.CustomApi', // Crud/Listener/CustomApiListener
				],
				'ApiPagination', // => 'Crud.ApiPagination',
				'ApiQueryLog', // => 'Crud.ApiQueryLog',
				'ApiTransformation' => [
					'className' => 'Api.CustomApiTransformation', // Crud/Listener/CustomApiTransformationListener
					'castNumbers' => false,
					'valueMethods' => [
						'_castNumbersIfNeeded',
					],
				],
				'DebugKit', // => 'Crud.DebugKit',
				'Search', // => 'Crud.Search',
			],
		],
		'DebugKit.Toolbar' => [
			// 'panels' => ['Crud.Crud'], // NOTE: 例外が発生してうまく動作しない
		],
		'RequestHandler',
		'ResourceServer',
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'paramType' => 'querystring',
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		if (!$this->request->is('api')) {
			throw new NotFoundException();
		}

		// TODO: 認証・認可について要検討
		// 認証不要のアクション名を指定
		// $this->Auth->allow(['index', 'add', 'edit', 'view', 'delete']);
		// 使わないコンポーネントをアンロード
		$this->Components->unload('Auth');
		$this->Components->unload('Flash');
		$this->Components->unload('Security');
		$this->Components->unload('Session');

		parent::beforeFilter();
	}

/**
 * リクエストデータに含まれる指定の値がタイムスタンプであれば日時文字列へ変換する。
 *
 * @param array $fields 対象フィールド名の配列
 * @return void
 * @link https://book.cakephp.org/2/ja/core-utility-libraries/hash.html
 */
	protected function _ts2dtsIfNeeded(array $fields) {
		$data = Hash::flatten($this->request->data);
		foreach ($data as $path => $value) {
			$keys = explode('.', $path);
			$last = end($keys);
			if (in_array($last, $fields)) { // 対象フィールドの場合
				if (is_numeric($value)) {
					$value = to_datetime_string($value);
					$this->request->data($path, $value);
				}
			}
		}
	}

/**
 * AffiliateResult を扱い易いように整形する。
 *
 * @param array &$results AffiliateResult の配列
 * @return void
 */
	protected function _formatAffiliateResults(array &$results) {
		foreach ($results as &$result) {
			$result['Affiliate']['name'] = $result['Affiliate']['Profile']['full_name'];
			unset($result['Affiliate']['Profile']);
		}
	}
}

<?php

App::uses('ApiListener', 'Crud.Controller/Crud/Listener');

/**
 * カスタム ApiListener 。
 *
 * Crud.CrudValidationException のステータスコードをカスタマイズ（412 -> 422）するため。
 */
class CustomApiListener extends ApiListener {

/**
 * Throw an exception based on API configuration
 *
 * @throws CakeException
 * @param array $exceptionConfig
 * @return void
 */
	protected function _exceptionResponse($exceptionConfig) {
		$exceptionConfig = array_merge($this->config('exception'), $exceptionConfig);

		$class = $exceptionConfig['class'];

		if ($exceptionConfig['type'] === 'validate') {
			$errors = $this->_validationErrors();
			throw new $class($errors, 422);
		}

		throw new $class($exceptionConfig['message'], $exceptionConfig['code']);
	}
}

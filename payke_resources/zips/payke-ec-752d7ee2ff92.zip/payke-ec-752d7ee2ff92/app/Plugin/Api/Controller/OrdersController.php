<?php
App::uses('ApiAppController', 'Api.Controller');

/**
 * Orders Controller
 *
 * @property Order $Order
 */
class OrdersController extends ApiAppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'Order', // デフォルトの Api.Order ではなく App の Order を使う
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'contain' => [
			'AffiliateResult' => [
				'Affiliate' => [
					'fields' => [],
					'Profile' => ['fields' => ['full_name']],
				],
			],
			'Payment',
			'PaymentPlan' => [
				'PaymentMethod',
			],
		],
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://crud.readthedocs.io/en/cake3/configuration.html#disabling-loaded-actions
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Crud->disable(['add', 'edit', 'delete']); // 無効化する Crud アクションを指定
	}

/**
 * index method
 *
 * @return CakeResponse
 * @link https://crud.readthedocs.io/en/cake3/actions/index.html
 * @link https://crud.readthedocs.io/en/cake3/events.html?highlight=beforefind#crud-beforepaginate
 * @link https://crud.readthedocs.io/en/cake3/events.html?highlight=after#crud-afterpaginate
 */
	public function index() {
		$this->Crud->on('beforePaginate', function(CakeEvent $event) {
			// バーチャルフィールドを設定
			$Order = $event->subject->model;
			$Order->addVirtualFields(['amount_received']);
		});

		$this->Crud->on('afterPaginate', function(CakeEvent $event) {
			// 取得結果を整形
			foreach ($event->subject->items as &$item) {
				$this->_formatAffiliateResults($item['AffiliateResult']);
			}
		});

		return $this->Crud->execute();
	}

/**
 * view method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/view.html
 * @link https://crud.readthedocs.io/en/cake3/events.html?highlight=beforefind#action
 */
	public function view($id = null) {
		$this->Crud->on('beforeFind', function(CakeEvent $event) {
			$event->subject->query['contain'] = [
				'AffiliateResult' => [
					'Affiliate' => [
						'fields' => [],
						'Profile' => ['fields' => ['full_name']],
					],
					'AffiliatePayout' => [
						'fields' => ['payment_status'],
					],
				],
				'PaymentPlan' => [
					'PaymentMethod',
				],
				'Payment' => [
					'PaymentMethod',
				],
				'Product',
				'ProductOption',
				'CustomFieldValue',
			];
		});

		$this->Crud->on('afterFind', function(CakeEvent $event) {
			// 取得結果を整形
			$item = $event->subject->item;
			$this->_formatAffiliateResults($item['AffiliateResult']);
			$event->subject->item = $item;
		});

		return $this->Crud->execute();
	}

/**
 * キャンセル。
 *
 * @param string $id 注文ID
 * @return void
 * @throws MethodNotAllowedException
 * @throws NotFoundException
 */
	public function cancel($id) {
		// Crud.Edit アクションをベースにカスタマイズ
		$this->Crud->mapAction($action = 'cancel', $settings = [
			'className' => 'Crud.Edit', // Crud.EditCrudAction を使う
			'saveMethod' => 'cancel', // デフォルトの saveAssociated() の替わりに cancel() を使う
		]);

		return $this->Crud->execute();
	}
}

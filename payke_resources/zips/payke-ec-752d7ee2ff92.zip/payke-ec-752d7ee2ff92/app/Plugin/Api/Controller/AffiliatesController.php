<?php
App::uses('ApiAppController', 'Api.Controller');
App::uses('User', 'Model');

/**
 * Affiliates Controller
 *
 * @property User $User
 */
class AffiliatesController extends ApiAppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'User', // デフォルトの Api.Affiliate ではなく App の User を使う
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://crud.readthedocs.io/en/cake3/configuration.html#disabling-loaded-actions
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Crud->disable(['index']); // 無効化する Crud アクションを指定
	}

/**
 * view method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/view.html
 * @link https://crud.readthedocs.io/en/cake3/events.html?highlight=beforefind#action
 */
	public function view($id = null) {
		$this->Crud->on('beforeFind', function(CakeEvent $event) {
			$userFields = $this->User->fields();
			$profileFields = $this->User->Profile->fields();
			$event->subject->query['fields'] = am($userFields, $profileFields);
			$event->subject->query['conditions'] += User::ROLE_IS_AFFILIATE;
			$event->subject->query['contain'] = [
				'Profile',
			];
		});

		return $this->Crud->execute();
	}

/**
 * add method
 *
 * @return CakeResponse
 * @link https://crud.readthedocs.io/en/cake3/actions/add.html
 * @see User::registerAffiliate()
 */
	public function add() {
		$this->Crud->on('beforeSave', function(CakeEvent $event) {
			$request = $event->subject->request;

			// パスワードをパスワード（確認用）へコピー
			// アフィリエイト会員登録完了メール送信処理でパスワード平文が必要なため
			$password = $request->data('User.password');
			$request->data('User.temppassword', $password);

			// デフォルトの商品グループ（id=1）との紐付け
			$request->data('ProductGroup.ProductGroup.0', 1);
		});

		// デフォルトの saveAssociated() ではなく registerAffiliate() を使わせる
		$this->Crud->action()->saveMethod('registerAffiliate');

		return $this->Crud->execute();
	}

/**
 * edit method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/edit.html
 */
	public function edit($id = null) {
		$this->Crud->on('beforeFind', function(CakeEvent $event) {
			$event->subject->query['conditions'] += User::ROLE_IS_AFFILIATE;
		});

		// 追加の保存オプションをマージ
		$this->Crud->action()->saveOptions([
			'fieldList' => [ // 保存対象フィールド（ホワイトリスト）
				'User' => [
					'password',
					'email',
				],
				'Profile' => [
					'full_name',
					'address',
					'phone',
					'bank_name',
					'bank_branch_name',
					'bank_account_type',
					'bank_account_number',
					'bank_account_name_kana',
				],
			],
		]);

		return $this->Crud->execute();
	}

/**
 * delete method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/delete.html
 */
	public function delete($id = null) {
		$this->Crud->on('beforeFind', function(CakeEvent $event) {
			$event->subject->query['conditions'] += User::ROLE_IS_AFFILIATE;
		});

		return $this->Crud->execute();
	}
}

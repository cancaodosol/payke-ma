<?php
App::uses('ApiAppController', 'Api.Controller');

/**
 * Products Controller
 *
 * @property Product $Product
 */
class ProductsController extends ApiAppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'Product', // デフォルトの Api.Product ではなく App の Product を使う
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://crud.readthedocs.io/en/cake3/configuration.html#disabling-loaded-actions
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Crud->disable(['index']); // 無効化する Crud アクションを指定
	}

/**
 * 前処理。
 *
 * @return void
 */
	protected function _preprocess() {
		// リクエストデータに含まれる指定データがタイムスタンプであれば日時文字列へ変換
		$this->_ts2dtsIfNeeded([
			'sales_start_date',
			'sales_end_date',
			'cancelation_deadline',
			'order_deadline',
			'affiliate_start_date',
			'trial_end',
		]);
	}

/**
 * view method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/view.html
 * @link https://crud.readthedocs.io/en/cake3/events.html?highlight=beforefind#action
 * @see Product::_findForEdit()
 */
	public function view($id = null) {
		$this->Crud->on('beforeFind', function(CakeEvent $event) {
			$event->subject->query['contain'] = [
				'ProductOption',
				'CustomField',
				'StripePaymentPlan',
				'PayPalPaymentPlan',
				'AmazonPayPaymentPlan',
				'PaidyPaymentPlan',
				'BankTransferPaymentPlan',
				'PaymentCompletedMail',
				'InstallmentPaymentCompletedMail',
				'BankTransferPaymentMail',
				'BankTransferRequestMail',
				'BookedMail',
			];
		});

		return $this->Crud->execute();
	}

/**
 * add method
 *
 * @return CakeResponse
 * @link https://crud.readthedocs.io/en/cake3/actions/add.html
 */
	public function add() {
		$this->_preprocess();

		// 必要な値が指定されていない場合は補完
		if (empty($this->request->data('Product.scta_notation_id'))) { // 特定商取引法に基づく表記
			$this->request->data('Product.scta_notation_id', 1); // デフォルト値 (id=1)
		}

		return $this->Crud->execute();
	}

/**
 * edit method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/edit.html
 */
	public function edit($id = null) {
		$this->_preprocess();

		return $this->Crud->execute();
	}

/**
 * delete method
 *
 * @param string $id
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/delete.html
 */
	public function delete($id = null) {
		$this->Crud->on('beforeDelete', function(CakeEvent $event) {
			$Product = $event->subject->model;
			$Product->id = $event->subject->id;
			$count = $Product->countOrders();
			if (0 < $count) { // 注文がある場合
				// TODO: 要調査: イベントを止める方法だと何故か以下の Notice が出てしまう。
				// Notice (8): Undefined property: CrudSubject::$success [APP/Plugin/Crud/Controller/Crud/Listener/ApiListener.php, line 143
				// $event->stopPropagation(); // イベントを止めることで削除を止める
				// 替わりに例外を投げる
				throw new BadRequestException(__('The product could not be deleted because it has some orders.'));
			}
		});

		return $this->Crud->execute();
	}
}

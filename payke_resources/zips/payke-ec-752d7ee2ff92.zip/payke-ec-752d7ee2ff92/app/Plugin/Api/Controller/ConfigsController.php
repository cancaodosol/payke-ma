<?php
App::uses('ApiAppController', 'Api.Controller');

/**
 * Configs Controller
 *
 * @property Config $Config
 */
class ConfigsController extends ApiAppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'Config', // デフォルトの Api.Config ではなく App の Config を使う
	];

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://crud.readthedocs.io/en/cake3/configuration.html#disabling-loaded-actions
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Crud->disable(['index', 'view', 'add', 'delete']); // 無効化する Crud アクションを指定
	}

/**
 * edit method
 *
 * @param string $name
 * @return CakeResponse
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/actions/edit.html
 */
	public function edit($name) {
		$id = $this->Config->primaryKeyValue(compact('name')); // 引数をもとにIDを取得

		// 追加の保存オプションをマージ
		$this->Crud->action()->saveOptions([
			'fieldList' => [ // 保存対象フィールド（ホワイトリスト）
				'Config' => [
					'affiliate_emails_disabled',
				],
			],
		]);

		return $this->Crud->execute(null, [$id]);
	}
}

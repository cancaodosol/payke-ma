<?php

App::uses('ViewCrudAction', 'Crud.Controller/Crud/Action');

/**
 * カスタム ViewCrudAction 。
 *
 * Crud.ViewCrudAction では何故か api.* のデフォルト値が設定されておらず Notice が出る。
 * Notice (8): Trying to access array offset on value of type null
 *  [APP/Plugin/Crud/Controller/Crud/Listener/ApiListener.php, line 151]
 * 回避策として $_settings を修正する。
 */
class CustomViewCrudAction extends ViewCrudAction {

/**
 * 'view'アクションのためのデフォルト設定。
 *
 * @var array
 */
	protected $_settings = array(
		'enabled' => true,
		'findMethod' => 'first',
		'view' => null,
		'viewVar' => null,
		'api' => [
			'success' => [
				'code' => 200,
			],
		],
		'serialize' => array(),
	);
}

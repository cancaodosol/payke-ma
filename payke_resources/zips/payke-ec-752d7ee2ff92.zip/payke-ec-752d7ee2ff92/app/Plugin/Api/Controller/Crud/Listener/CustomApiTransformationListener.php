<?php

App::uses('ApiTransformationListener', 'Crud.Controller/Crud/Listener');

/**
 * カスタム ApiTransformationListener 。
 *
 * Crud.ApiTransformationListener クラスの _castNumbers() の挙動を制御したいため。
 */
class CustomApiTransformationListener extends ApiTransformationListener {

/**
 * 数値変換の対象外とするフィールドの一覧。必要に応じてここに追記していく。
 *
 * @var array
 * @see self::_castNumbersIfNeeded()
 */
	const CAST_NUMBER_EXCLUDES = [
		'phone', // 電話番号
		'bank_account_number', // 銀行口座番号
	];

/**
 * 必要な場合だけ _castNumbers() により変換する。
 *
 * @param mixed $variable
 * @param string $key
 * @return mixed
 * @see self::_castNumbers()
 */
	protected function _castNumbersIfNeeded($variable, $key) {
		$keys = explode('.', $key);
		$last = end($keys);
		if (in_array($last, self::CAST_NUMBER_EXCLUDES)) { // 除外フィールドの場合
			return $variable; // そのまま返す
		}

		return self::_castNumbers($variable);
	}
}

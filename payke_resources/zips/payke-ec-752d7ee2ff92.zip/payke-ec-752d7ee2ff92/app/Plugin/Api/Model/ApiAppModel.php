<?php

App::uses('AppModel', 'Model');

class ApiAppModel extends AppModel {

}

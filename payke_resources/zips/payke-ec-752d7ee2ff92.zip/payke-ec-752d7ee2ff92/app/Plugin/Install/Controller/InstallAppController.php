<?php

App::uses('AppController', 'Controller');

class InstallAppController extends AppController
{
    /**
     * {@inheritdoc}
     */
    public $components = array(
        'Security',
    );

    /**
     * {@inheritdoc}
     */
    public $helpers = array(
        'Form',
    );

/**
 * Called before the controller action. You can use this method to configure and customize components
 * or perform logic that needs to happen before each controller action.
 *
 * @return void
 * @link https://book.cakephp.org/2.0/en/controllers.html#request-life-cycle-callbacks
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// https://book.cakephp.org/2/en/core-libraries/components/security-component.html
		$this->Security->csrfCheck = false;
		$this->Security->validatePost = false;
	}

/**
* Called after the controller action is run, but before the view is rendered. You can use this method
* to perform logic or set view variables that are required on every request.
*
* @return void
* @link https://book.cakephp.org/2.0/en/controllers.html#request-life-cycle-callbacks
*/
	public function beforeRender() {
		parent::beforeRender();

		$this->helpers['Form'] = ['className' => 'Install.BootstrapForm'];
	}

}

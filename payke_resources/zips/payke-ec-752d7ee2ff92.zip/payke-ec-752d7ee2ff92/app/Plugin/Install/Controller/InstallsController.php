<?php

App::uses('InstallAppController', 'Install.Controller');

class InstallsController extends InstallAppController
{
    /**
     * {@inheritdoc}
     */
    public function beforeFilter()
    {
        parent::beforeFilter();

        $this->Auth->allow();
    }

    /**
     * {@inheritdoc}
     */
    public function beforeRender()
    {
        parent::beforeRender();

        $this->layout = 'install';
    }

    /**
     * Check environment.
     */
    public function index()
    {
    }

    /**
     * Configure database connection.
     */
    public function connect()
    {
        // loads the default configuration
        include_once CONFIG.'database.php';
        $config = (new DATABASE_CONFIG())->default;

        if ($this->request->is('post')) {
            $this->Install->set($this->request->data);
            if (!$this->Install->validates()) {
                $this->Flash->error(__d('install', 'The database configuration could not be saved. Please, try again.'));

                return false;
            }

            // loads form data
            $config = array_merge($config, $this->request->data['Install']);
            // $this->log('config: '.Debugger::exportVar($config), 'debug');

            // Try to connect the database with the new configuration
            App::uses('ConnectionManager', 'Model');
            try {
                $db = ConnectionManager::create('default', $config);
            } catch (MissingConnectionException $e) {
                $this->Flash->error(__d('install', 'Cannot connect to the database')." {$e->getAttributes()['message']}");

                return false;
            }
            // $this->Flash->success(__d('install', 'Connected to the database'));

            if (!$this->Install->saveToEnvironment($config)) {
                $this->Flash->error(__d('install', '%s file cannot be modified', 'app/Config/.env.php'));

                return false;
            }
            $this->Flash->success(__d('install', 'Saved the database configuration to the %s file', 'app/Config/.env.php'));

            return $this->redirect(array('action' => 'key'));
        } else {
            unset($config['password']);
            $this->request->data['Install'] = $config;
        }
    }

    /**
     * Configure security keys.
     */
    public function key()
    {
        if ($this->request->is('post')) {
            if (!class_exists('Security')) {
                require CAKE_CORE_INCLUDE_PATH.DS.'Cake'.DS.'Utility'.DS.'security.php';
            }

            $config = array();

            if ($this->request->data['Install']['salt']) {
                // NOTE: Security.saltを変更した場合、セッションがクリアされるので注意。
                $config['salt'] = Security::hash(CakeText::uuid());
            }

            if ($this->request->data['Install']['seed']) {
                $config['seed'] = mt_rand().mt_rand().mt_rand();
            }

            if (!empty($config)) {
                if (!$this->Install->saveToEnvironment($config, $backup = true)) {
                    $this->Flash->error(__d('install', 'Error when regenerating new keys'));

                    return false;
                }
            }

            // NOTE: Security.saltを変更した場合、セッションが切れるため、フラッシュメッセージが表示されない。
            // $this->Flash->success(__d('install', 'Your database has been correctly installed, you can now configure your website'));

            return $this->redirect(array('action' => 'migrate'));
        }
    }

    /**
     * Migrate database.
     */
    public function migrate()
    {
        if ($this->request->is('post')) {
            // Connect to the database
            App::uses('ConnectionManager', 'Model');
            $db = ConnectionManager::getDataSource('default');
            if (!$db->isConnected()) {
                $this->Flash->error(__d('install', 'Cannot connect to the database'));

                return false;
            }

            // run all migrations
            if (!$this->Install->runAllMigrations()) {
                $this->Flash->error(__d('install', 'Cannot migrate'));

                return false;
            }

            $this->Flash->success(__d('install', 'Your database has been correctly installed.'));

            return $this->redirect(array('action' => 'finish'));
        }
    }

    /**
     * Finish installation.
     */
    public function finish()
    {
        if ($this->request->is('post')) {
            if (!$this->Install->changeConfiguration('installed', true)) {
                $this->Flash->error(__d('install', 'Cannot modify the value of %s in the app/Config/install.php file', 'installed'));

                return false;
            }

            return $this->redirect(Configure::read('Install.redirect.url'));
        }
    }
}

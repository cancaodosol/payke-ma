<?php

class Install extends InstallAppModel
{
    /**
     * {@inheritdoc}
     */
    public $useTable = false;

    /**
     * {@inheritdoc}
     */
    public $validate = array(
        'host' => array(
            'notBlank' => array(
                'rule' => array('notBlank'),
            ),
        ),
        'login' => array(
            'notBlank' => array(
                'rule' => array('notBlank'),
            ),
        ),
        'database' => array(
            'notBlank' => array(
                'rule' => array('notBlank'),
            ),
        ),
    );

    // Configuration key to Environment variable name
    protected $conf2env = array(
        // Database
        'host' => 'DB_HOST',
        'login' => 'DB_USERNAME',
        'password' => 'DB_PASSWORD',
        'database' => 'DB_DATABASE',
        'prefix' => 'DB_PREFIX',
        // Security
        'salt' => 'SECURITY_SALT',
        'seed' => 'SECURITY_CIPHER_SEED',
    );

    /**
     * Change configuration in app/Plugin/Install/Config/bootstrap.php.
     *
     * @param	string	the key to change
     * @param	string	the new value
     *
     * @return bool
     */
    public function changeConfiguration($key, $value)
    {
        // https://book.cakephp.org/2.0/en/development/configuration.html#Configure::write
        if (!Configure::write("Install.{$key}", $value)) {
            $this->log('Configure write failed');

            return false;
        }

        // https://book.cakephp.org/2.0/en/development/configuration.html#id10
        if (!Configure::dump('install.php', 'default', array('Install'))) {
            $this->log('Configure dump failed');

            return false;
        }

        return true;
    }

    /**
     * Change environment variable in app/Config/.env.php.
     *
     * @param array $config
     * @param bool  $backup
     *
     * @return bool
     */
    public function saveToEnvironment(array $config, $backup = false)
    {
        $path = CONFIG.'.env.php';

        foreach ($config as $k => $v) {
            if (isset($this->conf2env[$k])) {
                $name = $this->conf2env[$k];
                $environment[$name] = $v;
            }
        }

        App::uses('File', 'Utility');
        $file = new File($path);
        $contents = $file->read();
        $contents = preg_replace_callback(
            '/[\'\"]([^\'\"]*)[\'\"]\s*=>\s*[\'\"]?([^\'\"]*)[\'\"]?\s*,/',
            function (array $matches) use ($environment) {
                $name = $matches[1];
                if (isset($environment[$name])) {
                    $value = $environment[$name];

                    return var_export($name, true).' => '.var_export($value, true).',';
                }

                return $matches[0];
            },
            $contents
        );

        if ($backup) {
            $file->copy($path.'.'.date('Y-m-d\TH:i:s').'.'.'bak');
        }

        $success = $file->write($contents);
        $file->close();

        return $success;
    }

    public function runAllMigrations()
    {
        $command = '-app '.APP.' Migrations.migration run all --precheck Migrations.PrecheckCondition';

        App::uses('ShellDispatcher', 'Console');
        App::uses('Shell', 'Console');
        $result = Shell::dispatchShell($command); // https://book.cakephp.org/2.0/en/console-and-shells.html#invoking-other-shells-from-your-shell

        return $result;
    }
}

Inspired by [prbaron/CakePHP-Install](https://github.com/prbaron/CakePHP-Install)

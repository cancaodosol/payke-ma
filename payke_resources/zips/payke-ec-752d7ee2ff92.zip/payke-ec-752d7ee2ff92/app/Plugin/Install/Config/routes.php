<?php
Router::connect('/install', array('plugin' => 'install', 'controller' => 'installs'));

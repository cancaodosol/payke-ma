<?php
Router::connect('/users/users', ['plugin' => 'users', 'controller' => 'users_users']);
Router::connect('/users/users/:action/*', ['plugin' => 'users', 'controller' => 'users_users']);
Router::connect('/users', ['plugin' => 'users', 'controller' => 'users_users']);
Router::connect('/users/:action/*', ['plugin' => 'users', 'controller' => 'users_users']);
Router::connect("/admin/users/users", ['plugin' => 'users', 'controller' => 'users_users', 'prefix' => 'admin', 'admin' => true]);
Router::connect("/admin/users/users/:action/*", ['plugin' => 'users', 'controller' => 'users_users', 'prefix' => 'admin', 'admin' => true]);
Router::connect("/admin/users", ['plugin' => 'users', 'controller' => 'users_users', 'prefix' => 'admin', 'admin' => true]);
Router::connect("/admin/users/:action/*", ['plugin' => 'users', 'controller' => 'users_users', 'prefix' => 'admin', 'admin' => true]);
Router::connect('/login', ['plugin' => 'users', 'controller' => 'users_users', 'action' => 'login']);
Router::connect('/logout', ['plugin' => 'users', 'controller' => 'users_users', 'action' => 'logout']);
Router::connect('/register', ['plugin' => 'users', 'controller' => 'users_users', 'action' => 'add']);

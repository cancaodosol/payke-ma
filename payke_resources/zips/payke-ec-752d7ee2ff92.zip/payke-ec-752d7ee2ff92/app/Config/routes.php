<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different URLs to chosen controllers and their actions (functions).
 *
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.2.9
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 * its action called 'display', and we pass a param to select the view file
 * to use (in this case, /app/View/Pages/home.ctp)...
 */
	// Router::connect('/', array('controller' => 'pages', 'action' => 'display', 'home'));
/**
 * ...and connect the rest of 'Pages' controller's URLs.
 */
	// Router::connect('/pages/*', array('controller' => 'pages', 'action' => 'display'));

	Router::connect('/p/:slug', array(
		'controller' => 'orders',
		'action' => 'add'
	), array(
		'pass' => array('slug'),
	));

	Router::connect('/oe/:uuid', array(
		'controller' => 'orders',
		'action' => 'edit'
	), array(
		'pass' => array('uuid'),
	));

	Router::connect('/oc/:uuid', array(
		'controller' => 'orders',
		'action' => 'confirm'
	), array(
		'pass' => array('uuid'),
	));

	Router::connect('/ov/:uuid', array(
		'controller' => 'orders',
		'action' => 'set_reference'
	), array(
		'pass' => array('uuid'),
	));

	Router::connect('/qae/:uuid', array(
		'controller' => 'questionnaire_answers',
		'action' => 'edit',
	), array(
		'pass' => array('uuid'),
	));

	Router::connect('/af/:productId/**', array(
		'controller' => 'af',
	), array(
		'pass' => array('productId', 'aid'),
		'productId' => '[\d]+',
		'aid' => '[\w]+',
	));

	// Usersプラグインのコントローラからのリダイレクト先をカスタマイズ
	Router::connect('/users/login', ['controller' => 'pages', 'action' => 'display', 'home']);

	// Usersプラグインではなくアプリのコントローラへルーティング
	// https://github.com/CakeDC/users/blob/2.x/Docs/Documentation/Extending-the-Plugin.md#routing-to-preserve-the-users-url-when-extending-the-plugin
	// https://book.cakephp.org/2/ja/development/routing.html#prefix-routing
	foreach (Configure::read('Routing.prefixes') as $prefix) {
		Router::connect("/{$prefix}/users", [
			'plugin' => null,
			'controller' => 'users',
			'prefix' => $prefix,
			$prefix => true,
		]);
		Router::connect("/{$prefix}/users/:action/*", [
			'plugin' => null,
			'controller' => 'users',
			'prefix' => $prefix,
			$prefix => true,
		]);
	}
	Router::connect('/users/:action/*', [
		'plugin' => null,
		'controller' => 'users',
	]);

	// ApiプラグインのルーティングをRESTfulにする @see Crud.ApiListener::mapResources()
	App::uses('ApiListener', 'Crud.Controller/Crud/Listener');
	ApiListener::mapResources('Api');

	// [ルーティング / 拡張子](https://book.cakephp.org/2/ja/development/routing.html#file-extensions)
	// [JSONとXMLビュー / データビューを有効にする](https://book.cakephp.org/2/ja/views/json-and-xml-views.html#id1)
	// [REST / 簡単なセットアップ](https://book.cakephp.org/2/ja/development/rest.html#id1)
	// [setExtensions()](https://book.cakephp.org/2/ja/development/routing.html#Router::setExtensions)
	Router::setExtensions('json');
	Router::parseExtensions('json');

/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();

/**
 * Load the CakePHP default routes. Only remove this if you do not want to use
 * the built-in default routes.
 */
	require CAKE . 'Config' . DS . 'routes.php';

<?php

$variableReplacer = function ($name) {
	return "{{ {$name} }}"; // Twigの変数タグ
};

$subTemplateReplacer = function ($name) {
	return "{% include '{$name}.twig' %}"; // Twigのincludeタグ
};

// 差込変数と置換のマッピング

$variables = [
	// サブテンプレート
	'af_memo' => $subTemplateReplacer,
	'items' => $subTemplateReplacer,
	'item_descriptions' => $subTemplateReplacer,
	'customer' => $subTemplateReplacer,
	'answers' => $subTemplateReplacer,
	'billing_details' => $subTemplateReplacer,
	'pay_limit' => $subTemplateReplacer,

	// 変数
	'order_no' => $variableReplacer,
	'item_list' => $variableReplacer,
	'item_name' => $variableReplacer,
	'price' => $variableReplacer,
	'payment' => $variableReplacer,
	'quantity' => $variableReplacer,
	'item_op' => $variableReplacer,
	'amount_per_cycle' => $variableReplacer,
	'initial_fee' => $variableReplacer,
	'gross' => $variableReplacer,
	'tax_amount' => $variableReplacer,
	'reference_id' => $variableReplacer,
	'order_date' => $variableReplacer,
	'paid_date' => $variableReplacer,
	'cancel_date' => $variableReplacer,
	'name' => $variableReplacer,
	'kana' => $variableReplacer,
	'email' => $variableReplacer,
	'zip' => $variableReplacer,
	'prefecture' => $variableReplacer,
	'address' => $variableReplacer,
	'phone' => $variableReplacer,
	'gender' => $variableReplacer,
	'birth_date' => $variableReplacer,
	'payer_kana' => $variableReplacer,
	'fields' => $variableReplacer,
	'arg1' => $variableReplacer,
	'arg2' => $variableReplacer,
	'arg3' => $variableReplacer,
	'arg4' => $variableReplacer,
	'arg5' => $variableReplacer,
	'send_date' => $variableReplacer,
	'payment_cycles' => $variableReplacer,
	'memo' => $variableReplacer,
	'admin_email' => $variableReplacer,
	'setup_fee' => $variableReplacer,
	'trials' => $variableReplacer,
	'regular' => $variableReplacer,
	// 非推奨（ここから）
	'regular_amount' => $variableReplacer,
	'regular_frequency' => $variableReplacer,
	'regular_cycles' => $variableReplacer,
	'trial_amount' => $variableReplacer,
	'trial_frequency' => $variableReplacer,
	'trial_cycles' => $variableReplacer,
	// 非推奨（ここまで）
	'additional' => $variableReplacer,
	'order_deadline' => $variableReplacer,
	'order_url' => $variableReplacer,
	'summary' => $variableReplacer,
	'due_date' => $variableReplacer,
	'paid_date' => $variableReplacer,
	'amount' => $variableReplacer,
	'cancel_url' => $variableReplacer,
	'form' => $variableReplacer,
	'form_name' => $variableReplacer,
	'affiliate_message' => $variableReplacer,
	'af_full_name' => $variableReplacer,
	'af_email' => $variableReplacer,
	'af_password' => $variableReplacer,
	'af_login_url' => $variableReplacer,
	'aid' => $variableReplacer,
];

// タグを置換
foreach ($variables as $name => $replacer) {
	$variables[$name] = $replacer($name);
}

<?php
// Stripe にアクセスするデータソースを動的に作成

App::uses('ClassRegistry', 'Utility');
App::uses('ConnectionManager', 'Model');

try {
	$Config = ClassRegistry::init('Config');
	// $publishableKey = $Config->get('stripe_publishable_key');
	$apiKey = $Config->get('stripe_api_key');
} catch (\Exception $e) {
	// データベース接続を未設定等の場合
}

// if (!empty($publishableKey) && !empty($apiKey)) {
if (!empty($apiKey)) {
	$config = [
		'datasource' => 'StripeSource',

		// 'publishable_key' => $publishableKey,
		'api_key' => $apiKey,
	];

	$ds = ConnectionManager::create('stripe', $config);
}

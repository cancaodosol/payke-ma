<?php

return array(
    // アプリ名
    'APP_NAME' => 'Payke EC',

    // Debugレベル
    'DEBUG' => 0,

    // セキュリティ関連のハッシュ処理で使われるランダムな文字列
    'SECURITY_SALT' => '3CMOcDnkXuAae9PiJmxrhGbUyj6dRpgNWLsvVlS1',

    // 文字列を暗号化／復号化するのに使われるランダムな文字列（数字のみ）
    'SECURITY_CIPHER_SEED' => '44854019587430567321827562136',

    // データベース接続情報
    'DB_DATASOURCE' => 'Database/Mysql',
    'DB_HOST' => 'localhost',
    'DB_PORT' => 3306,
    'DB_DATABASE' => 'database_name',
    'DB_USERNAME' => 'user',
    'DB_PASSWORD' => 'password',
    'DB_PREFIX' => '',

    'TEST_DB_DATASOURCE' => 'Database/Mysql',
    'TEST_DB_HOST' => 'localhost',
    'TEST_DB_PORT' => 3306,
    'TEST_DB_DATABASE' => 'test_database_name',
    'TEST_DB_USERNAME' => 'user',
    'TEST_DB_PASSWORD' => 'password',
    'TEST_DB_PREFIX' => '',

	// 'TUNNEL_ENDPOINT_URL' => 'https://******.ngrok.io',
);

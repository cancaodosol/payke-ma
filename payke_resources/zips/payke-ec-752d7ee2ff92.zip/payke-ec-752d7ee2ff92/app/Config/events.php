<?php
// TODO: ここで全てをアタッチせずに、必要なときだけ個別にアタッチすべきではないか

// Load event listeners
App::uses('AffiliateResultApprover', 'Lib/Event');
App::uses('AffiliateResultEmailSender', 'Lib/Event');
App::uses('AuthEmailSender', 'Lib/Event');
App::uses('CakeEventManager', 'Event');
App::uses('ClassRegistry', 'Utility');
App::uses('PaymentDeclinedEmailSender', 'Lib/Event');
App::uses('PaymentEmailSender', 'Lib/Event');
App::uses('PaymentErrorEmailSender', 'Lib/Event');
App::uses('PaymentFailedEmailSender', 'Lib/Event');
App::uses('ProductStatistic', 'Lib/Event');
App::uses('InventoryManager', 'Lib/Event');
App::uses('OrderEmailSender', 'Lib/Event');
App::uses('PaykeEventCreator', 'Lib/Event');
App::uses('PaykeEventSender', 'Lib/Event');
App::uses('QuestionnaireAnswerMail', 'Lib/Event');
App::uses('RefundOrCancelRequester', 'Lib/Event');

$Config = ClassRegistry::init('Config');
$affiliateEmailsEnabled = !boolval($Config->get('affiliate_emails_disabled'));

// Attach listeners.
CakeEventManager::instance()->attach(new AffiliateResultApprover());
if ($affiliateEmailsEnabled) { // アフィリ関連メールを配信する
	CakeEventManager::instance()->attach(new AffiliateResultEmailSender());
	CakeEventManager::instance()->attach(new AuthEmailSender());
}
CakeEventManager::instance()->attach(new PaymentDeclinedEmailSender());
CakeEventManager::instance()->attach(new PaymentEmailSender());
CakeEventManager::instance()->attach(new PaymentErrorEmailSender());
CakeEventManager::instance()->attach(new PaymentFailedEmailSender());
CakeEventManager::instance()->attach(new ProductStatistic());
CakeEventManager::instance()->attach(new InventoryManager());
CakeEventManager::instance()->attach(new OrderEmailSender());
CakeEventManager::instance()->attach(new QuestionnaireAnswerMail());
CakeEventManager::instance()->attach(new RefundOrCancelRequester());

// Webhooks
CakeEventManager::instance()->attach(new PaykeEventCreator());
CakeEventManager::instance()->attach(new PaykeEventSender());

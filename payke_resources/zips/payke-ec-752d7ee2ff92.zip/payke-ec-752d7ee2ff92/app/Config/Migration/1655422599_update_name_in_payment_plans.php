<?php
class UpdateNameInPaymentPlans extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'update_name_in_payment_plans';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
		),
		'down' => array(
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$payment_plans = $prefix . 'payment_plans';

		if ($direction === 'up') {
			// Stripe 1回払いのプランの名前を修正（1632899359 のマイグレーションでの設定ミスを修正）
			$sql = <<<EOT
UPDATE `{$payment_plans}` SET `name` = '一括'
WHERE `payment_method_id` = 7
AND `reference_plan_id` IS NULL
AND `name` IS NULL
AND `cycles` = 1
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('payment_plans has NOT been migrated');
				return false;
			}
			$this->callback->out('payment_plans has been migrated');
		}

		return true;
	}
}

<?php
class AddDueDateAndDemandedToPayments extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_due_date_and_demanded_to_payments';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'alter_field' => array(
				'payments' => array(
					'amount' => array('after' => 'summary'),
				),
			),
			'create_field' => array(
				'payments' => array(
					'due_date' => array('type' => 'date', 'null' => true, 'default' => null, 'after' => 'amount'),
					'demanded' => array('type' => 'datetime', 'null' => true, 'default' => null, 'after' => 'paid_date'),
				),
			),
		),
		'down' => array(
			'drop_field' => array(
				'payments' => array('due_date', 'demanded'),
			),
			'alter_field' => array(
				'payments' => array(
					'amount' => array('after' => 'paid_date'),
				),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$mail_template_bases = $prefix . 'mail_template_bases';
		$orders = $prefix . 'orders';
		$payments = $prefix . 'payments';
		if ($direction === 'up') {
			// 既存の注文（銀振で継続）について初回未入金を追加
			$sql = <<<EOT
INSERT INTO `{$payments}` (
`order_id`, `payment_method_id`, `summary`, `amount`, `due_date`, `created`, `modified`
)
SELECT
	`id`,
	`payment_method_id`,
	DATE_FORMAT(`due_date`, '%Y年%c月分') AS `summary`,
	`amount`,
	CAST(`due_date` AS DATE) AS `due_date`,
	NOW(),
	NOW()
FROM (
	SELECT
		`id`,
		`payment_method_id`,
		`amount_per_cycle` AS `amount`,
		ADDDATE(
			`order_date`,
			`bank_transfer_limit`
		) AS `due_date`
	FROM `{$orders}` AS `o`
	WHERE `payment_method_id` = 9
	AND `status` = 0
	AND `payment_cycles` = 0
	AND `deleted` = FALSE
	AND NOT EXISTS (
		SELECT 1
		FROM `{$payments}` AS `p`
		WHERE `p`.`order_id` = `o`.`id`
	)
) AS `o2`
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('payments has NOT been migrated');
				return false;
			}
			$this->callback->out('payments has been migrated');

			// メールテンプレートベース16を追加
			$sql = <<<EOT
INSERT INTO `{$mail_template_bases}`
(`id`, `sort`, `type`, `name`, `subject`, `body`, `created`)
VALUES
(16, 63, 'DemandPaymentMail', '入金催促',
'%item_name%のご入金が確認できておりません',
'%name%様、

%item_name%に対して、下記お支払が確認できておりません。
　　　%summary%
　　　%payment%
　　　%amount%円

至急、ご対応をお願い致します。

それでは今後ともよろしくお願いいたします。
===================================================================
このメッセージは、自動的に送信されております。
ご不明な点、このメールに心当たりのない場合、下記までご連絡ください。
お問い合わせ先：%admin_email%
===================================================================
送信日時：%send_date%
', NOW());
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_template_bases has NOT been migrated');
				return false;
			}
			$this->callback->out('mail_template_bases has been migrated');

		} else if ($direction === 'down') {

			// 銀振継続の初回未入金を削除
			$sql = <<<EOT
DELETE FROM `{$payments}`
WHERE `paid_date` IS NULL
AND `payment_method_id` = 9
AND `order_id` IN (
	SELECT `id` FROM `{$orders}`
	WHERE `payment_method_id` = 9
	AND `payment_cycles` = 0
)
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('payments has NOT been migrated');
				return false;
			}
			$this->callback->out('payments has been migrated');

			// メールテンプレートベース16を削除
			$sql = "DELETE FROM `{$mail_template_bases}` WHERE `id` = 16;";
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_template_bases has NOT been migrated');
				return false;
			}
			$this->callback->out('mail_template_bases has been migrated');
		}

		return true;
	}
}

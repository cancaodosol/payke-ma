<?php
class AddUnivaPay extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_UnivaPay';

/**
 * UnivaPay用のテーブルやカラムを作成する。
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'create_table' => array(
				'univapay_events' => array(
					'id' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 80, 'key' => 'primary', 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'event' => array('type' => 'string', 'null' => false, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'data' => array('type' => 'text', 'null' => false, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'status' => array('type' => 'string', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'created' => array('type' => 'datetime', 'null' => true, 'default' => null),
					'modified' => array('type' => 'datetime', 'null' => true, 'default' => null),
					'indexes' => array(
						'PRIMARY' => array('column' => 'id', 'unique' => 1),
					),
					'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB'),
				),
			),
			'create_field' => array(
				'configs' => array(
					'univapay_token' => array('type' => 'text', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'stripe_webhook_secret'),
					'univapay_secret' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 20, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'univapay_token'),
					'univapay_webhook_auth_token' => array('type' => 'text', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'univapay_secret'),
				),
				'payment_methods' => array(
					'obsolete' => array('type' => 'boolean', 'null' => true, 'default' => '0'),
				),
			),
		),
		'down' => array(
			'drop_table' => array(
				'univapay_events'
			),
			'drop_field' => array(
				'configs' => array('univapay_token', 'univapay_secret', 'univapay_webhook_auth_token'),
				'payment_methods' => array('obsolete'),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		if ($direction === 'up') {
			// 既存データの修正 (UnivaPayとは無関係)
			// 銀行振込の継続払いプランの frequency の値が NULL になっているものを修正
			$prefix = $this->db->config['prefix'];
			$payment_plans = $prefix . 'payment_plans';
			$sql = <<<EOT
UPDATE `{$payment_plans}`
SET `frequency` = 'P1M'
WHERE `frequency` IS NULL
AND `payment_method_id` = 9
AND `reference_plan_id` IS NULL
AND `cycles` = 0
EOT;
			$result = $this->db->query($sql);
			if ($result === false) {
				$this->callback->err('payment_plans has NOT been migrated');
				return false;
			}
			$this->callback->out('payment_plans has been migrated');
		}

		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$payment_methods = $prefix . 'payment_methods';

		if ($direction === 'up') {
			// obsoleteカラムの値を設定
			$sql = <<<EOT
UPDATE `{$payment_methods}` SET `obsolete` = TRUE
WHERE `identifier` IN ('yahoo_fastpay', 'rakuten_pay_lite')
EOT;
			$result = $this->db->query($sql);
			if ($result === false) {
				$this->callback->err('payment_methods.obsolete has NOT been migrated');
				return false;
			}
			// UnivaPayを追加
			$sql = <<<EOT
INSERT INTO `{$payment_methods}`
(`id`, `identifier`, `name`, `notation`, `type`)
VALUES (8, 'univapay', 'UnivaPay', 'クレジットカード', 0)
EOT;
			$result = $this->db->query($sql);
			if ($result === false) {
				$this->callback->err('payment_methods has NOT been migrated');
				return false;
			}
			$this->callback->out('payment_methods has been migrated');
		} elseif ($direction === 'down') {
			// UnivaPayを削除
			$sql = <<<EOT
DELETE FROM `{$payment_methods}` WHERE `identifier` = 'univapay';
EOT;
			$result = $this->db->query($sql);
			if ($result === false) {
				$this->callback->err('payment_methods has NOT been migrated');
				return false;
			}
			$this->callback->out('payment_methods has been migrated');
		}

		return true;
	}
}

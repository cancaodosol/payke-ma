<?php
class CreateTableAmazonEnvironments extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'create_table_amazon_environments';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'create_table' => array(
				'amazon_environments' => array(
					'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
					'name' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 50, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'sandbox' => array('type' => 'boolean', 'null' => true, 'default' => null),
					'mws_endpoint' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 2083, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'widget_url' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 2083, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
					'indexes' => array(
						'PRIMARY' => array('column' => 'id', 'unique' => 1),
					),
					'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB'),
				),
			),
		),
		'down' => array(
			'drop_table' => array(
				'amazon_environments'
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$AmazonEnvironments = ClassRegistry::init(array('class' => 'AmazonEnvironments', 'ds' => $this->connection));

		if ($direction === 'up') {
			$data = array(
				// テスト環境
				array(
					'id' => 1,
					'name' => 'テスト環境',
					'sandbox' => true,
					'mws_endpoint' => 'https://mws.amazonservices.jp/OffAmazonPayments_Sandbox/2013-01-01/',
					'widget_url' => 'https://static-fe.payments-amazon.com/OffAmazonPayments/jp/sandbox/lpa/js/Widgets.js',
				),
				// 本番環境
				array(
					'id' => 2,
					'name' => '本番環境',
					'sandbox' => false,
					'mws_endpoint' => 'https://mws.amazonservices.jp/OffAmazonPayments/2013-01-01/',
					'widget_url' => 'https://static-fe.payments-amazon.com/OffAmazonPayments/jp/lpa/js/Widgets.js',
				),
			);
			$AmazonEnvironments->create();
			if ($AmazonEnvironments->saveMany($data)) {
				$this->callback->out('amazon_environments table has been initialized');
			} else {
				$this->callback->err('amazon_environments table has NOT been initialized');
				return false;
			}
		}

		return true;
	}
}

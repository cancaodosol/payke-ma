<?php
class AddBankTransferPaymentMailTemplateData extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_BankTransferPaymentMail_template_data';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
		),
		'down' => array(
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$mail_templates = $prefix . 'mail_templates';
		$products = $prefix . 'products';
		if ($direction === 'up') {
			// 決済完了メール（分割支払）のテンプレートを追加/変更
			$sql = <<<EOT
UPDATE `{$mail_templates}`
SET `name` = '決済完了　分割払い（ペイパル）', `modified` = NOW()
WHERE `id` = 9;

UPDATE `{$mail_templates}`
SET `product_id` = NULL, `purchase_type` = 1, `sort` = 16,
`type` = 'BankTransferPaymentMail',
`name` = '決済完了　分割払い（銀行振込）',
`subject` = 'ご注文内容のご確認（%item_name%：銀行振込）',
`body` = '%name%様

この度は%item_name%のご購入、誠にありがとうございます。
お申込み内容をご確認下さい。

-------------------------------------------
　商品情報
-------------------------------------------

注文ID　　　：%order_no%
商品名　　　：%item_name%
価　格　　　：%price% 円
数量　　　　：%quantity%
合計　　　　：%gross% 円

お支払方法　：%payment%
ご注文日時　：%order_date%

お支払プラン
金額　　　　：%amount_per_cycle% 円
回数　　　　：%payment_cycles%
期日　　　　：%pay_limit%

-------------------------------------------
　お客様情報
-------------------------------------------

メール　　　：%email%
お名前　　　：%name%
郵便番号　　：〒 %zip%
住所　　　　：%address%
電話番号　　：%phone%

%af_memo%

===================================================================
このメッセージは、自動的に送信されております。
ご不明な点、このメールに心当たりのない場合、下記までご連絡ください。
お問い合わせ先：%admin_email%
===================================================================
送信日時：%send_date%',
`modified` = NOW()
WHERE `id` = 10;

UPDATE `{$mail_templates}`
SET `name` = '決済完了　ペイパル定期支払', `modified` = NOW()
WHERE `id` = 5;
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_templates has NOT been migrated');
				return false;
			}

			// 「一括/分割支払」の各商品の「決済完了メール 分割払い（銀行振込）」を作成
			$sql = <<<EOT
INSERT INTO `{$mail_templates}` (`product_id`, `type`, `subject`, `body`, `created`)
SELECT `p`.id, `mt`.`type`, `mt`.`subject`, `mt`.`body`, NOW()
FROM `{$mail_templates}` AS `mt` CROSS JOIN `{$products}` AS `p`
WHERE `mt`.`type` = 'BankTransferPaymentMail'
AND `p`.`purchase_type` = 1
ORDER BY `p`.`id`;
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_templates has NOT been migrated');
				return false;
			}

			$this->callback->out('mail_templates has been migrated');

		} else if ($direction === 'down') {
			// 決済完了メール（分割支払）のテンプレートの追加/変更を戻す
			$sql = <<<EOT
UPDATE `{$mail_templates}`
SET `name` = '決済完了　分割支払', `modified` = NOW()
WHERE `id` = 9;

UPDATE `{$mail_templates}`
SET `product_id` = 99999999, `purchase_type` = NULL, `sort` = NULL,
`type` = '(reserved)', `name` = NULL, `subject` = NULL, `body` = NULL,
`modified` = NOW()
WHERE `id` = 10;

UPDATE `{$mail_templates}`
SET `name` = '決済完了　ペイパル（定期支払）', `modified` = NOW()
WHERE `id` = 5;
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_templates has NOT been migrated');
				return false;
			}

			// 「一括/分割支払」の各商品の「決済完了メール 分割払い（銀行振込）」を削除
			$sql = <<<EOT
DELETE FROM `{$mail_templates}`
WHERE `product_id` IS NOT NULL AND `type` = 'BankTransferPaymentMail';
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_templates has NOT been migrated');
				return false;
			}

			$this->callback->out('mail_templates has been migrated');
		}

		return true;
	}
}

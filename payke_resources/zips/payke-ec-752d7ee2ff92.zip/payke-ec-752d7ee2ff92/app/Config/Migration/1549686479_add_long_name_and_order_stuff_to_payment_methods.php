<?php
class AddLongNameAndOrderStuffToPaymentMethods extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_long_name_and_order_stuff_to_payment_methods';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'create_field' => array(
				'payment_methods' => array(
					'long_name' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 50, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'name'),
					'admin_order' => array('type' => 'integer', 'null' => true, 'default' => null, 'length' => 10, 'unsigned' => true, 'after' => 'type'),
					'default_order' => array('type' => 'integer', 'null' => true, 'default' => null, 'length' => 10, 'unsigned' => true, 'after' => 'admin_order'),
				),
			),
		),
		'down' => array(
			'drop_field' => array(
				'payment_methods' => array('long_name', 'admin_order', 'default_order'),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		// payment_methods.name の変更
		$PaymentMethod = ClassRegistry::init(array(
			'class' => 'PaymentMethod',
			'ds' => $this->connection,
		));
		$data = array();

		if ($direction === 'up') {
			$data[] = array('id' => 1, 'long_name' => 'Yahoo!ウォレット FastPay');
			$data[] = array('id' => 2, 'name' => '楽天ペイ', 'long_name' => '楽天ペイ（オンライン決済LITE）', 'admin_order' => 2, 'default_order' => 4);
			$data[] = array('id' => 3, 'name' => 'Amazon Pay', 'long_name' => 'Amazon Pay', 'admin_order' => 3, 'default_order' => 5);
			$data[] = array('id' => 4, 'name' => 'PayPal', 'long_name' => 'PayPal（一括）', 'admin_order' => 1, 'default_order' => 1);
			$data[] = array('id' => 5, 'name' => 'PayPal定期支払', 'long_name' => 'PayPal定期支払（分割）', 'default_order' => 3);
			$data[] = array('id' => 9, 'long_name' => '銀行振込', 'default_order' => 2);
		} else if ($direction === 'down') {
			$data[] = array('id' => 2, 'name' => '楽天ID決済');
			$data[] = array('id' => 3, 'name' => 'Amazonペイメント');
			$data[] = array('id' => 4, 'name' => 'ペイパル');
			$data[] = array('id' => 5, 'name' => 'ペイパル（定期支払）');
		}

		$results = $PaymentMethod->saveMany($data, array(
			'callbacks' => false,
			'validate' => false,
		));
		if (!$results) {
			$this->callback->err('payment_methods has NOT been migrated');
			return false;
		}
		$this->callback->out('payment_methods has been migrated');

		return true;
	}
}

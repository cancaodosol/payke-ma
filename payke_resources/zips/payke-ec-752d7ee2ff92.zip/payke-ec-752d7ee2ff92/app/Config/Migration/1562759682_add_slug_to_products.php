<?php
class AddSlugToProducts extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_slug_to_products';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'create_field' => array(
				'products' => array(
					'slug' => array('type' => 'string', 'null' => true, 'default' => null, 'key' => 'unique', 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'name'),
					'indexes' => array(
						'slug' => array('column' => 'slug', 'unique' => 1),
					),
				),
			),
		),
		'down' => array(
			'drop_field' => array(
				'products' => array('slug', 'indexes' => array('slug')),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$products = $prefix . 'products';
		if ($direction === 'up') {
			// 商品
			$sql = "UPDATE `{$products}` SET `slug` = CONCAT('product-', `id`);";
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('products has NOT been migrated');
				return false;
			}
			$this->callback->out('products has been migrated');
		}

		return true;
	}
}

<?php
class CreateTablePaymentMethodsProducts extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'create_table_payment_methods_products';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'create_table' => array(
				'payment_methods_products' => array(
					'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
					'payment_method_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
					'product_id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
					'indexes' => array(
						'PRIMARY' => array('column' => 'id', 'unique' => 1),
					),
					'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB'),
				),
			),
		),
		'down' => array(
			'drop_table' => array(
				'payment_methods_products'
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$PaymentMethodsProduct = ClassRegistry::init(array('class' => 'PaymentMethodsProduct', 'ds' => $this->connection));
		$Product = ClassRegistry::init(array('class' => 'Product', 'ds' => $this->connection));

		if ($direction === 'up') {
			$products = $Product->find('all', array(
				'recursive' => -1,
			));
			$data = array();
			foreach ($products as $product) {
				if ($product['Product']['purchase_type'] == 1) { // 一括払い型
					if ($product['Product']['credit_available']) { // クレジット可
						$data[] = array(
							'payment_method_id' => 1, // FastPay
							'product_id' => $product['Product']['id'],
						);
						$data[] = array(
							'payment_method_id' => 2, // LITE
							'product_id' => $product['Product']['id'],
						);
					}
					if ($product['Product']['bank_transfer_available']) { // 銀行振込可
						$data[] = array(
							'payment_method_id' => 9, // 銀行振込
							'product_id' => $product['Product']['id'],
						);
					}
				} else if ($product['Product']['purchase_type'] == 2) { // 継続課金型
					$data[] = array(
						'payment_method_id' => 1, // FastPay
						'product_id' => $product['Product']['id'],
					);
				}
			}
			if (0 < count($data)) {
				if ($PaymentMethodsProduct->saveMany($data)) {
					$this->callback->out('payment_methods_products table has been initialized');
				} else {
					$this->callback->err('payment_methods_products table has NOT been initialized');
					return false;
				}
			}
		}

		return true;
	}
}

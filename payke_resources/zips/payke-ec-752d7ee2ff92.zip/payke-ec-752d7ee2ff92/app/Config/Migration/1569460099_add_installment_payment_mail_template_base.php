<?php
class AddInstallmentPaymentMailTemplateBase extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_installment_payment_mail_template_base';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
		),
		'down' => array(
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		$prefix = $this->db->config['prefix'];
		$mail_template_bases = $prefix . 'mail_template_bases';
		if ($direction === 'up') {
			// 分割入金確認通知メールテンプレートを追加
			$sql = <<<EOT
INSERT INTO `{$mail_template_bases}`
(`id`, `sort`, `type`, `name`, `subject`, `body`, `created`)
VALUES
(13, 65, 'InstallmentPaymentMail', '入金確認　分割払い（銀行振込/PayPal定期支払）',
'ご入金を確認しました',
'%name%様、
%item_name%に対して、下記ご入金を確認しました
　　　%payment%
　　　%paid_date%
　　　%amount%円
それでは今後ともよろしくお願いいたします。
===================================================================
このメッセージは、自動的に送信されております。
ご不明な点、このメールに心当たりのない場合、下記までご連絡ください。
お問い合わせ先：%admin_email%
===================================================================
送信日時：%send_date%
', NOW());
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_template_bases has NOT been migrated');
				return false;
			}
			$this->callback->out('mail_template_bases has been migrated');

		} else if ($direction === 'down') {
			// 分割入金確認通知メールテンプレートを削除
			$sql = <<<EOT
DELETE FROM `{$mail_template_bases}` WHERE `id` = 13;
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('mail_template_bases has NOT been migrated');
				return false;
			}
			$this->callback->out('mail_template_bases has been migrated');
		}

		return true;
	}
}

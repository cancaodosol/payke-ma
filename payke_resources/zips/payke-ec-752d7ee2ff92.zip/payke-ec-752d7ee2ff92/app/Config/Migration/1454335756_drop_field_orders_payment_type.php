<?php
class DropFieldOrdersPaymentType extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'drop_field_orders_payment_type';

/**
 * Actions to be performed
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'drop_field' => array(
				'orders' => array('payment_type'),
			),
		),
		'down' => array(
			'create_field' => array(
				'orders' => array(
					'payment_type' => array('type' => 'integer', 'null' => true, 'default' => null, 'length' => 1, 'unsigned' => false, 'after' => 'amount'),
				),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		if ($direction === 'down') {
			$prefix = $this->db->config['prefix'];
			$orders = $prefix . 'orders';
			$sql = "UPDATE `{$orders}` SET `payment_type` = IF(`payment_method_id` = 9, 1, 0)";
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('orders has NOT been migrated');
				return false;
			}
			$this->callback->out('orders has been migrated');
		}

		return true;
	}
}

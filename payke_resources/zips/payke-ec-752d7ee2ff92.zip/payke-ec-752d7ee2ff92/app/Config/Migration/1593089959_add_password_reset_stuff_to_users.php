<?php
class AddPasswordResetStuffToUsers extends CakeMigration {

/**
 * Migration description
 *
 * @var string
 */
	public $description = 'add_password_reset_stuff_to_users';

/**
 * Actions to be performed
 *
 * 以下の順序で実行されるみたい（Migrations プラグインのドキュメントには載っていない）。
 * up
 * - Change field
 * - Add field
 * down
 * - Drop field
 * - Change field
 * 分かり易くするため、以下の配列もその順序通りに記述した。
 *
 * @var array $migration
 */
	public $migration = array(
		'up' => array(
			'alter_field' => array(
				'users' => array(
					'email' => array('type' => 'string', 'null' => true, 'default' => null, 'key' => 'unique', 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'password'),
				),
			),
			'create_field' => array(
				'users' => array(
					'password_token' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 128, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'password'),
					'email_verified' => array('type' => 'boolean', 'null' => true, 'default' => '0', 'after' => 'email'),
					'email_token' => array('type' => 'string', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'email_verified'),
					'email_token_expires' => array('type' => 'datetime', 'null' => true, 'default' => null, 'after' => 'email_token'),
					'active' => array('type' => 'boolean', 'null' => true, 'default' => '0', 'after' => 'email_token_expires'),
				),
			),
		),
		'down' => array(
			'drop_field' => array(
				'users' => array('password_token', 'email_verified', 'email_token', 'email_token_expires', 'active'),
			),
			'alter_field' => array(
				'users' => array(
					'email' => array('type' => 'string', 'null' => true, 'default' => null, 'key' => 'unique', 'collate' => 'utf8_general_ci', 'charset' => 'utf8', 'after' => 'username'),
				),
			),
		),
	);

/**
 * Before migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function before($direction) {
		return true;
	}

/**
 * After migration callback
 *
 * @param string $direction Direction of migration process (up or down)
 * @return bool Should process continue
 */
	public function after($direction) {
		if ($direction === 'up') {
			$prefix = $this->db->config['prefix'];
			$users = $prefix . 'users';
			$sql = <<<EOT
UPDATE `{$users}` SET `email_verified` = TRUE, `active` = TRUE
EOT;
			$results = $this->db->query($sql);
			if ($results === false) {
				$this->callback->err('users has NOT been migrated');
				return false;
			}
			$this->callback->out('users has been migrated');
		}

		return true;
	}
}

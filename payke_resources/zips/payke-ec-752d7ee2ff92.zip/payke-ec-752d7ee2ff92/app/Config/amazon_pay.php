<?php
// Amazon Pay にアクセスするデータソースを動的に作成

App::uses('ClassRegistry', 'Utility');
App::uses('ConnectionManager', 'Model');

try {
	$Config = ClassRegistry::init('Config');
	$amazonPayPublicKeyId = $Config->get('amazon_pay_public_key_id');
	$amazonPayPrivateKey = $Config->get('AmazonPayPrivateKey.key');
	$sandbox = ($Config->get('amazon_pay_environment') === 'sandbox');
} catch (\Exception $e) {
	// データベース接続を未設定等の場合
}

if (!empty($amazonPayPublicKeyId)) {
	$config = [
		'datasource' => 'AmazonPaySource',

		'public_key_id' => $amazonPayPublicKeyId,
		'private_key' => $amazonPayPrivateKey,
		'sandbox' => boolval($sandbox),
	];

	$ds = ConnectionManager::create('amazon_pay', $config);
}

<?php
App::uses('AppController', 'Controller');

/**
 * StripeProducts Controller
 *
 * @property FlashComponent $Flash
 * @property PaginatorComponent $Paginator
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class StripeProductsController extends AppController {

	const URL_ADMIN_INDEX = [
		'admin' => true,
		'controller' => 'stripe_products',
		'action' => 'index',
		'?' => [
			'active' => 'true',
		],
	];

/**
 * {@inheritdoc}
 */
	public $components = [
		'Flash',
		'Paginator' => [
			'className' => 'StripePaginator',
		],
		'RequestHandler',
		'Session',
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'paramType' => 'querystring',
	];

/**
 * 各アクションの後で、ビューが描画される前に呼ばれる。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeRender
 */
	public function beforeRender() {
		parent::beforeRender();

		if ($this->request->is('json')) {
		} else {
			$this->helpers['Paginator'] = ['className' => 'StripePaginator'];
		}
	}

/**
 * admin_index method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_index() {
		$conditions = array_only($this->request->query, [
			'active',
		]);
		$this->Paginator->settings = compact('conditions') + $this->paginate;
		$products = $this->Paginator->paginate();
		$this->set(compact('products'));
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id = null) {
		$this->set('product', $this->StripeProduct->read(null, $id));
		$this->loadModel('StripePrice');
		$this->set('prices', $this->StripePrice->find('all', [
			'conditions' => ['product' => $id],
		]));
	}

/**
 * admin_add method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->StripeProduct->create();
			$result = $this->StripeProduct->save($this->request->data, ['atomic' => false]);
			if (!$result) {
				$message = __('The product could not be saved. Please, try again.');
				$errors = $this->StripeProduct->validationErrors;
				$this->response->statusCode(400);
				return $this->set(compact('errors', 'message'));
			}
			$message = __('The product has been saved.');
			$product = $result;
			$this->set(compact('message', 'product'));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_edit($id = null) {
		if ($this->request->is(array('post', 'put'))) {
			$this->StripeProduct->id = $id;
			$result = $this->StripeProduct->save($this->request->data, ['atomic' => false]);
			if (!$result) {
				$message = __('The product could not be saved. Please, try again.');
				$errors = $this->StripeProduct->validationErrors;
				$this->response->statusCode(400);
				return $this->set(compact('errors', 'message'));
			}
			$message = __('The product has been saved.');
			$product = $result;
			$this->set(compact('message', 'product'));
		} else {
			$product = $this->StripeProduct->read(null, $id);
			$this->set(compact('product'));
		}
	}

/**
 * admin_archive method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_archive($id = null) {
		return $this->_activate($id, false);
	}

/**
 * admin_unarchive method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_unarchive($id = null) {
		return $this->_activate($id);
	}

/**
 * _activate method
 *
 * @param string $id
 * @param boolean $active
 * @return void
 * @throws ApiErrorException
 */
	protected function _activate($id = null, $active = true) {
		$referrer = $this->referer(self::URL_ADMIN_INDEX);
		if ($this->request->is(array('post', 'put'))) {
			$this->request->data($this->StripeProduct->alias, [
				$this->StripeProduct->primaryKey => $id,
				'active' => $active,
			]);
			if ($this->StripeProduct->save($this->request->data, ['atomic' => false])) {
				$this->Flash->success(__('The product has been updated.'));
			} else {
				$this->Flash->error(__('The product could not be updated. Please, try again.'));
			}
		}
		return $this->redirect($referrer);
	}

/**
 * admin_delete method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_delete($id = null) {
		$referrer = $this->referer(self::URL_ADMIN_INDEX);
		$this->request->allowMethod('post', 'delete');
		if ($this->StripeProduct->delete($id, false)) {
			$this->Flash->success(__('The product has been deleted.'));
			if (strpos($referrer, Router::url(['action' => 'view', $id]))) { // 詳細ページからの削除の場合
				$referrer = self::URL_ADMIN_INDEX;
			}
		} else {
			$this->Flash->error(__('The product could not be deleted. Please, try again.'));
		}
		return $this->redirect($referrer);
	}
}

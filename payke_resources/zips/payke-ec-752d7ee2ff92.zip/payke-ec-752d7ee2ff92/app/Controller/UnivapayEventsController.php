<?php
App::uses('AppController', 'Controller');
/**
 * UnivapayEvents Controller
 *
 * @property UnivapayEvent $UnivapayEvent
 * @property RequestHandlerComponent $RequestHandler
 * @link https://docs.prod.univapaycast.com/References/webhooks/
 */
class UnivapayEventsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id10
 */
	public function beforeFilter() {
		// parent::beforeFilter(); // AppController::beforeFilter()の処理の多くは不要と思われるため呼んでいない

		// NOTE: Authorizationヘッダーによる認証はやめる（うまくいかない環境があるようなので）

		// 認証されていないリクエストの場合にビューを描画せず HTTP ステータスコード 403 を返す
		// $this->Auth->ajaxLogin = null;

		// トークン認証の設定
		// （Authorizationヘッダの値と configs.univapay_webhook_auth_token の値を照合）
		// $this->Auth->authenticate = [
		// 	'AuthToken' => [ // Component/Auth/AuthTokenAuthenticate クラスを使う
		// 		'fields' => [
		// 			'token' => 'univapay_webhook_auth_token',
		// 		],
		// 		'header' => 'Authorization',
		// 		'userModel' => 'Config',
		// 		'scope' => ['Config.name' => 'default'],
		// 		'recursive' => -1,
		// 	],
		// ];
		// 認証不要とする
		$this->Auth->allow('process');

		// [指定したアクションの CSRF とデータバリデーションの無効化](https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id12)
		$this->Security->unlockedActions = [
			'process'
		];
	}

/**
 * process method
 *
 * @return void
 * @throws BadRequestException
 * @throws ForbiddenException
 * @throws InternalErrorException
 * @throws MethodNotAllowedException
 */
	public function process() {
		$this->request->allowMethod('post');
		// $this->log($this->request->data, 'debug');

		// 処理対象か否かを確認
		$event = $this->request->data('event');
		if (empty($this->UnivapayEvent->handler($event))) {
			$message = "Unsupported event: {$event}";
			$this->log($message, 'warning');
			return;
		}

		// NOTE: UnivaPayからPOSTされたデータにはidがある場合と無い場合がある!
		// - 通常はidが無い。管理画面で表示されているidはPOST後に付けたものと思われる。
		//   (データにid値が無い場合、CakePHPはカラムが36桁だと自動生成したUUIDを使う)
		// - 管理画面上で[呼び出し]ボタンにより再送させた場合はidがあるが、何故か前回のid!
		// - 再送毎にidは変わる! 同一内容のイベントかを判別できなくなり意味が無いのでは?
		// 他の決済サービスのWebhookと違っていて、どう処理すべきかドキュメントにも無く不明。
		// 同一内容のイベントかは判別したいので、idそのものは使わずに、他の値を加工した文字列
		// (data.id + data.created_on) で代用することにした。
		$dataId = $this->request->data('data.id');
		$createdOn = $this->request->data('data.created_on');
		$this->request->data('id', "{$dataId}+{$createdOn}");

		// 既存を確認
		$id = $this->request->data('id');
		if ($this->UnivapayEvent->exists($id)) { // 過去に受信して保存済の場合
			$message = "The UnivapayEvent is redundant. id: {$id}";
			$this->log($message, 'info');
			return;
		}

		// 保存
		$this->UnivapayEvent->create();
		if (!$this->UnivapayEvent->save($this->request->data)) {
			$this->log($this->UnivapayEvent->validationErrors);
			throw new InternalErrorException("The UnivaPay event could not be saved. id: {$id}");
		}
	}
}

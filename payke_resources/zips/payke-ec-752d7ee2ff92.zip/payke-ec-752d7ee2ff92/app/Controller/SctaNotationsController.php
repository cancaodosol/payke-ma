<?php
App::uses('AppController', 'Controller');
/**
 * SctaNotations Controller
 *
 * @property FlashComponent $Flash
 * @property PaginatorComponent $Paginator
 * @property SctaNotation $SctaNotation
 * @property SessionComponent $Session
 */
class SctaNotationsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Flash',
		// https://book.cakephp.org/2/ja/controllers.html#Controller::$paginate
		'Paginator' => [
			'contain' => false,
			'paramType' => 'querystring',
		],
		'RequestHandler',
		'Session',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// ゲスト（未ログイン）ユーザーに公開するアクション
		$this->Auth->allow('view');
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 * @link https://book.cakephp.org/2/ja/views/json-and-xml-views.html#id3
 */
	public function view($id = null) {
		if (!$this->SctaNotation->exists($id)) {
			throw new NotFoundException(__('Invalid SCTA notation'));
		}
		$options = [
			'conditions' => ['SctaNotation.id' => $id],
			'contain' => false,
		];
		$sctaNotation = $this->SctaNotation->find('first', $options);
		$this->set(compact('sctaNotation'));
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Paginator->settings = $this->paginate;
		$this->set('sctaNotations', $this->Paginator->paginate());
	}

/**
 * 設定を取得する。
 *
 * @param int $id ID
 * @return array
 * @throws ForbiddenException
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::requestAction
 */
	public function admin_view($id = 1) {
		if (empty($this->request->params['requested'])) {
			throw new ForbiddenException();
		}
		$options = [
			'conditions' => ['SctaNotation.id' => $id],
			'contain' => false,
			'fields' => ['seller'],
		];
		return $this->SctaNotation->find('first', $options);
	}

/**
 * admin_edit method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		$this->SctaNotation->id = $id;
		if (!$this->SctaNotation->exists()) {
			throw new NotFoundException(__('Invalid SCTA notation'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->SctaNotation->save($this->request->data)) {
				$this->Flash->success(__('The SCTA notation has been saved.'));
				return $this->redirect(['action' => 'index']);
			} else {
				$this->Flash->error(__('The SCTA notation could not be saved. Please, try again.'));
			}
		}
		$options = [
			'conditions' => ['SctaNotation.id' => $id],
			'contain' => false,
		];
		$data = $this->SctaNotation->find('first', $options);
		$this->request->data = Hash::merge($data, $this->request->data);
	}

/**
 * admin_duplicate method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_duplicate($id = null) {
		$this->SctaNotation->id = $id;
		if (!$this->SctaNotation->exists()) {
			throw new NotFoundException(__('Invalid SCTA notation'));
		}
		$this->request->allowMethod('post');
		if (!$this->SctaNotation->duplicate()) {
			$this->Flash->error(__('The SCTA notation could not be duplicated.'));
			$this->log($this->SctaNotation->validationErrors);
			return $this->redirect($this->referer());
		}
		$this->Flash->success(__('The SCTA notation has been duplicated.'));
		return $this->redirect(['action' => 'edit', $this->SctaNotation->id]);
	}

/**
 * admin_delete method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		$this->SctaNotation->id = $id;
		if (!$this->SctaNotation->exists()) {
			throw new NotFoundException(__('Invalid SCTA notation'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($count = $this->SctaNotation->countProducts()) {
			$this->Flash->error(__('The SCTA notation could not be deleted because it has some products.'));
		} elseif ($this->SctaNotation->delete()) {
			$this->Flash->success(__('The SCTA notation has been deleted.'));
		} else {
			$this->Flash->error(__('The SCTA notation could not be deleted. Please, try again.'));
		}
		return $this->redirect(['action' => 'index']);
	}
}

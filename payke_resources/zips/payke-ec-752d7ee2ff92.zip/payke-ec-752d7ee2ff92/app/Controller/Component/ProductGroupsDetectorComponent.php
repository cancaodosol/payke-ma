<?php

App::uses('Component', 'Controller');

/**
 * ProductGroupsDetector Component class
 */
class ProductGroupsDetectorComponent extends Component {

/**
 * Request object
 *
 * @var CakeRequest
 */
	public $request;

/**
 * Initializes ProductGroupsDetectorComponent for use in the controller.
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);
		$this->request = $controller->request;
		$this->ProductGroup = $controller->User->ProductGroup;
	}

/**
 * クエリーパラメータで指定された商品グループを特定して返す。
 *
 * @return array
 * @throws NotFoundException
 */
	public function detect() {
		$pgs = $this->request->query('pgs');
		$values = explode(',', $pgs);
		$productGroups = $this->ProductGroup->find('all', [
			'conditions' => ["{$this->ProductGroup->alias}.uniqueid" => $values],
			'recursive' => -1,
			'fields' => ['id'],
		]);
		if (empty($productGroups)) {
			throw new NotFoundException();
		}
		$productGroups = Hash::extract($productGroups, "{n}.{$this->ProductGroup->alias}");

		return $productGroups;
	}
}

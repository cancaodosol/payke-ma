<?php

App::uses('PaginatorComponent', 'Controller/Component');

/**
 * Stripe Paginator Component class
 *
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
class StripePaginatorComponent extends PaginatorComponent {

/**
 * {@inheritdoc}
 */
	public $whitelist = [
		'limit', 'page', 'starting_after', 'ending_before',
		'pagination',
	];

/**
 * {@inheritdoc}
 */
	public function paginate($object = null, $scope = [], $whitelist = []) {
		$results = parent::paginate($object, $scope, $whitelist);

		if (!$results) {
			return $results;
		}

		$object = $this->_getObject($object);

		// NOTE: Stripe からは全件数を取得できないため、ページ制御は[前へ][次へ]のみ実装する
		$first = $results[0][$object->alias];
		$last = $results[count($results) - 1][$object->alias];
		$paging = [
			'first' => $first[$object->primaryKey],
			'last' => $last[$object->primaryKey],
		];
		$this->Controller->request['paging'] = array_merge_recursive(
			$this->Controller->request['paging'],
			[$object->alias => $paging]
		);

		return $results;
	}
}

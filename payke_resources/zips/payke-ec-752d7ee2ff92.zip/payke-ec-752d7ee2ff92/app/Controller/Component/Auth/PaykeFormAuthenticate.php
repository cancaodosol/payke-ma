<?php
App::uses('AuthLog', 'Model');
App::uses('CakeEmail', 'Network/Email');
App::uses('ClassRegistry', 'Utility');
App::uses('FormAuthenticate', 'Controller/Component/Auth');
App::uses('RateLimiter', 'Cache');
App::uses('User', 'Model');

/**
 * 一定時間内のパスワード誤りによるログイン失敗数を管理したり、ログイン試行を記録するため、
 * FormAuthenticate を拡張。
 * 失敗理由を判別するため _findUser() をオーバーライドする必要があった。
 */
class PaykeFormAuthenticate extends FormAuthenticate {

/**
 * 一定時間内のログイン失敗数を管理するためのレート制限。
 *
 * @var RateLimiter
 */
	protected $limiter;

/**
 * レート制限のインスタンスを取得する。
 *
 * @return RateLimiter
 */
	protected function _limiter(): RateLimiter {
		if ($this->limiter === null) {
			$decaySeconds = Configure::read('auth.fail.limiter.decaySeconds');
			$this->limiter = new RateLimiter($decaySeconds);
		}
		return $this->limiter;
	}

/**
 * Find a user record using the standard options.
 *
 * The $username parameter can be a (string)username or an array containing
 * conditions for Model::find('first'). If the $password param is not provided
 * the password field will be present in returned array.
 *
 * Input passwords will be hashed even when a user doesn't exist. This
 * helps mitigate timing attacks that are attempting to find valid usernames.
 *
 * @param string|array $username The username/identifier, or an array of find conditions.
 * @param string $password The password, only used if $username param is string.
 * @return bool|array Either false on failure, or an array of user data.
 * @throws UnauthorizedException ロックされている場合
 */
	protected function _findUser($username, $password = null) {
		$userModel = $this->settings['userModel'];
		list(, $model) = pluginSplit($userModel);
		$fields = $this->settings['fields'];

		if (is_array($username)) {
			$conditions = $username;
		} else {
			$conditions = array(
				$model . '.' . $fields['username'] => $username
			);
		}

		if (!empty($this->settings['scope'])) {
			$conditions = array_merge($conditions, $this->settings['scope']);
		}

		$userFields = $this->settings['userFields'];
		if ($password !== null && $userFields !== null) {
			$userFields[] = $model . '.' . $fields['password'];
		}

		$result = ClassRegistry::init($userModel)->find('first', array(
			'conditions' => $conditions,
			'recursive' => $this->settings['recursive'],
			'fields' => $userFields,
			'contain' => $this->settings['contain'],
		));
		if (empty($result[$model])) {
			$this->passwordHasher()->hash($password);
			$this->_craeteAuthLog([ // ログイン試行を記録（失敗理由: 存在しないユーザ）
				'result' => AuthLog::RESULT_FAILED,
				'error' => 'Unknown user',
				'data' => [$fields['username'] => $username],
				'user_id' => '',
			]);
			return false;
		}

		$user = $result[$model];
		if ($user['locked']) { // ロックされている場合
			$this->_craeteAuthLog([ // ログイン試行を記録（失敗理由: ロックされている）
				'result' => AuthLog::RESULT_FAILED,
				'error' => 'Locked out',
				'user_id' => $user['id'],
			]);
			throw new UnauthorizedException(__('This user account is locked'));
		}
		if ($password !== null) {
			if (!$this->passwordHasher()->check($password, $user[$fields['password']])) {
				$maxAttempts = Configure::read('auth.fail.limiter.maxAttempts');
				if ($this->_limiter()->tooManyAttempts($username, $maxAttempts)) { // 失敗数が多過ぎる
					$this->_lockOut($user); // ユーザをロックアウト
				}
				$this->_limiter()->hit($username); // パスワード誤りによる失敗数を更新
				$this->_craeteAuthLog([ // ログイン試行を記録（失敗理由: パスワード誤り）
					'result' => AuthLog::RESULT_FAILED,
					'error' => 'Password mismatch',
					'user_id' => $user['id'],
				]);
				return false;
			}
			unset($user[$fields['password']]);
		}

		$this->_limiter()->clear($username); // パスワード誤りによる失敗数をリセット、タイマーをクリア

		if ($result['Profile']['affiliate_disabled']) { // アフィリエイトを停止されている場合
			$this->_craeteAuthLog([ // ログイン試行を記録（失敗理由: アフィリエイト停止）
				'result' => AuthLog::RESULT_FAILED,
				'error' => 'Affiliate disabled',
				'user_id' => $user['id'],
			]);
			throw new UnauthorizedException(__('This affiliate is disabled'));
		}

		$this->_craeteAuthLog([ // ログイン試行を記録（成功）
			'result' => AuthLog::RESULT_SUCCEEDED,
			'user_id' => $user['id'],
		]);

		unset($result[$model]);
		return array_merge($user, $result);
	}

/**
 * ログイン試行を記録する。
 *
 * @param array $data
 * @return void
 */
	protected function _craeteAuthLog(array $data) {
		$data += [
			'request_time' => env('REQUEST_TIME'),
			'type' => AuthLog::TYPE_LOGIN,
			'uri' => env('REQUEST_URI'),
		];

		$AuthLog = ClassRegistry::init('AuthLog');
		$AuthLog->create();
		$saved = $AuthLog->save([$AuthLog->alias => $data], ['validate' => false]);
		if (! $saved) {
			CakeLog::write('error', 'The auth log could not be saved.');
		}
	}

/**
 * ユーザをロックアウトする。
 *
 * @param array $user
 * @return bool
 */
	protected function _lockOut(array $user): bool {
		$User = ClassRegistry::init('User');
		$User->id = $user['id'];
		$result = $User->save([
			'User' => [
				'locked' => now()->toDateTimeString(),
			],
		], [
			'validate' => false,
		]);
		if (!$result) {
			CakeLog::write('error', 'The user could not be locked.');
			return false;
		}

		$role = User::translateRole($user['role']);

		// メールで通知
		$subject = 'ユーザがロックされました';
		$content = <<<EOT
一定時間に5回ログインに失敗したユーザがロックされました。

ユーザ: {$user['name']} ({$role})
EOT;
		$Email = new CakeEmail();
		$to = $Email->from(); // 宛先は管理者（基本設定 > メール送信設定 > 送信者メールアドレス）
		$result = $Email->to($to)->subject($subject)->send($content);
		if (!$result) {
			CakeLog::write('error', 'The email could not be sent.');
		}

		return true;
	}
}

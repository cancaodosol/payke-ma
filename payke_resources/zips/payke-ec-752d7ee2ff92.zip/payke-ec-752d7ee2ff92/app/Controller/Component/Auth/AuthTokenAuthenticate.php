<?php
App::uses('CakeLog', 'Log');
App::uses('TokenAuthenticate', 'Users.Controller/Component/Auth');

/**
 * Users.TokenAuthenticate をカスタマイズしたクラス。
 *
 * @link https://github.com/CakeDC/users/blob/2.x/Controller/Component/Auth/TokenAuthenticate.php
 */
class AuthTokenAuthenticate extends TokenAuthenticate {

/**
 * トークン情報をリクエストから取得する。
 *
 * @param CakeRequest $request リクエストオブジェクト
 * @return mixed 取得できない場合はfalse
 * @link https://www.php.net/manual/ja/function.getallheaders.php
 */
	public function getUser(CakeRequest $request) {
		if (!empty($this->settings['header'])) {
			$name = strtolower($this->settings['header']); // ヘッダ名を小文字に変換
			$headers = getallheaders(); // Authorizationヘッダ等が取得されるはず
			$headers = array_change_key_case($headers); // 取得したヘッダ名も小文字に変換
			$value = Hash::get($headers, $name);
			if ($value) {
				CakeLog::write('debug', "The request has the '{$name}' header.");
				$token = trim(str_ireplace('Bearer', '', $value)); // NOTE: UnivaPayからのリクエストでは'Bearer'は含まれない
				$result = $this->_findUser($token, null);
				if (!$result) {
					CakeLog::write('error', 'Unauthenticated.');
				}
				return $result;
			}
			CakeLog::write('debug', "The request does not have the '{$name}' header.");
		}

		return parent::getUser($request);
	}
}

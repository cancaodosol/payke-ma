<?php

App::uses('AccessTokenRepository', 'Model/Repository');
App::uses('Component', 'Controller');

/**
 * ResourceServer Component class
 *
 * @property PsrHttpComponent $PsrHttp
 * @link https://book.cakephp.org/2/ja/controllers/components.html#creating-a-component
 */
class ResourceServerComponent extends Component {

/**
 * このコンポーネントが使用する他のコンポーネント。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/controllers/components.html#id8
 */
	public $components = [
		'PsrHttp',
	];

/**
 * @var \League\OAuth2\Server\ResourceServer
 */
	public $server;

/**
 * Controller::beforeFilter() の前に呼ばれる。
 *
 * @param Controller $controller コントローラ
 * @return void
 * @throws UnauthorizedException
 * @link https://book.cakephp.org/2/ja/controllers/components.html#Component::initialize
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);

		$this->_setupServer();

		$this->PsrHttp->initialize($controller);

		$this->validateAuthorized();
	}

/**
 * リソースサーバをセットアップする。
 *
 * @return void
 */
	protected function _setupServer() {
		// Init our repository
		$accessTokenRepository = new AccessTokenRepository();

		// Authorization server's public key
		$publicKey = ClassRegistry::init('CryptKey')->field('key', [
			'name' => 'auth.public',
		]);

		// Setup the authorization server
		$this->server = new \League\OAuth2\Server\ResourceServer(
			$accessTokenRepository,
			$publicKey
		);
	}

/**
 * 認可されているかを検証する。
 *
 * @throws UnauthorizedException
 * @link https://github.com/laravel/passport/blob/425c4054c47eab1c1ab6ba2ece08797257d42b27/src/Http/Middleware/CheckClientCredentials.php#L41
 */
	public function validateAuthorized() {
		try {
			$this->server->validateAuthenticatedRequest($this->PsrHttp->request);
		} catch (\League\OAuth2\Server\Exception\OAuthServerException $e) {
			$this->log($e->getHint());
			if ($e->getPrevious()) {
				$this->log($e->getPrevious()->getMessage());
			}
			throw new UnauthorizedException($e->getMessage());
		}
	}
}

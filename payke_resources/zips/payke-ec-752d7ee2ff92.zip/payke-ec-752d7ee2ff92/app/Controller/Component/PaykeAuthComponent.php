<?php

App::uses('AuthComponent', 'Controller/Component');
App::uses('RateLimiter', 'Cache');
App::uses('TooManyRequestsException', 'Lib/Error');

/**
 * Payke Auth Component class
 *
 * @link https://book.cakephp.org/2/ja/controllers/components.html#configuring-components
 * @link https://github.com/laravel/breeze/blob/1.x/stubs/default/app/Http/Requests/Auth/LoginRequest.php
 * @link https://github.com/laravel/ui/blob/4.x/auth-backend/AuthenticatesUsers.php
 */
class PaykeAuthComponent extends AuthComponent {

/**
 * 初期化する。
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);

		$this->limiter = new RateLimiter();
	}

// login() メソッドから呼ばれる identify() メソッドをオーバーライド
/**
 * 設定されている認証オブジェクトを使い、リクエストに含まれる認証情報でユーザーの特定を試みる。
 *
 * @param CakeRequest $request 認証データを含むリクエスト
 * @param CakeResponse $response レスポンス
 * @return array|bool ユーザーレコードデータ、または特定できなかった場合は false
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#AuthComponent::identify
 */
	public function identify(CakeRequest $request, CakeResponse $response) {
		$key = $this->throttleKey();

		if ($this->limiter->tooManyAttempts($key, 5)) { // 試行数が多過ぎる
			$seconds = $this->limiter->availableIn($key); // 再アクセス可になるまでの秒数
			$this->log("Available in {$seconds} seconds", 'debug');
			$message = __('Too many login attempts. Please try again later.');
			throw new TooManyRequestsException($message);
		}

		$result = parent::identify($request, $response); // 認証
		if (! $result) { // 認証失敗
			$this->limiter->hit($key); // 試行数を更新
			return false;
		}

		$this->limiter->clear($key); // 試行数をリセット、タイマーをクリア

		return $result;
	}

/**
 * リクエストに対するレート制限のスロットルキーを作成して返す。
 *
 * @return string スロットルキー（例: "メールアドレス|IPアドレス"）
 */
	protected function throttleKey(): string {
		$id = mb_strtolower($this->loginId(), 'UTF-8'); // ログインID
		$ip = $this->request->clientIp(false); // クライアントIP
		return "{$id}|{$ip}";
	}

/**
 * ログインIDを取得する。
 *
 * @return string メールアドレスまたはユーザー名
 */
	protected function loginId() {
		$results = Hash::extract($this->request->data, '{*}.username');
		if (empty($results)) {
			$results = Hash::extract($this->request->data, '{*}.email');
		}
		$loginId = $results[0];
		return $loginId;
	}
}

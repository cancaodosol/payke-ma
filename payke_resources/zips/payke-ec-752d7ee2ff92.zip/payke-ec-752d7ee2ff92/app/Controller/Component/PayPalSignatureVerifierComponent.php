<?php
App::uses('ApiErrorException', 'Lib/Error');
App::uses('CakeRequest', 'Network');
App::uses('ClassRegistry', 'Utility');
App::uses('Component', 'Controller');

/**
 * PayPalSignatureVerifier Component class
 *
 * @link https://book.cakephp.org/2/ja/controllers/components.html#creating-a-component
 */
class PayPalSignatureVerifierComponent extends Component {

/**
 * @var CakeRequest
 */
	public $request;

/**
 * Controller::beforeFilter() の後、アクションの前に呼ばれる。
 *
 * @param Controller $controller コントローラ
 * @return void
 * @throws UnauthorizedException
 * @link https://book.cakephp.org/2/ja/controllers/components.html#Component::startup
 */
	public function startup(Controller $controller) {
		parent::startup($controller);

		$this->request = $controller->request;

		$this->_verifySignature();
	}

/**
 * 署名を検証する。
 *
 * @return void
 * @throws UnauthorizedException
 * @link https://developer.paypal.com/docs/api/webhooks/v1/#verify-webhook-signature_post
 */
	protected function _verifySignature() {
		$config = ClassRegistry::init('Config');
		$webhookId = $config->get('paypal_webhook_id'); // API設定の Webhook ID

		$data['auth_algo'] = CakeRequest::header('PAYPAL-AUTH-ALGO');
		$data['cert_url'] = CakeRequest::header('PAYPAL-CERT-URL');
		$data['transmission_id'] = CakeRequest::header('PAYPAL-TRANSMISSION-ID');
		$data['transmission_sig'] = CakeRequest::header('PAYPAL-TRANSMISSION-SIG');
		$data['transmission_time'] = CakeRequest::header('PAYPAL-TRANSMISSION-TIME');
		$data['webhook_id'] = $webhookId;
		$data['webhook_event'] = $this->request->data;

		$Notification = ClassRegistry::init('PayPalNotification');
		try {
			$Notification->verifyWebhookSignature($data); // PayPalへ検証を依頼
		} catch (ApiErrorException $e) {
			throw new UnauthorizedException($e->getMessage());
		}
	}
}

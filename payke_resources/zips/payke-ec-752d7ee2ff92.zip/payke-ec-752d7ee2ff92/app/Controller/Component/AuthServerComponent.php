<?php

App::uses('AccessTokenRepository', 'Model/Repository');
App::uses('CakeResponse', 'Network');
App::uses('ClientRepository', 'Model/Repository');
App::uses('Component', 'Controller');
App::uses('ScopeRepository', 'Model/Repository');

/**
 * AuthServer Component class
 *
 * @property PsrHttpComponent $PsrHttp
 * @link https://book.cakephp.org/2/ja/controllers/components.html#creating-a-component
 */
class AuthServerComponent extends Component {

/**
 * このコンポーネントが使用する他のコンポーネント。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/controllers/components.html#id8
 */
	public $components = [
		'PsrHttp',
	];

/**
 * @var \League\OAuth2\Server\AuthorizationServer
 */
	public $server;

/**
 * Controller::beforeFilter() の前に呼ばれる。
 *
 * @param Controller $controller コントローラ
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers/components.html#Component::initialize
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);

		$this->_setupServer();

		$this->PsrHttp->initialize($controller);
	}

/**
 * 認可サーバをセットアップする。
 *
 * @return void
 * @link https://github.com/laravel/passport/blob/425c4054c47eab1c1ab6ba2ece08797257d42b27/src/PassportServiceProvider.php#L96
 */
	protected function _setupServer() {
		// Init our repositories
		$clientRepository = new ClientRepository();
		$accessTokenRepository = new AccessTokenRepository();
		$scopeRepository = new ScopeRepository();

		// public and private keys
		$privateKey = ClassRegistry::init('CryptKey')->field('key', [
			'name' => 'auth.private',
		]);

		// encryption key
		$encryptionKey = ClassRegistry::init('CryptKey')->field('key', [
			'name' => 'auth.encryption',
		]);
		$encryptionKey = \Defuse\Crypto\Key::loadFromAsciiSafeString($encryptionKey);

		// Setup the authorization server
		$this->server = new \League\OAuth2\Server\AuthorizationServer(
			$clientRepository,
			$accessTokenRepository,
			$scopeRepository,
			$privateKey,
			$encryptionKey
		);

		// Enable the client credentials grant on the server
		$this->server->enableGrantType(
			new \League\OAuth2\Server\Grant\ClientCredentialsGrant(),
			new DateInterval(Configure::read('auth.client.token.duration'))
		);
	}

/**
 * アクセストークンを発行する。
 *
 * @return CakeResponse
 * @link https://github.com/laravel/passport/blob/425c4054c47eab1c1ab6ba2ece08797257d42b27/src/Http/Controllers/AccessTokenController.php#L59
 */
	public function issueToken(): CakeResponse {
		try {
			$this->server->respondToAccessTokenRequest(
				$this->PsrHttp->request,
				$this->PsrHttp->response
			);
		} catch (\League\OAuth2\Server\Exception\OAuthServerException $e) {
			$this->PsrHttp->response = $e->generateHttpResponse($this->PsrHttp->response);
		}

		return $this->PsrHttp->convertResponse();
	}
}

<?php

App::uses('ClassRegistry', 'Utility');
App::uses('Component', 'Controller');
App::uses('OrderItem', 'Model');

/**
 * CartManager Component class
 */
class CartManagerComponent extends Component {

/**
 * {@inheritdoc}
 */
	public $components = array(
		'Flash',
		'AffiliateDetector',
		'AccessLogger',
	);

/**
 * Initializes CartManagerComponent for use in the controller.
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);
		$this->Controller = $controller;
		$this->request = $controller->request;
		$this->Order = $controller->Order;
		$this->PaymentPlan = $controller->Order->PaymentPlan;
		$this->Product = $controller->Order->Product;
	}

/**
 * カートに商品を入れる。
 *
 * @param string $slug スラッグ
 * @return void
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function add($slug) {
		$conditions = ['Product.parent_id' => null];
		if (isset($slug)) {
			$this->log('Using slug', 'debug');
			$conditions['Product.slug'] = $slug;
		} elseif ($this->request->query('product_id')) { // この形式も従来通り受け付ける
			$this->log('Using product_id', 'debug');
			$conditions['Product.id'] = $this->request->query('product_id');
		} else {
			throw new BadRequestException(__('Invalid product'));
		}
		$result = $this->Product->find('first', [
			'conditions' => $conditions,
			'contain' => ['Item' => ['fields' => ['id']]],
			'fields' => ['id', 'affiliate_object'],
		]);
		if (!$result) {
			throw new NotFoundException(__('Invalid product'));
		}
		$productId = $result['Product']['id'];

		// 紹介者
		$this->AffiliateDetector->initialize($this->Controller);
		$affiliateId = $this->AffiliateDetector->detect();
		$this->log(compact('affiliateId'), 'debug');

		// アクセスログ
		$this->AccessLogger->initialize($this->Controller);
		$this->AccessLogger->record($productId, $affiliateId);

		$this->request->data['Order']['product_id'] = $productId;
		if (empty($result['Item'])) {
			$this->request->data['Order']['quantity'] = 1; // 数量デフォルト値
		} else {
			foreach ($result['Item'] as $i => $item) {
				$this->request->data['OrderItem'][$i]['product_id'] = $item['id'];
				$this->request->data['OrderItem'][$i]['quantity'] = OrderItem::QUANTITY_DEFAULT;
			}
		}

		// アフィリエイトであればアフィリエイト成果の作成を準備
		if ($result['Product']['affiliate_object'] && $affiliateId) {
			$this->request->data('AffiliateResult.0.affiliate_id', $affiliateId);
		}

		for ($n = 1; $n <= 5; $n++) {
			$this->request->data['Order']["arg{$n}"] = $this->request->query("arg{$n}"); // 追加パラメータ
		}
	}

/**
 * 商品の情報を読み込む。
 *
 * @return void
 * @throws NotFoundException
 */
	public function loadProduct() {
		$this->Product->addVirtualFields(['price', 'base_price']);
		$this->Product->Item->addVirtualFields(['price', 'base_price']);
		$result = $this->Product->find('first', [
			'conditions' => [
				'Product.id' => $this->request->data['Order']['product_id'],
			],
			'contain' => [
				'Item' => [
					'fields' => ['id', 'name', 'price', 'base_price', 'is_tax_reduced'],
					'ProductOption' => ['fields' => ['not_accepted']],
				],
			],
			'fields' => [
				'name', 'price', 'base_price', 'is_tax_reduced', 'can_order_only_once', 'message_for_unorderable',
				'purchase_type','affiliate_object', 'affiliate_type', 'affiliate_rate',
			],
		]);
		if (!$result) {
			throw new NotFoundException(__('Invalid product'));
		}

		$this->request->data['Order']['name'] = $result['Product']['name'];
		$this->request->data['Order']['price'] = $result['Product']['price'];
		$this->request->data['Order']['base_price'] = $result['Product']['base_price'];
		$this->request->data['Order']['is_tax_reduced'] = $result['Product']['is_tax_reduced'];
		$this->request->data['Product']['can_order_only_once'] = $result['Product']['can_order_only_once'];
		$this->request->data['Product']['message_for_unorderable'] = $result['Product']['message_for_unorderable'];
		$this->request->data['Product']['purchase_type'] = $result['Product']['purchase_type'];
		$this->request->data['Product']['affiliate_object'] = $result['Product']['affiliate_object'];
		$this->request->data['Product']['affiliate_type'] = $result['Product']['affiliate_type'];
		$this->request->data['Product']['affiliate_rate'] = $result['Product']['affiliate_rate'];

		$orderItems = $this->request->data('OrderItem');
		foreach ($result['Item'] as $i => $item) {
			$orderItem = my_array_search($orderItems, ['product_id' => $item['id']]);
			if ($orderItem) {
				if (isset($orderItem['id'])) {
					$this->request->data['OrderItem'][$i]['id'] = $orderItem['id'];
				}
				$this->request->data['OrderItem'][$i]['quantity'] = $orderItem['quantity'];
			} else {
				$this->request->data['OrderItem'][$i]['quantity'] = OrderItem::QUANTITY_DEFAULT;
			}
			$this->request->data['OrderItem'][$i]['product_id'] = $item['id'];
			$this->request->data['OrderItem'][$i]['product_option_id'] = $item['ProductOption'][0]['id'];
			$this->request->data['OrderItem'][$i]['name'] = $item['name'];
			$this->request->data['OrderItem'][$i]['price'] = $item['price'];
			$this->request->data['OrderItem'][$i]['base_price'] = $item['base_price'];
			$this->request->data['OrderItem'][$i]['is_tax_reduced'] = $item['is_tax_reduced'];
			$this->request->data['OrderItem'][$i]['ProductOption'] = $item['ProductOption'];
		}
	}

/**
 * 金額を計算する。
 *
 * @return void
 */
	public function calculate() {
		if (empty($this->request->data['OrderItem'])) {
			$quantity = intval($this->request->data['Order']['quantity']);
			$amount = intval($this->request->data['Order']['price']) * $quantity;
			$baseAmount = intval($this->request->data['Order']['base_price']) * $quantity;
			$this->request->data['Order']['amount'] = $amount;
			$this->request->data['Order']['base_amount'] = $baseAmount;
			$this->request->data['Order']['tax_amount'] = $amount - $baseAmount;
		} else {
			$totalAmount = 0;
			$totalBaseAmount = 0;
			foreach ($this->request->data['OrderItem'] as $i => $item) {
				$quantity = intval($item['quantity']);
				$totalAmount += $amount = intval($item['price']) * $quantity;
				$totalBaseAmount += $baseAmount = intval($item['base_price']) * $quantity;
				$this->request->data['OrderItem'][$i]['amount'] = $amount;
				$this->request->data['OrderItem'][$i]['base_amount'] = $baseAmount;
				$this->request->data['OrderItem'][$i]['tax_amount'] = $amount - $baseAmount;
			}
			$this->request->data['Order']['amount'] = $totalAmount;
			$this->request->data['Order']['base_amount'] = $totalBaseAmount;
			$this->request->data['Order']['tax_amount'] = $totalAmount - $totalBaseAmount;
		}
	}

/**
 * 選択された支払いプランをもとに、注文リクエストデータの支払い関連の属性値を更新する。
 * - initial_fee
 * - amount_per_cycle
 * - payment_cycles
 * - payment_method_id
 *
 * orders.amount_per_cycle は以下の箇所で使用される。
 * - confirm.ctp
 *   - 注文フォームでUnivaPay継続支払いが選択された場合のUnivaPayボタン作成時に指定する金額
 * - AmazonPayCheckoutSession クラス
 *   - 注文フォームでAmazon Payボタン作成時に指定する金額
 * - AmazonPayCharge クラス
 *   - Amazon Pay継続支払いの2回目以降の課金の金額
 * - DueDataTask クラス
 *   - 銀行振込の入金予定の金額
 * - Order クラス
 *   - 注文フォームでの確定時、注文編集ページでの更新時に作成する入金の金額
 * - OrderEmailSender クラス
 *   - 注文関連メールの差込変数 amount_per_cycle の値
 *   - 銀行振込の支払い一覧で各回の金額
 *   - Amazon Pay継続支払いを顧客が解除したときの未入金の額
 *   - 初回支払額（初期費用+各回の金額）を求めるとき
 *
 * @return void
 * @throws NotFoundException
 */
	public function setPaymentDetails() {
		$paymentPlanId = $this->request->data('Order.payment_plan_id'); // 選択されたプラン
		if (empty($paymentPlanId)) {
			return;
		}

		// 支払プランを取得
		$result = $this->PaymentPlan->find('forDetail', [
			'conditions' => ['PaymentPlan.id' => $paymentPlanId],
		]);
		if (empty($result)) {
			throw new NotFoundException(__('Invalid payment plan'));
		}

		if ($this->PaymentPlan->isRecurring($result['PaymentPlan'])) { // 分割払い/継続払いの場合
			$details = $this->PaymentPlan->detail($result); // PaymentPlanや参照モデルから詳細を取得

			$unitPrice = Hash::get($details, 'regular.price.value'); // 単価
			$cycles = Hash::get($details, 'regular.cycles'); // 支払い回数
			$quantitySupported = $details['quantity_supported']; // 数量指定に対応しているか
			$quantity = intval($this->request->data('Order.quantity')); // 数量

			if (empty($unitPrice)) { // 支払いプランの単価が設定されていない場合
				$amount = intval($this->request->data('Order.amount')); // 総額
				$initialFee = intval($result['PaymentPlan']['initial_fee']); // 初期費用
				$amountPerCycle = 1 < $cycles
					? floor(($amount - $initialFee) / $cycles) // 分割払いの場合
					: $amount; // 継続払いの場合
			} elseif (1 < $quantity && $quantitySupported) { // 単価が固定、かつ、数量に応じた金額にする場合
				$amountPerCycle = $unitPrice * $quantity; // 単価 * 数量
			} else { // 上記以外
				$amountPerCycle = $unitPrice; // 単価
			}
		} else { // 上記以外
			$amountPerCycle = $this->request->data('Order.amount'); // 支払い各回の金額
			$cycles = $result['PaymentPlan']['cycles']; // 支払い回数
		}

		// これらの値は毎回選択された支払い方法に応じて値を更新する
		$this->request->data('Order.initial_fee', $result['PaymentPlan']['initial_fee']); // 初期費用
		$this->request->data('Order.amount_per_cycle', $amountPerCycle); // 支払い各回の金額
		$this->request->data('Order.payment_cycles', $cycles); // 支払い回数
		$this->request->data('Order.payment_method_id', $result['PaymentPlan']['payment_method_id']);
		// TODO: 以下も注文時点の値を保存すべきではないか
		// $this->request->data('Order.frequency', 間隔);
		// $this->request->data('Order.quantity_supported', 数量指定に対応しているか);
	}

/**
 * 購入に必要なデータを読み込む。
 *
 * @param bool $editable 変更可
 * @return void
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function loadPurchaseData(bool $editable = false) {
		if (empty($this->request->data['Order']['product_id'])) {
			throw new BadRequestException(__('Invalid product'));
		}
		$product = $this->Product->find('first', [
			'conditions' => [
				'Product.id' => $this->request->data('Order.product_id'),
			],
			'contain' => [
				'CustomField' => [
					'conditions' => [
						'fieldable_type' => 'Product',
						'displayed' => true,
					],
					'fields' => [
						'id', 'name', 'required', 'label', 'type', 'options',
						'col_size', 'row_size', 'note', 'fixed',
					],
				],
				'ProductOption',
				'SctaNotation' => [ // 特定商取引法に基づく表記
					'fields' => [
						'id',
						'delivery_method_and_time', // 商品引渡し方法と時期
						'retun_reject_cancellation_notes', // 返品・不良品・キャンセルについて
						'subscription_cancellation_notes', // 定期購入契約の解約等についての注意事項
					],
				],
			],
		]);
		if (!$product) {
			throw new NotFoundException(__('Invalid product'));
		}

		if ($product['Product']['discontinued']) {
			$this->Flash->error(__('This product became discontinued.'));
			$this->set('formDisabled', true);
		} elseif (!$onSale = $this->Product->isOnSale($product)) {
			$this->Flash->error(__('Product is NOT on sale.'));
			$this->set('formDisabled', true);
		}

		// 商品
		$this->set('product', $product['Product']);

		// 商品オプション
		$this->set('productOptionsCount', count($product['ProductOption']));
		if (is_order_status_booked($this->request->data('Order.status'))) { // 予約済の場合
			$productOptions = $product['ProductOption'];
		} else { // 上記以外の場合
			$productOptions = Hash::extract($product['ProductOption'], '{n}[hidden!=true]'); // 表示するものに絞る
		}
		$productOptions = Hash::combine($productOptions, '{n}.id', '{n}.name');
		$this->set('productOptions', $productOptions);
		$disabledProductOptionIds = Hash::extract($product['ProductOption'], '{n}[not_accepted=true].id');
		$this->set('disabledProductOptionIds', $disabledProductOptionIds);

		if (boolval($product['Product']['booking_needed']) && $this->isStatusEmpty()) {
			$this->set('booking', true); // 予約時
			$this->_setOrderDeadline($product); // 申し込み締め切り日時をセット
		} else {
			$this->set('booking', false); // 決済時
			if ($editable) {
				$this->_setPaymentPlans(); // 支払プラン一覧をセット
			}
		}

		$this->_setCustomFields($product, $editable); // 注文フォーム入力項目

		$this->set('sctaNotation', $product['SctaNotation']); // 特定商取引法に基づく表記

		// アフィリエイト
		if ($affiliateId = $this->request->data('AffiliateResult.0.affiliate_id')) {
			if ($product['Product']['affiliate_object']) { // アフィリエイト対象
				$affiliateMessage = $this->Product->AffiliateItem->field('message_on_page', [
					'affiliate_id' => $affiliateId,
					'product_id' => $this->request->data('Order.product_id'),
				]);
				$this->set('affiliateMessage', $affiliateMessage);
			} else {
				unset($this->request->data['AffiliateResult']);
			}
		}
	}

/**
 * 申し込み締め切り日時をセットする。
 *
 * @param array $product 商品情報
 * @return void
 * @throws BadRequestException 申し込み締め切り日時を過ぎている場合
 */
	protected function _setOrderDeadline(array $product) {
		if (boolval($product['Product']['is_deadline_relative'])) { // 相対指定
			$days = intval($product['Product']['days_until_deadline']); // 予約日後の日数
			$date = today()->addDays($days)->endOfDay()->toDateTimeString();
		} else {
			$date = $product['Product']['order_deadline']; // 日時
			if (is_datetime_past($date)) { // 申し込み締め切り日時を過ぎている
				throw new BadRequestException(__('The product order deadline has expired.'));
			}
		}
		$this->request->data['Order']['order_deadline'] = $date;
	}

/**
 * 支払プラン一覧をセットする。
 *
 * @return void
 */
	protected function _setPaymentPlans() {
		$paymentPlans = $this->PaymentPlan->find('forOrderForm', [
			'conditions' => [
				'PaymentPlan.product_id' => $this->request->data('Order.product_id'),
			],
		]);
		if (0 < count($paymentPlans)) {
			sort_payment_plans_for_order_form($paymentPlans); // 表示順でソート
			if (empty($this->request->data('Order.payment_plan_id'))) { // 支払プランが未選択
				// 最初のプランを初期選択値としてセット
				$this->request->data('Order.payment_plan_id', $paymentPlans[0]['id']);
			}
		}
		$this->set('paymentPlans', $paymentPlans);
	}

/**
 * 注文フォーム入力項目をセットする。
 *
 * @param array $product
 * @param bool $editable 変更可
 * @return void
 */
	protected function _setCustomFields(array $product, bool $editable) {
		$customFields = $product['CustomField'];

		// 支払い方法によって追加項目があれば追加
		$vars = $this->Controller->viewVars;
		$paymentMethodIds = $editable
			? Hash::extract($vars, 'paymentPlans.{n}.payment_method_id')
			: (array) $this->request->data('PaymentPlan.payment_method_id');
		if (!empty($paymentMethodIds)) {
			$paymentMethodIds = array_unique($paymentMethodIds);
			$baseFieldNames = array_column($customFields, 'name');

			// 支払い方法別の追加項目
			$EXTRA_FIELD_NAMES = [
				// Paidyは住所が必要 https://paidy.com/docs/jp/paidycheckout.html#section-1
				PE_PAYMENT_METHOD_PAIDY => [
					'customer_zip_code',
					'customer_prefecture',
					'customer_address',
				],
			];

			// 追加項目名の一覧を作成
			$extraFieldNames = [];
			foreach ($paymentMethodIds as $paymentMethodId) {
				if (empty($EXTRA_FIELD_NAMES[$paymentMethodId])) {
					continue;
				}
				$fieldNames = $EXTRA_FIELD_NAMES[$paymentMethodId];
				$fieldNames = array_diff($fieldNames, $baseFieldNames);
				if (empty($fieldNames)) {
					continue;
				}
				$fieldNames = array_fill_keys($fieldNames, [$paymentMethodId]);
				$extraFieldNames = array_merge_recursive($extraFieldNames, $fieldNames);
			}

			if (!empty($extraFieldNames)) {
				// 追加項目を作成
				$names = array_keys($extraFieldNames);
				$extraFields = $this->Product->CustomField->defaultFields($names);
				foreach ($extraFields as &$field) {
					$paymentMethodIds = $extraFieldNames[$field['name']];
					$field['present_if']['payment_method_id'] = $paymentMethodIds;
				}

				// 追加
				$customFields = array_merge($customFields, $extraFields);
			}
		}

		$this->set('customFields', $customFields);
	}

/**
 * 在庫チェックする。
 *
 * @return void
 */
	public function checkInStock() {
		if (empty($this->request->data['OrderItem'])) {
			$this->Order->set($this->request->data);
			if (!$this->Order->validates(array('fieldList' => array('quantity')))) {
				foreach ($this->Order->validationErrors as $modelName => $fields) {
					foreach ($fields as $fieldName => $message) {
						$this->Flash->error($message);
						$this->set('formDisabled', true);
					}
				}
			}
		} else {
			$productIds = Hash::extract($this->request->data, 'OrderItem.{n}.product_id');
			$count = $this->Product->ProductOption->countAvailable($productIds);
			if ($count === 0) {
				$this->Flash->error(__('inStock'));
				$this->set('formDisabled', true);
			}
		}
	}

/**
 * 注文情報を読み込む。
 *
 * これで取得したデータを saveAssociated や saveMany へ安易に渡さないよう注意。
 * もし渡す場合は、一緒に更新するとまずいデータを除去してから渡すこと。
 *
 * @param string|null $uuid UUID
 * @return array
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function loadOrder($uuid = null) {
		if ($uuid) {
			$conditions = ['Order.uuid' => $uuid];
		} else {
			throw new BadRequestException('Invalid order');
		}

		// 注文を取得
		$result = $this->Order->find('first', array(
			'conditions' => $conditions,
			'contain' => array(
				'AffiliateResult' => array(
					'fields' => array('id', 'affiliate_id', 'payment_no', 'name', 'reward'),
				),
				'Product' => array(
					'affiliate_object', 'affiliate_type', 'purchase_type', 'affiliate_rate'
				),
				// TODO: 必要なカラムだけに絞る
				'CustomFieldValue',
				'OrderItem',
				'PaymentPlan' => [
					'PaymentMethod',
					'PayPalBillingPlan', // Order::checkout() で使っている
				]
			),
		));
		if (empty($result)) {
			throw new NotFoundException(__('Invalid order'));
		}

		$this->PaymentPlan->addDetailsTo($result['PaymentPlan']); // プラン詳細を追加

		// 最新の注文状況をチェックし、リクエストデータへセット
		$status = $result['Order']['status'];
		if (is_null($status)) { // 未注文
			;
		} elseif (is_order_status_booked($status)) { // 予約済
			if (Order::isDeadlinePast($result)) { // 注文期限を過ぎた
				throw new BadRequestException(__('The order deadline has expired.'));
			}
		} elseif (is_order_status_canceled($status)) { // キャンセル
			$message = __('This order was canceled.');
			if (boolval($result['Order']['auto_canceled'])) { // 自動キャンセル
				$message = __('This order was canceled because the deadline for order passed.');
			}
			$this->Flash->error($message);
			$this->set('formDisabled', true);
		} else { // 上記以外
			throw new BadRequestException(__('Invalid status'));
		}
		$this->request->data('Order.status', $status);

		return $result;
	}

/**
 * 決済サービスでチェックアウトされてリダイレクトで戻ってきたかどうかを調べる。
 * チェックアウトセッションを特定するクエリーパラメータがあれば、注文へ保存していた値と照合する。
 *
 * @param array $order 注文データ
 * @return void
 * @see Order::checkout()
 */
	public function detectCheckout(array $order) {
		if (
			$this->request->query('session_id') &&
			$this->request->query('session_id') === $order['Order']['checkout_session_id']
		) { // Stripe Checkout からのリダイレクト
			$result = $this->_confirmStripeCheckout($order);
		} elseif (
			$this->request->query('success') === 'true' &&
			$this->request->query('token') &&
			$this->request->query('token') === $order['Order']['checkout_session_id']
		) { // PayPal からのリダイレクト
			if ($paymentId = $this->request->query('paymentId')) { // 1回払いの場合
				$payerId = $this->request->query('PayerID');
				// state や PayerID をチェック
				$model = ClassRegistry::init('PayPalPayment');
				$model->id = $paymentId;
				$results = $model->get();
				if (
					$results &&
					$results['state'] !== 'failed' &&
					$results['payer']['payer_info']['payer_id'] === $payerId
				) {
					$this->set('checkedOut', true);
				}
			} elseif ($baToken = $this->request->query('ba_token')) { // 定期支払い(旧)の場合
				// NOTE: チェックする方法が無さそう。
				// 決済せずURL直打ちで不正にアクセスされても、確定処理で `Token is invalid.` エラーになる。
				$this->set('checkedOut', true);
			}
		} elseif ($this->request->query('amazonCheckoutSessionId')) { // Amazon Pay からのリダイレクト
			$result = $this->_completeAmazonPayCheckoutSession($order);
		}
	}

/**
 * Stripe Checkout からのリダイレクトを処理する。
 *
 * @param array $data 注文データ
 * @return bool|null
 * @link https://stripe.com/docs/api/subscription_schedules/create#create_subscription_schedule-from_subscription
 * @link https://stripe.com/docs/api/subscription_schedules/update#update_subscription_schedule-phases-iterations
 */
	protected function _confirmStripeCheckout(array $data) {
		// チェックアウトセッションを取得
		$CheckoutSession = ClassRegistry::init('StripeCheckoutSession');
		$session = $CheckoutSession->read(null, $data['Order']['checkout_session_id']);

		// 支払い状況等を確認
		if (!$CheckoutSession->isStatusComplete()) {
			$this->log('Stripe checkout session NOT complete', 'warning');
			return;
		}
		if (!$CheckoutSession->isPaymentStatusPaid()) {
			$this->log('Stripe checkout session NOT paid', 'warning');
			return;
		}
		$this->set('checkedOut', true);
		$this->set('confirmed', true);

		// 注文へセットする Reference ID を取得
		$referenceId = $session[$CheckoutSession->alias]['payment_intent']
			?: $session[$CheckoutSession->alias]['subscription'];
		$this->request->data('Order.reference_id', $referenceId);

		// 分割払いは、サブスクリプションスケジュールへ移行してイテレーションとして回数を設定することで実現
		if ($CheckoutSession->isModeSubscription()) {
			$cycles = intval($data['Order']['payment_cycles']);
			if (0 < $cycles) {
				// サブスクリプションスケジュールを作成
				$SubscriptionSchedule = ClassRegistry::init('StripeSubscriptionSchedule');
				$SubscriptionSchedule->create();
				$saved = $SubscriptionSchedule->save([
					$SubscriptionSchedule->alias => ['from_subscription' => $referenceId],
				], ['atomic' => false, 'validate' => false]);
				if (!$saved) {
					$this->log('Failed to migrate to subscription schedule.', 'error');
					$this->Flash->error(__('Error') . " (Failed to migrate to subscription schedule)");
					return false;
				}
				// サブスクリプションスケジュールを更新（イテレーションを設定）
				$phases = [];
				foreach ($saved[$SubscriptionSchedule->alias]['phases'] as &$phase) {
					if (!empty($phase['trial'])) { // 無料トライアル期間（0または1つのはず）
						unset($phase['trial']); // エラー `You may only specify one of these parameters: trial, trial_end.` を回避するため
					} else { // 購読期間（1つのはず）
						unset($phase['end_date']); // 終了日時を除去
						$phase['iterations'] = $cycles; // イテレーションとして回数を設定
					}
					$phases[] = Hash::filter($phase); // 値が空のパラメータを除去
				}
				$saved = $SubscriptionSchedule->save([
					$SubscriptionSchedule->alias => [
						'end_behavior' => 'cancel', 'phases' => $phases,
					],
				], ['atomic' => false, 'validate' => false]);
				if (!$saved) {
					$this->log('Failed to update subscription schedule.', 'error');
					$this->Flash->error(__('Error') . " (Failed to update subscription schedule)");
					return false;
				}
			}
		}

		return true;
	}

/**
 * Amazon PayのCheckout Sessionを完了させる。
 *
 * @param array $data 注文データ
 * @return array|bool
 * @link https://developer.amazon.com/ja/docs/amazon-pay-apb-checkout/verify-and-complete-checkout.html
 * @link https://github.com/amazonpay-labs/amazonpay-cv2-php-sample/blob/main/php/result_return_apb.php
 */
	protected function _completeAmazonPayCheckoutSession(array $data) {
		$checkoutSessionId = $this->request->query('amazonCheckoutSessionId');
		// TODO: $dataが持つセッションIDと一致するかもチェックすべき？

		$payload = [
			'chargeAmount' => [
				'amount' => $this->Order::initialAmount($data),
				'currencyCode' => CURRENCY_DEFAULT,
			],
		];

		App::uses('ApiErrorException', 'Lib/Error');
		$AmazonPayCheckoutSession = ClassRegistry::init('AmazonPayCheckoutSession');
		$AmazonPayCheckoutSession->id = $checkoutSessionId;
		try {
			$result = $AmazonPayCheckoutSession->complete($payload);
		} catch (ApiErrorException $e) {
			$this->Flash->warning(__('Your payment was not successful. Please try another payment method.'));
			return false;
		}

		if (!$AmazonPayCheckoutSession->isCompleted()) {
			$this->Flash->error($AmazonPayCheckoutSession->getReasonDescription());
			return false;
		}

		$chargePermissionId = $result[$AmazonPayCheckoutSession->alias]['chargePermissionId'];
		$chargeId = $result[$AmazonPayCheckoutSession->alias]['chargeId'];
		$paidDate = $AmazonPayCheckoutSession->getLastUpdatedTimestamp()->toDateTimeString();
		App::uses('AmazonPayChargePermission', 'Model');

		$this->request->data('Order.checkout_session_id', $checkoutSessionId); // 使わないかもしれないが念のため保持
		$this->request->data('Order.reference_id', $chargePermissionId);
		$this->request->data('Order.paid_date', $paidDate);
		$this->request->data('OrderReference.id', $chargePermissionId);
		$this->request->data('OrderReference.type', 'AmazonPayChargePermission');
		$this->request->data('OrderReference.state', AmazonPayChargePermission::STATE_CHARGEABLE);
		$this->request->data('Payment.0.reference_id', $chargeId);
		$this->request->data('Payment.0.paid_date', $paidDate);
		$this->set('checkedOut', true);
		$this->set('confirmed', true);

		return $result;
	}

/**
 * リクエストデータの注文状況が空(NULL)かどうか。
 *
 * @return bool
 */
	public function isStatusEmpty() {
		return is_null($this->request->data('Order.status'));
	}

/**
 * ビューテンプレートで使用する変数を保存するため、コントローラの set を呼ぶ。
 *
 * @param string|array $one A string or an array of data.
 * @param mixed $two Value in case $one is a string (which then works as the key).
 *   Unused if $one is an associative array, otherwise serves as the values to $one's keys.
 * @return void
 */
	public function set($one, $two = null) {
		$this->Controller->set($one, $two);
	}

/**
 * 注文確定後のリダイレクト先を判断して返す。
 *
 * @param array $data 注文データ
 * @return array|string
 */
	public function redirectUrl(array $data) {
		// 商品のリダイレクト設定を取得
		$this->Product->id = $data['Order']['product_id'];
		$settings = $this->Product->redirectSettings(Hash::get($data, 'PaymentPlan.PaymentMethod'));
		if ($settings['type'] == PE_REDIRECT_TYPE_EXTERNAL) { // 外部へリダイレクト
			$url = $settings['url']; // リダイレクト先URL

			// クエリーパラメータ
			$params = [];
			// 注文フォームに渡されていた arg1 - arg5 パラメータがあればリダイレクト先にも渡す
			foreach ($data['Order'] as $name => $value) {
				if (substr($name, 0, 3) === 'arg') {
					$params[$name] = $value;
				}
			}
			if ($settings['withParams']) { // 注文データをリダイレクト先にも渡す
				$field2param = [
					'id' => 'order_no',
					'product_id' => 'product_id',
					'name' => 'item_name',
					'price' => 'price',
					'quantity' => 'quantity',
					'customer_name' => 'name',
					'customer_email' => 'email',
					'customer_zip_code' => 'zip',
					'customer_address' => 'address',
					'customer_phone' => 'phone',
				];
				foreach ($field2param as $field => $name) {
					$params[$name] = $data['Order'][$field];
				}
			}
			// 値があるものだけに絞る
			$params = array_filter($params, function ($value) {
				return 0 < strlen($value);
			});
			if (!empty($params)) {
				$query = parse_url($url, PHP_URL_QUERY);
				$url = $url . ($query ? '&' : '?') . http_build_query($params);
			}

			return $url;
		} elseif ($settings['type'] == PE_REDIRECT_TYPE_QUESTIONNAIRE) { // アンケート
			$result = $this->Order->QuestionnaireAnswer->find('first', [
				'conditions' => ['QuestionnaireAnswer.order_id' => $data['Order']['id']],
				'contain' => false,
				'fields' => ['uuid'],
			]);
			return [
				'controller' => 'questionnaire_answers',
				'action' => 'edit',
				'uuid' => Hash::get($result, 'QuestionnaireAnswer.uuid'),
			];
		}

		// デフォルトは注文完了ページ
		return [
			'controller' => 'orders',
			'action' => 'complete',
			$data['Order']['id'],
		];
	}
}

<?php

App::uses('Component', 'Controller');

/**
 * AffiliateDetector Component class
 */
class AffiliateDetectorComponent extends Component {

/**
 * Other Components this component uses.
 *
 * @var array
 */
	public $components = [
		'Session',
	];

/**
 * Request object
 *
 * @var CakeRequest
 */
	public $request;

/**
 * Initializes AffiliateDetectorComponent for use in the controller.
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);
		$this->request = $controller->request;
	}

/**
 * リクエストからaidを取得し、該当する紹介者を特定して返す。
 *
 * @return string|null 紹介者のID
 */
	public function detect() {
		$aid = $this->request->query('aid');
		if (!$aid) {
			// クエリーに含まれていない場合は、リファラーのクエリーから取得する
			if ($referer = $this->request->referer()) {
				$this->log('Trying to get the aid from the referer...', 'debug');
				if ($refererQuery = parse_url($referer, PHP_URL_QUERY)) {
					parse_str($refererQuery, $result);
					$aid = isset($result['aid']) ? $result['aid'] : null;
				}
				if (!$aid) {
					// リファラーのクエリーから取得できない場合は、セッションから取得（消費）する
					$this->log('Trying to consume the aid from the session...', 'debug');
					$aid = $this->Session->consume('Affiliate.aid');
				}
			}
		}
		$this->log("aid: {$aid}", 'debug');
		if (isset($aid)) {
			$result = ClassRegistry::init('User')->find('first', [
				'conditions' => [
					'Profile.aid' => $aid, // aidが一致する
					'Profile.affiliate_disabled' => null, // アフィリ停止ではない
				],
				'contain' => ['Profile'],
				'fields' => ['User.id'],
			]);
			return Hash::get($result, 'User.id');
		}
		return;
	}
}

<?php

App::uses('CakeResponse', 'Network');
App::uses('Component', 'Controller');
App::uses('ComponentCollection', 'Controller');

/**
 * PSR HTTP Message Component class
 *
 * @link https://book.cakephp.org/2/ja/controllers/components.html#creating-a-component
 */
class PsrHttpComponent extends Component {

/**
 * PSR-7リクエスト。
 *
 * @var \Psr\Http\Message\ServerRequestInterface
 */
	public $request;

/**
 * PSR-7レスポンス。
 *
 * @var \Psr\Http\Message\ResponseInterface
 */
	public $response;

/**
 * Controller::beforeFilter() の前に呼ばれる。
 *
 * @param Controller $controller コントローラ
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers/components.html#Component::initialize
 * @link https://docs.laminas.dev/laminas-diactoros/v1/usage/#server-side-applications
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);

		// Create a PSR-7 compliant request and response

		$this->request = \Laminas\Diactoros\ServerRequestFactory::fromGlobals();
		$contentType = $this->request->getHeaderLine('Content-Type');
		if (strpos($contentType, 'application/json') !== false) {
			$data = json_decode($this->request->getBody()->getContents());
			$this->request = $this->request->withParsedBody($data);
		}

		$this->response = new \Laminas\Diactoros\Response\JsonResponse(null);
	}

/**
 * PSR-7レスポンスをCakeResponseへ変換する。
 *
 * @return CakeResponse
 */
	public function convertResponse(): CakeResponse {
		$cakeResponse = new CakeResponse([
			'body' => (string) $this->response->getBody(), // ボディの設定
			'statusCodes' => [ // HTTPステータスコード一覧へマージ
				$this->response->getStatusCode() => $this->response->getReasonPhrase(),
			],
			'status' => $this->response->getStatusCode(), // HTTPステータスコードの設定
		]);

		// ヘッダーの設定（header()メソッドではなく別のメソッドで設定しなければならないものがある）
		foreach ($this->response->getHeaders() as $name => $values) {
			foreach ($values as $value) {
				if (strcasecmp($name, 'Content-Type') === 0) { // Content-Typeの場合
					$cakeResponse->type($value);
				} else { // 上記以外
					$cakeResponse->header([$name => $value]);
				}
			}
		}

		return $cakeResponse;
	}
}

<?php

App::uses('Component', 'Controller');

/**
 * AccessLogger Component class
 */
class AccessLoggerComponent extends Component {

/**
 * Request object
 *
 * @var CakeRequest
 */
	public $request;

/**
 * Initializes AccessLoggerComponent for use in the controller.
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);
		$this->request = $controller->request;
	}

/**
 * アクセスログを記録する。
 *
 * @param string $productId 商品ID
 * @param string $affiliateId アフィリエイトID
 * @return void
 */
	public function record($productId, $affiliateId = null) {
		$ADMIN_URL = Router::url(array(
			'controller' => 'products',
			'admin' => true,
		), true);
		if (strpos($this->request->referer(), $ADMIN_URL) !== false) {
			$this->log(__METHOD__.': not create access log from admin', 'debug');
			return;
		}

		$model = ClassRegistry::init('AccessLog');
		$model->create(array(
			'request_time' => env('REQUEST_TIME'),
			'remote_addr' => $this->request->clientIp(false),
			'referer' => $this->request->referer(),
			'product_id' => $productId,
			'affiliate_id' => $affiliateId,
		));
		if (!$model->save()) {
			$this->log(__METHOD__.': failed to save AccessLog', 'error');
		}
	}
}

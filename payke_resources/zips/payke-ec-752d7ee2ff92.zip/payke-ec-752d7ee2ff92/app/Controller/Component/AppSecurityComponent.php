<?php

App::uses('SecurityComponent', 'Controller/Component');

/**
 * このアプリ用に拡張したセキュリティコンポーネント。
 *
 * @link https://book.cakephp.org/2/ja/controllers/components.html#creating-a-component
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html
 */
class AppSecurityComponent extends SecurityComponent {

/**
 * CSRF トークンが作成されてから有効期限が切れるまでの期間。
 *
 * @var string
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#SecurityComponent::$csrfExpires
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id8
 */
	public $csrfExpires = '+1 hour';

/**
 * CSRF トークンの使用が一度きりかそうでないかの制御。
 * false を指定すると各リクエストで新しいトークンを生成しない。一つのトークンを有効期限が切れるまで再利用する。
 *
 * @var bool
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#SecurityComponent::$csrfUseOnce
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id10
 */
	public $csrfUseOnce = false;

/**
 * Component startup. All security checking happens here.
 *
 * @param Controller $controller Instantiating controller
 * @throws AuthSecurityException
 * @return void
 * @link https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#SecurityComponent::$validatePost
 * @link https://axios-http.com/ja/docs/req_config
 * @link https://github.com/laravel/framework/blob/10.x/src/Illuminate/Foundation/Http/Middleware/VerifyCsrfToken.php
 * @link https://www.php.net/manual/ja/function.setcookie.php
 * @see CakeResponse::cookie()
 */
	public function startup(Controller $controller) {
		if ($controller->request->is('ajax')) { // JSからのリクエスト
			$this->validatePost = false; // フォーム検証をしない
		}

		parent::startup($controller);

		// アプリ内JSからの更新リクエストのヘッダにCSRFトークンが含まれるようクッキーを設定
		// AxiosはXSRFトークンをクッキーから取得してリクエストヘッダへ含めてくれる
		// Axiosのデフォルトではクッキー名: XSRF-TOKEN、ヘッダ名: X-XSRF-TOKEN
		$controller->response->cookie([
			'name' => 'XSRF-TOKEN',
			'value' => $controller->request->params['_Token']['key'],
			'expire' => now()
				->addSeconds(Configure::read('Session.timeout') * 60)
				->timestamp,
		]);
	}

/**
 * コントローラへのリクエストに有効な CSRF トークンが含まれているかを検証する。
 *
 * @param Controller $controller コントローラ
 * @throws SecurityException
 * @return bool 適正なCSRFトークンかどうか
 * @link https://axios-http.com/ja/docs/req_config
 */
	protected function _validateCsrf(Controller $controller) {
		if ($this->request->is('ajax')) { // アプリ内JSのリクエスト
			if (empty($this->request->data('_Token.key'))) { // 本文にCSRFトークンが無い
				// ヘッダにCSRFトークンがあれば本文へセットする
				$headerToken = $this->request->header('X-XSRF-TOKEN');
				if ($headerToken) {
					$this->request->data('_Token.key', $headerToken);
					$this->log('CSRF token set', 'debug');
				}
			}
		}

		return parent::_validateCsrf($controller);
	}
}

<?php

App::uses('Component', 'Controller');

/**
 * RequestModifier Component class
 */
class RequestModifierComponent extends Component {

/**
 * Request object
 *
 * @var CakeRequest
 */
	public $request;

/**
 * Initializes RequestModifierComponent for use in the controller.
 *
 * @param Controller $controller A reference to the instantiating controller object
 * @return void
 */
	public function initialize(Controller $controller) {
		parent::initialize($controller);
		$this->request = $controller->request;
	}

/**
 * リクエストパラメータを変更する。
 *
 * @param array $map マッピング
 * @return void
 */
	public function modify(array $map) {
		foreach ($map as $path => $func) {
			$value = $this->request->data($path);
			if (empty($value) && !is_numeric($value)) {
				continue;
			}
			$modified = $func($value);
			$this->request->data($path, $modified);
		}
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * Products Controller
 *
 * @property Product $Product
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class ProductsController extends AppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'Product',
		'PayPalBillingPlan',
	];

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator' => array(
			'order' => array(
				'created' => 'desc',
			),
		),
		'RequestHandler',
		'Session',
		'Search.Prg' => array(
			'commonProcess' => array(
				'filterEmpty' => true,
			),
		),
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'create' => [
				'admin_duplicate',
			],
			'update' => [
				'admin_bulk_change',
			],
		]);

		if (in_array($this->request->action, ['admin_add', 'admin_edit'])) {
			$this->_setUnlockedFields();
		}
	}

/**
 * POSTバリデーションを解除したいフォームフィールドの一覧をセットする。
 *
 * @return void
 * @link https://book.cakephp.org/2.0/ja/core-libraries/components/security-component.html#SecurityComponent::$unlockedFields
 */
	protected function _setUnlockedFields() {
		// NOTE: hasManyのフィールドはFormHelper::unlockField()では解除できないようなのでここでセットしている。
		$this->Security->unlockedFields = array(
			'Item',
			'CustomField',
			'AmazonPayPaymentPlan',
			'BankTransferPaymentPlan',
			'PaidyPaymentPlan',
			'PayPalPaymentPlan',
			'ProductOption',
			'StripePaymentPlan',
			'UnivapayPaymentPlan',
		);
	}

/**
 * POST/PUTリクエストされたデータを型通りに解析しておく。
 * boolean型のカラムの値が'0'や'1'のままだと、バリデーションエラーで再表示するとき、JSでうまく処理できないため。
 *
 * @return void
 */
	protected function _parseStrictly() {
		foreach ($this->request->data['CustomField'] as &$record) {
			$record = $this->Product->CustomField->parseStrictly($record);
		}
		if (is_array($this->request->data('StripePaymentPlan'))) {
			foreach ($this->request->data['StripePaymentPlan'] as &$record) {
				$record = $this->Product->StripePaymentPlan->parseStrictly($record);
			}
		}
	}

/**
 * アフィリエイト会員向け商品一覧を表示する。
 *
 * @return void
 */
	public function affiliate_index() {
		$affiliateId = $this->Auth->user('id'); // アフィリエイト会員のユーザID

		$subQuery = $this->Product->buildConditionForAffiliate($affiliateId);

		$this->Paginator->settings = array(
			'conditions' => array(
				$subQuery, // このアフィリエイト会員に設定された商品グループの商品
				'affiliate_object' => true, // アフィリエイト対象
				'discontinued' => false, // 販売停止ではない
			),
			'contain' => array(
				'AffiliateItem' => array(
					'conditions' => array(
						'AffiliateItem.affiliate_id' => $affiliateId,
					),
					'fields' => array(
						'id',
						'affiliate_id',
					),
				),
			),
			'order' => array(
				'affiliate_start_date' => 'desc', // アフィリエイト対象に設定された日時の降順
			),
			'fields' => array(
				'id',
				'name',
				'purchase_type',
				'price',
				'affiliate_reward',
			),
		);
		$this->Product->addVirtualFields(['price']);
		$this->set('products', $this->Paginator->paginate());
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$conditions = $this->Product->parseCriteria($this->Prg->parsedParams());
		$conditions['parent_id'] = null;
		$this->Paginator->settings = array(
			'conditions' => $conditions,
			'contain' => array(
				'ProductGroup' => array(
					'fields' => array(
						'name',
					),
				),
				'ProductOption' => array(
					'fields' => array(
						'name',
						'initial_stock',
						'stock',
						'ordered_quantity',
						'not_accepted',
						'hidden',
					),
				),
				'Questionnaire' => ['fields' => ['id']],
			),
			'order' => array(
				'created' => 'desc',
			),
			'paramType' => 'querystring',
		);
		$this->Product->addVirtualFields(['price', 'booked_quantity', 'ordered_quantity']);

		$this->set('productGroups', $this->Product->ProductGroup->listSelectable());
		$this->set('products', $this->Paginator->paginate());
		$this->set('sctaNotations', $this->Product->SctaNotation->listSelectable());
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_view($id = null) {
		if (!$this->Product->exists($id)) {
			throw new NotFoundException();
		}
		$this->Product->id = $id;
		$this->request->data = $this->Product->find('forEdit');

		// 商品グループ
		$this->set('productGroups', $this->Product->ProductGroup->listSelectable());
		// アンケート
		$this->set('questionnaires', $this->Product->Questionnaire->listSelectable());
		// PayPal定期支払プラン
		$purchaseType = (int)Hash::get($this->request->data, 'Product.purchase_type');
		if (!is_purchase_type_registration($purchaseType)) { // 登録商品ではない
			// 特定商取引法に基づく表記
			$this->set('sctaNotations', $this->Product->SctaNotation->listSelectable());
		}
		if (is_purchase_type_payment($purchaseType)) {
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect', [
				'conditions' => ['type' => 'FIXED'],
			]));
		} elseif (is_purchase_type_subscription($purchaseType)) { // 継続
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect'));
		}
		if ($this->Auth->user('role') === 'admin') { // 管理者
			// 変更ログ一覧
			$this->set('changeLogs', $this->Product->ChangeLog->find('forModel', [
				'conditions' => ['model' => $this->Product->alias, 'foreign_key' => $id],
			]));
		}
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->Product->create();
			$options = ['deep' => true];
			if ($this->Product->saveAssociated($this->request->data, $options)) {
				$this->Flash->success(__('The product has been saved.'));
				return $this->redirect(array(
					'action' => 'view',
					$this->Product->id,
				));
			} else {
				$message = __('The product could not be saved. Please, try again.');
				$this->renderError($message, ['payment_plans']);
			}
			$this->_parseStrictly();
		} elseif ($this->request->is('get')) {
			$this->request->data = $this->Product->formDefaults(array(
				$this->Product->alias => $this->request->query,
			));
		}

		// 商品グループ
		$this->set('productGroups', $this->Product->ProductGroup->listSelectable());
		// アンケート
		$this->set('questionnaires', $this->Product->Questionnaire->listSelectable());
		// PayPal定期支払プラン
		$purchaseType = (int)Hash::get($this->request->data, 'Product.purchase_type');
		if (!is_purchase_type_registration($purchaseType)) { // 登録商品ではない
			// 特定商取引法に基づく表記
			$this->set('sctaNotations', $this->Product->SctaNotation->listSelectable());
		}
		if (is_purchase_type_payment($purchaseType)) {
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect', [
				'conditions' => ['type' => 'FIXED'],
			]));
		} elseif (is_purchase_type_subscription($purchaseType)) { // 継続
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect', [
				'conditions' => ['type' => 'INFINITE'],
			]));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->Product->exists($id)) {
			throw new NotFoundException(__('Invalid product'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$options = ['deep' => true];
			if ($this->Product->saveAssociated($this->request->data, $options)) {
				$this->Flash->success(__('The product has been saved.'));
				return $this->redirect([
					'action' => 'view',
					$id,
				]);
			} else {
				$message = __('The product could not be saved. Please, try again.');
				$this->renderError($message, ['payment_plans']);
			}
			$this->_parseStrictly();
		} else {
			$this->Product->id = $id;
		}
		$product = $this->Product->find('forEdit');
		$this->request->data = Hash::merge($product, $this->request->data);

		// 商品グループ
		$this->set('productGroups', $this->Product->ProductGroup->listSelectable());
		// アンケート
		$this->set('questionnaires', $this->Product->Questionnaire->listSelectable());
		// PayPal定期支払プラン
		$purchaseType = (int)Hash::get($this->request->data, 'Product.purchase_type');
		if (!is_purchase_type_registration($purchaseType)) { // 登録商品ではない
			// 特定商取引法に基づく表記
			$this->set('sctaNotations', $this->Product->SctaNotation->listSelectable());
		}
		if (is_purchase_type_payment($purchaseType)) {
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect', [
				'conditions' => ['type' => 'FIXED'],
			]));
		} elseif (is_purchase_type_subscription($purchaseType)) { // 継続
			$this->set('payPalBillingPlans', $this->PayPalBillingPlan->find('forSelect')); // Fix Issue #274 編集ページではtypeを問わずに取得
		}
		if ($this->Auth->user('role') === 'admin') { // 管理者
			// 変更ログ一覧
			$this->set('changeLogs', $this->Product->ChangeLog->find('forModel', [
				'conditions' => ['model' => $this->Product->alias, 'foreign_key' => $id],
			]));
		}
	}

/**
 * 管理者向け商品複製アクション。
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_duplicate($id = null) {
		$this->Product->id = $id;
		if (!$this->Product->exists()) {
			throw new NotFoundException(__('Invalid product'));
		}
		$this->request->allowMethod('post');
		if ($this->Product->duplicate()) {
			$this->Flash->success('商品を複製しました。');
		} else {
			$this->Flash->error('商品を複製できませんでした。');
			$this->log($this->Product->validationErrors);
			return $this->redirect($this->referer());
		}
		return $this->redirect(array('action' => 'view', $this->Product->id));
	}

/**
 * admin_delete method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		$this->Product->id = $id;
		if (!$this->Product->exists()) {
			throw new NotFoundException(__('Invalid product'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($count = $this->Product->countOrders()) {
			$this->Flash->error(__('The product could not be deleted because it has some orders.'));
		} elseif ($this->Product->delete()) {
			$this->Flash->success(__('The product has been deleted.'));
		} else {
			$this->Flash->error(__('The product could not be deleted. Please, try again.'));
		}
		return $this->redirect($this->referer());
	}

/**
 * 管理者向け一括変更アクション。
 *
 * @return void
 * @throws BadRequestException
 */
	public function admin_bulk_change() {
		$products = $this->request->data('Product');
		if (empty($products)) {
			$this->Flash->warning('商品が選択されていません。');
			return $this->redirect($this->referer());
		}
		if ($this->request->data('discontinue')) {
			$discontinued = true; // 販売停止
		} elseif ($this->request->data('continue')) {
			$discontinued = false; // 販売
		} else {
			throw new BadRequestException('Invalid field');
		}
		foreach ($products as &$product) {
			$product['discontinued'] = $discontinued;
		}
		$options = [
			'fieldList' => ['discontinued'],
			'counterCache' => false,
		];
		if ($this->Product->saveMany($products, $options)) {
			$this->Flash->success('一括変更されました。');
		} else {
			$this->Flash->error('一括変更されませんでした。');
			$this->log($this->Product->validationErrors);
		}
		// $this->log($this->Product->getDataSource()->getLog(), LOG_DEBUG);
		return $this->redirect($this->referer());
	}
}

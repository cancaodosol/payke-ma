<?php
App::uses('AppController', 'Controller');
/**
 * Questionnaires Controller
 *
 * @property Questionnaire $Questionnaire
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class QuestionnairesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		// https://book.cakephp.org/2/ja/controllers.html#Controller::$paginate
		'Paginator' => [
			'contain' => false,
			'order' => [
				'Questionnaire.created' => 'desc',
			],
			'paramType' => 'querystring',
		],
		'Session',
		'Flash',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		if (in_array($this->request->action, ['admin_add', 'admin_edit'])) {
			$this->_setUnlockedFields();
		}

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'create' => [
				'admin_duplicate',
			],
			'read' => [
				'admin_tally',
			],
		]);
	}

/**
 * POSTバリデーションを解除したいフォームフィールドの一覧をセットする。
 *
 * @return void
 * @link https://book.cakephp.org/2.0/ja/core-libraries/components/security-component.html#SecurityComponent::$unlockedFields
 */
	protected function _setUnlockedFields() {
		// NOTE: hasManyのフィールドはFormHelper::unlockField()では解除できないようなのでここでセットしている。
		$this->Security->unlockedFields = [
			'CustomField',
		];
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Paginator->settings = $this->paginate;
		$this->set('questionnaires', $this->Paginator->paginate());
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_view($id = null) {
		if (!$this->Questionnaire->exists($id)) {
			throw new NotFoundException();
		}
		$this->Questionnaire->id = $id;
		$this->request->data = $this->Questionnaire->find('forEdit');
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->Questionnaire->create();
			if ($this->Questionnaire->saveAssociated($this->request->data)) {
				$this->Flash->success(__('The questionnaire has been saved.'));
				return $this->redirect([
					'action' => 'view',
					$this->Questionnaire->id,
				]);
			} else {
				$this->Flash->error(__('The questionnaire could not be saved. Please, try again.'));
			}
		} elseif ($this->request->is('get')) {
			$this->request->data = $this->Questionnaire->formDefaults();
		}
	}

/**
 * admin_edit method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->Questionnaire->exists($id)) {
			throw new NotFoundException(__('Invalid questionnaire'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Questionnaire->saveAssociated($this->request->data)) {
				$this->Flash->success(__('The questionnaire has been saved.'));
				return $this->redirect([
					'action' => 'view',
					$id,
				]);
			} else {
				$this->Flash->error(__('The questionnaire could not be saved. Please, try again.'));
			}
		} else {
			$this->Questionnaire->id = $id;
			$this->request->data = $this->Questionnaire->find('forEdit');
		}
	}

/**
 * admin_duplicate method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_duplicate($id = null) {
		$this->Questionnaire->id = $id;
		if (!$this->Questionnaire->exists()) {
			throw new NotFoundException(__('Invalid questionnaire'));
		}
		$this->request->allowMethod('post');
		if ($this->Questionnaire->duplicate()) {
			$this->Flash->success(__('The questionnaire has been duplicated.'));
		} else {
			$this->Flash->error(__('The questionnaire could not be duplicated.'));
			$this->log($this->Questionnaire->validationErrors);
			return $this->redirect($this->referer());
		}
		return $this->redirect(['action' => 'edit', $this->Questionnaire->id]);
	}

/**
 * admin_delete method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		$this->Questionnaire->id = $id;
		if (!$this->Questionnaire->exists()) {
			throw new NotFoundException(__('Invalid questionnaire'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($count = $this->Questionnaire->countQuestionnaireAnswer()) {
			$this->Flash->error(__('The questionnaire could not be deleted because it has some questionnaire answers.'));
		} elseif ($count = $this->Questionnaire->countProducts()) {
			$this->Flash->error(__('The questionnaire could not be deleted because it has some products.'));
		} elseif ($this->Questionnaire->delete()) {
			$this->Flash->success(__('The questionnaire has been deleted.'));
		} else {
			$this->Flash->error(__('The questionnaire could not be deleted. Please, try again.'));
		}
		return $this->redirect(['action' => 'index']);
	}

/**
 * 集計結果を表示する。
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_tally($id = null) {
		$this->Questionnaire->id = $id;
		if (!$this->Questionnaire->exists()) {
			throw new NotFoundException(__('Invalid questionnaire'));
		}
		App::uses('Order', 'Model');
		$questionnaire = $this->Questionnaire->find('first', [
			'conditions' => ['Questionnaire.id' => $id],
			'contain' => [
				'CustomField' => [
					'conditions' => [
						'fieldable_type' => 'Questionnaire',
						'displayed' => true,
					],
					'fields' => ['id', 'name', 'label', 'type', 'options', 'fixed'],
				],
				'QuestionnaireAnswer' => [
					'CustomFieldValue' => [
						'fields' => ['custom_field_id', 'value'],
					],
					'Order' => [
						'fields' => Order::FIXED_FIELDS,
					],
					'fields' => [],
				],
			],
			'fields' => ['name'],
		]);
		$this->set(compact('questionnaire'));
	}
}

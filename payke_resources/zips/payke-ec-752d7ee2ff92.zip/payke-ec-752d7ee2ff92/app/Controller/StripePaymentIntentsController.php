<?php
App::uses('AppController', 'Controller');

/**
 * StripePaymentIntents Controller
 *
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class StripePaymentIntentsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'update' => [
				'admin_refund',
			],
		]);
	}

/**
 * _view method
 *
 * @throws NotFoundException
 * @param string $id
 * @param string $message
 * @return void
 * @throws ApiErrorException
 * @link https://stripe.com/docs/api/payment_intents/retrieve
 */
	protected function _view($id = null, $message = null) {
		$paymentIntent = $this->StripePaymentIntent->read(null, $id);
		$this->set(compact('message', 'paymentIntent'));
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id = null) {
		$this->_view($id);
	}

/**
 * admin_refund method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 * @link https://stripe.com/docs/api/refunds/create
 */
	public function admin_refund($id = null) {
		if ($this->request->is('post')) {
			$this->loadModel('StripeRefund');
			$this->StripeRefund->create();
			$result = $this->StripeRefund->save($this->request->data, ['atomic' => false]);
			if (!$result) {
				$message = __('The refund could not be saved. Please, try again.');
				$errors = $this->StripeRefund->validationErrors;
				$this->response->statusCode(400);
				return $this->set(compact('errors', 'message'));
			}
			$message = __('The refund has been created.');
			$this->_view($id, $message);
		}
	}
}

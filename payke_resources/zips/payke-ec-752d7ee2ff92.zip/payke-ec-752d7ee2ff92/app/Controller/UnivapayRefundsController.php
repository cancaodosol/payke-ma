<?php
App::uses('AppController', 'Controller');

/**
 * UnivapayRefunds Controller
 *
 * @property UnivapayRefund $UnivapayRefund
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class UnivapayRefundsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_add method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->UnivapayRefund->create();
			if ($result = $this->UnivapayRefund->save($this->request->data)) {
				$this->Flash->success(__('The refund has been saved.'));
				if ($this->request->is('ajax')) {
					$this->request->data = $result;
				} else {
					return $this->redirect(array('action' => 'index'));
				}
			} else {
				$this->Flash->error(__('The refund could not be saved. Please, try again.'));
			}
		}
	}
}

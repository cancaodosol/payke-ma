<?php
App::uses('AppController', 'Controller');
/**
 * Configs Controller
 *
 * @property Config $Config
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class ConfigsController extends AppController {

	const KEY_REQ_DATA = 'Request.data.Config';

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @param string $part
 * @return void
 */
	public function admin_edit($id = null, $part = null) {
		if (!$this->Config->exists($id)) {
			throw new NotFoundException(__('Invalid config'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->request->data('send_test_mail')) { // テストメール送信の場合
				if ($this->_sendTestMail()) { // テストメール送信
					$this->Flash->success('テストメールが送信されました。正しく送信されたことを確認できたら、[保存]ボタンによりこの設定を保存してください。');
					$this->Session->write(self::KEY_REQ_DATA, $this->request->data('Config')); // データをセッションへ保存
					return $this->redirect($this->referer());
				}
			} else if ($this->Config->save($this->request->data)) { // 保存
				$this->Flash->success(__('The config has been saved.'));
				return $this->redirect(array($id, $part));
			} else {
				$this->Flash->error(__('The config could not be saved. Please, try again.'));
			}
		} else {
			if ($this->Session->check(self::KEY_REQ_DATA)) { // データがセッションに保存されている
				$data = $this->Session->consume(self::KEY_REQ_DATA); // データをセッションから消費
				$this->request->data('Config', $data);
			} else {
				$options = [
					'conditions' => ['Config.' . $this->Config->primaryKey => $id],
				];
				$this->request->data = $this->Config->find('first', $options);
			}
		}

		switch ($part) {
			case 'apis':
				$this->loadModel('CryptKey');
				$amazonPayPrivateKeys = $this->CryptKey->find('list', [
					'conditions' => ['CryptKey.type' => 'amazon_pay.private'],
				]);
				$this->set('amazonPayPrivateKeys', $amazonPayPrivateKeys);
				$this->render('admin_edit_apis');
				break;
			case 'elements':
				$this->render('admin_edit_order_view');
				break;
			default:
				$this->loadModel('ProductGroup');
				$this->set('productGroups', $this->ProductGroup->find('list', [
					'fields' => ['uniqueid', 'name'],
					'order' => 'name',
				]));
				break;
		}
	}

/**
 * 設定を取得する。
 *
 * @param int $id ID
 * @return array
 * @throws ForbiddenException
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::requestAction
 */
	public function admin_view($id = 1) {
		if (empty($this->request->params['requested'])) {
			throw new ForbiddenException();
		}
		return $this->Config->find('first', [
			'conditions' => [
				"{$this->Config->alias}.{$this->Config->primaryKey}" => $id,
			],
			'recursive' => -1,
			'fields' => ['email_from'],
		]);
	}

/**
 * テストメールを送信する。
 *
 * @return mixed
 */
	protected function _sendTestMail() {
		$sent = false;

		try {
			$sent = $this->Config->sendTestMail($this->request->data);
		} catch (SocketException $e) {
			$this->Flash->error('テストメールは送信されませんでした。', [
				'params' => [
					'details' => [$e->getMessage()],
				],
			]);
		}

		return $sent;
	}
}

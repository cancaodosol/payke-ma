<?php
App::uses('AppController', 'Controller');

/**
 * AmazonPayCharges Controller
 *
 * @property AmazonPayCharge $AmazonPayCharge
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class AmazonPayChargesController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id) {
		$charge = $this->AmazonPayCharge->read(null, $id);
		$message = $this->AmazonPayCharge->statusReason();
		$this->set(compact('charge', 'message'));
	}
}

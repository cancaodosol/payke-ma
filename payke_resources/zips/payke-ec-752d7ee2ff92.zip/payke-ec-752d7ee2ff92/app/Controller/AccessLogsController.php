<?php
App::uses('AppController', 'Controller');
/**
 * AccessLogs Controller
 *
 * @property AccessLog $AccessLog
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class AccessLogsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator',
		'Session',
		'Search.Prg' => array(
			'commonProcess' => array(
				'filterEmpty' => true,
			),
		),
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_open_url',
			],
			'delete' => [
				'admin_delete_all_by_conditions',
			],
		]);
	}

/**
 * affiliate_index method
 *
 * @return void
 */
	public function affiliate_index() {
		$this->Paginator->settings = array(
			'conditions' => array(
				'affiliate_id' => $this->Auth->user('id'), // ログインユーザ（アフィリエイト会員）の紹介コードを経由
				'affiliate_object' => true, // アフィリエイト対象
			),
			'contain' => array(
				'Product' => array(
					'fields' => array(
						'name',
					),
				),
			),
			'order' => array(
				'request_time' => 'desc',
			),
		);
		$this->set('accessLogs', $this->Paginator->paginate());
	}

/**
 * affiliate_open_url method
 *
 * @param string $id
 * @return void
 */
	public function affiliate_open_url($id = null) {
		$this->_redirectToReferrerUrl($id);
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = array(
			'conditions' => $this->AccessLog->parseCriteria($this->Prg->parsedParams()),
			'contain' => array(
				'Product' => array(
					'fields' => array(
						'name',
					),
				),
				'Affiliate' => array(
					'fields' => array(
					),
					'Profile' => array(
						'fields' => array(
							'full_name',
						),
					),
				),
			),
			'order' => array(
				'request_time' => 'desc',
			),
			'paramType' => 'querystring',
		);

		$accessLogs = $this->Paginator->paginate();

		$products = $this->AccessLog->Product->find('list');
		$affiliates = $this->AccessLog->Affiliate->find('list', array(
			'fields' => array('Profile.full_name'),
			'conditions' => array('role' => 'affiliate'),
			'contain' => array('Profile'),
			'order' => array('Profile.full_name'),
		));

		$this->set(compact('accessLogs', 'products', 'affiliates'));
	}

/**
 * admin_open_url method
 *
 * @param string $id
 * @return void
 */
	public function admin_open_url($id = null) {
		$this->_redirectToReferrerUrl($id);
	}

/**
 * admin_delete_all_by_conditions method
 *
 * @throws NotFoundException
 * @return void
 */
	public function admin_delete_all_by_conditions() {
		$this->request->allowMethod('post', 'delete');
		if ($this->AccessLog->deleteAllByConditions($this->request->data)) {
			$this->Flash->success(__('The access logs have been deleted.'));
		} else {
			foreach ($this->AccessLog->validationErrors as $field => $errors) {
				foreach ($errors as $error) {
					$this->Flash->error($error);
				}
			}
		}
		return $this->redirect(array('action' => 'index'));
	}

/**
 * リファラーのURLへリダイレクトする。
 *
 * @param string $id
 * @return void
 */
	protected function _redirectToReferrerUrl($id = null) {
		$this->AccessLog->id = $id;
		if (!$this->AccessLog->exists()) {
			throw new NotFoundException(__('Invalid access log'));
		}
		$url = $this->AccessLog->field('referer');
		$this->set(compact('url'));
		$this->render('/open_url');
	}
}

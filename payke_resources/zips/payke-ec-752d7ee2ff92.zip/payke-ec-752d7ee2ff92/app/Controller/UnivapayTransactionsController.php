<?php
App::uses('AppController', 'Controller');

/**
 * UnivapayTransactions Controller
 *
 * @property UnivapayTransaction $UnivapayTransaction
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 * @link https://docs.prod.univapaycast.com/References/transactions/
 */
class UnivapayTransactionsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_index method
 *
 * 返金リストも一緒に取得できる「トランザクション: List」により、課金を取得する。
 * （「課金: Get」では返金リストを一緒に取得できない）
 *
 * @return void
 * @throws ApiErrorException
 * @link https://docs.prod.univapaycast.com/References/transactions-list/
 */
	public function admin_index() {
		$transactions = $this->UnivapayTransaction->find('all', [
			'conditions' => array_only(
				$this->request->query,
				$this->UnivapayTransaction::LIST_PARAMS
			),
		]);
		$this->set(compact('transactions'));
	}
}

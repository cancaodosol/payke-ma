<?php
App::uses('UsersUsersController', 'Users.Controller');
/**
 * Users Controller
 */
class UsersController extends UsersUsersController {

/**
 * Setup components based on plugin availability
 *
 * @return void
 */
	protected function _setupComponents() {
		$this->components[] = 'Acl';
	}

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_dashboard',
			],
		]);
	}

/**
 * Sets the default pagination settings up
 *
 * Override this method or the index() action directly if you want to change
 * pagination settings. admin_index()
 *
 * @return void
 */
	protected function _setupAdminPagination() {
		$this->Paginator->settings[$this->modelClass] = [
			'conditions' => [
				$this->modelClass . '.role' => 'business', // 業務ユーザー
				'NOT' => [
					$this->modelClass . '.id' => $this->Auth->user('id'),
				],
			],
			'fields' => [
				'id', 'username', 'locked',
			],
			'order' => [
				$this->modelClass . '.created' => 'asc'
			],
		];
	}

/**
 * Setup Authentication Component
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#authcomponent-api
 */
	protected function _setupAuth() {
		$this->Auth->allow([
			'admin_logout',
			'can',
			'reset_password',
		]);

		// https://slywalker.github.io/cakephp-plugin-boost_cake/
		$this->Auth->flash = [
			'element' => 'alert',
			'key' => 'auth',
			'params' => [
				'plugin' => 'BoostCake',
				'class' => 'alert-error'
			],
		];

		switch ($this->request->prefix) {
			case 'admin': // 管理者向けWebページへのリクエスト
				$this->Auth->authenticate = [
					'PaykeForm' => [
						'passwordHasher' => 'Blowfish',
					],
				];
				$this->Auth->loginRedirect = PE_URL_ADMIN_DASHBOARD;
				break;
		}
	}

/**
 * 該当ユーザーがリクエスト内でリソースにアクセスすることが許可されるかを boolean で返す。
 *
 * @param array $user アクティブなユーザー
 * @return bool 許可されるか
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#controllerauthorize
 * @link https://book.cakephp.org/2/ja/tutorials-and-examples/blog-auth-example/auth.html#id4
 */
	public function isAuthorized($user = null) {
		// ダッシュボード、ログイン情報を編集
		if (in_array($this->action, ['admin_dashboard', 'admin_me'])) {
			// 管理者と業務ユーザーを認可
			return in_array($user['role'], ['admin', 'business']);
		}

		return parent::isAuthorized($user);
	}

/**
 * アフィリ会員ログインページの
 * 旧URL (/affiliate/users/login) を
 * 新URL (/affiliate/affiliates/login) へリダイレクトさせる。
 *
 * Config/routes.php 内の Router::redirect() でやろうとすると、
 * 何故かサブディレクトリで動かしている環境でうまくいかないようなので、ここで行っている。
 *
 * @return CakeResponse|null
 */
	public function affiliate_login() {
		return $this->redirect([
			'controller' => 'affiliates',
		]);
	}

/**
 * Admin login action
 *
 * @return CakeResponse|null
 */
	public function admin_login() {
		// 既に認証済みの場合はリダイレクトさせる
		if ($response = $this->authenticated()) {
			return $response;
		}
		if ($this->request->is('post')) {
			if ($this->Auth->login()) {
				$this->Flash->success(__('You have successfully logged in'));
				$url = $this->Auth->redirectUrl();
				if ($this->Auth->user('role') === 'admin') {
					$url = PE_URL_ADMIN_ORDERS;
				}
				return $this->redirect($url);
			}
			$this->Flash->error(__('You could not log in.'));
		} else {
			$this->Session->delete('Auth.redirect');
		}
	}

/**
 * Admin logout action
 *
 * @return CakeResponse|null
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id18
 */
	public function admin_logout() {
		return $this->redirect($this->Auth->logout());
	}

/**
 * Admin dashboard action
 *
 * @return CakeResponse|null
 */
	public function admin_dashboard() {
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->_setupAdminPagination();
		$users = $this->Paginator->paginate();
		foreach ($users as &$user) {
			$user['permissions'] = $this->_listPermissions($user);
		}
		$this->set('users', $users);
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			if ($user = $this->User->registerBusiness($this->request->data)) {
				$this->_savePermissions($user);
				$this->Flash->success(__('The user has been saved.'));
				return $this->redirect([
					'action' => 'edit',
					$this->User->id,
				]);
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data('permissions', $this->_listPermissions(null));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id ユーザーのID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->User->save($this->request->data)) {
				$this->_savePermissions($this->request->data);
				$this->Flash->success(__('The user has been saved.'));
				return $this->redirect([]);
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $this->User->find('first', [
				'conditions' => ['User.' . $this->User->primaryKey => $id],
				'contain' => false,
				'fields' => ['id', 'username'],
			]);
			$permissions = $this->_listPermissions($this->request->data);
			$this->request->data('permissions', $permissions);
		}
	}

/**
 * admin_me method
 *
 * @return void
 */
	public function admin_me() {
		$id = $this->Auth->user('id');
		if ($this->request->is(array('post', 'put'))) {
			// FIXME: `Couldn't find Aro node ...`エラーへの回避策としてモデルからACLビヘイビアを外している。
			$this->User->Behaviors->unload('Acl');
			if ($this->User->save($this->request->data)) {
				$this->Flash->success(__('The user has been saved.'));
				return $this->redirect([]);
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $user = $this->User->find('first', [
				'conditions' => ['User.' . $this->User->primaryKey => $id],
				'contain' => false,
				'fields' => ['id', 'username'],
			]);
		}
	}

/**
 * ACOへのアクションが許可されているかを返す。
 *
 * @param string $action アクション
 * @param string $aco ACO
 * @return bool
 * @throws ForbiddenException
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::requestAction
 * @link https://book.cakephp.org/2/ja/core-libraries/components/access-control-lists.html#checking-permissions
 */
	public function can($action, $aco) {
		if (empty($this->request->params['requested'])) {
			throw new ForbiddenException();
		}

		$user = $this->Auth->user(); // 現在の認証済みユーザー

		if (Hash::get($user, 'role') === 'admin') { // 管理者
			return true;
		}

		$aro[$this->User->alias] = $user;
		return $this->Acl->check($aro, $aco, $action);
	}

/**
 * パーミッションの一覧を作成して返す。
 *
 * @param array|null $aro AROの情報を含む連想配列
 * @return array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/access-control-lists.html#checking-permissions
 */
	protected function _listPermissions($aro) : array {
		$list = [];
		$actions = array_reverse(array_filter(array_keys(PE_PERMISSION_OPTS)));
		foreach (PE_ACO_ALIASES as $aco) {
			$permission = null;
			foreach ($actions as $action) {
				if ($this->Acl->check($aro, $aco, $action)) {
					$permission = $action;
					break;
				}
			}
			$list[$aco] = $permission;
		}
		return $list;
	}

/**
 * パーミッションの一覧を保存する。
 *
 * @param array $data ARO, ACO, アクションの情報を含む連想配列
 * @return array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/access-control-lists.html#id3
 */
	protected function _savePermissions(array $data) {
		$aro = $data;
		foreach ($data['permissions'] as $aco => $action) {
			$this->Acl->inherit($aro, $aco);
			if (!empty($action)) {
				$this->Acl->allow($aro, $aco, $action);
			}
		}
	}

/**
 * admin_unlock method
 *
 * @param string $id ユーザーのID
 * @return void
 * @throws NotFoundException
 */
	public function admin_unlock($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$this->User->id = $id;
			if ($this->User->saveField('locked', $this->request->data('User.locked'))) {
				$username = $this->User->field('name');
				App::uses('RateLimiter', 'Cache');
				(new RateLimiter())->clear($username);
				$this->Flash->success(__('The user has been unlocked.'));
			} else {
				$this->Flash->error(__('The user could not be unlocked. Please, try again.'));
			}
			return $this->redirect($this->referer());
		}
	}
}

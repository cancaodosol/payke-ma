<?php
App::uses('AppController', 'Controller');
/**
 * AmazonPayIpnMessages Controller
 *
 * @property AmazonPayIpnMessage $AmazonPayIpnMessage
 * @property RequestHandlerComponent $RequestHandler
 * @property RequestModifierComponent $RequestModifier
 * @link https://developer.amazon.com/ja/docs/amazon-pay-checkout/set-up-instant-payment-notifications.html
 * @link http://amazonpay-integration.amazon.co.jp/amazonpay-faq-v2/detail.html?id=QA-116
 */
class AmazonPayIpnMessagesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
		'RequestModifier',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// アクセス保護を削除
		$this->Auth->allow('process');

		// [指定したアクションの CSRF とデータバリデーションの無効化](https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id12)
		$this->Security->unlockedActions = [
			'process'
		];
	}

/**
 * process method
 *
 * @return void
 */
	public function process() {
		$this->request->allowMethod('post');

		// リクエストデータを加工
		$this->RequestModifier->modify([
			'Message' => function($value) {
				return json_decode($value, true);
			},
		]);

		// 処理対象か否かを確認
		$this->AmazonPayIpnMessage->set($this->request->data); // TODO: これは本当に必要か確認
		$objectType = $this->request->data('Message.ObjectType');
		if (empty($this->AmazonPayIpnMessage->handler($objectType))) {
			$this->log("Ignore ObjectType: '{$objectType}'", 'debug');
			return;
		}

		// 保存
		$this->AmazonPayIpnMessage->create();
		$result = $this->AmazonPayIpnMessage->save($this->request->data);
		if (!$result) {
			// 400番台であればIPN再試行の対象にはならない
			// https://developer.amazon.com/ja/docs/amazon-pay-checkout/set-up-instant-payment-notifications.html#ipn再試行ロジック
			$name = 'Validation Error';
			$message = $this->AmazonPayIpnMessage->validationErrors;
			throw new CakeException(compact('name', 'message'), 422);
		}

		$this->log('The Amazon Pay IPN message has been saved.', 'debug');
	}
}

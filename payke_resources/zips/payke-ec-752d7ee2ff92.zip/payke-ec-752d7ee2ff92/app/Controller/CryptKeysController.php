<?php
App::uses('AppController', 'Controller');
/**
 * CryptKeys Controller
 *
 * @property CryptKey $CryptKey
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class CryptKeysController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Flash',
		'RequestHandler',
		'Session',
	];

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->CryptKey->create();
			if ($result = $this->CryptKey->save($this->request->data)) {
				$this->Flash->success(__('The crypt key has been registered.'));
				if ($this->request->is('ajax')) {
					$this->request->data = $result;
				} else {
					return $this->redirect(array('action' => 'index'));
				}
			} else {
				$this->Flash->error(__('The crypt key could not be registered. Please, try again.'));
			}
		}
	}
}

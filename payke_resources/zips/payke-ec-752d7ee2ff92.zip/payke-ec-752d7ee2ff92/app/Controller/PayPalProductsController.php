<?php
App::uses('AppController', 'Controller');

/**
 * PayPalProducts Controller
 */
class PayPalProductsController extends AppController {

/**
 * {@inheritdoc}
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_index method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_index() {
		$products = $this->PayPalProduct->find('all');
		$this->set(compact('products'));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * PayPalBillingAgreements Controller
 */
class PayPalBillingAgreementsController extends AppController {

	/**
	 * {@inheritdoc}
	 */
	public $components = array(
		'RequestHandler',
	);

	/**
	 * admin_view method
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_view($id = null) {
		$this->log([__METHOD__, $id], 'debug');
		$this->PayPalBillingAgreement->id = $id;
		$billingAgreement = $this->PayPalBillingAgreement->get();
		// $this->log([__METHOD__, $billingAgreement], 'debug');
		$this->_setJsonResponse(compact('billingAgreement'));
	}

	/**
	 * キャンセルする。
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_cancel($id = null) {
		$this->log([__METHOD__, $id, $this->request->data], 'debug');
		$this->request->allowMethod('post');
		$this->PayPalBillingAgreement->id = $id;
		$this->PayPalBillingAgreement->set($this->request->data);
		if (!$this->PayPalBillingAgreement->validates()) {
			$message = __('Validation error');
			$errors = $this->PayPalBillingAgreement->validationErrors;
			return $this->_setJsonResponse(compact('message', 'errors'), 400);
		}
		if (!$this->PayPalBillingAgreement->cancel($this->request->data)) {
			$message = __('Error') . " ({$this->PayPalBillingAgreement->failureReason})";
			return $this->_setJsonResponse(compact('message'), 400);
		}
		$message = __('PayPal billing agreement canceled');
		$billingAgreement = $this->PayPalBillingAgreement->get();
		$this->_setJsonResponse(compact('message', 'billingAgreement'));
	}

}

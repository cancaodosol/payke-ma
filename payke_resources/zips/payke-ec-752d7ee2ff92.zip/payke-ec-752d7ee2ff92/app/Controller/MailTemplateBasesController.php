<?php
App::uses('AppController', 'Controller');
/**
 * MailTemplates Controller
 *
 * @property MailTemplateBase $MailTemplateBase
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class MailTemplateBasesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator' => array(
			'order' => array(
				'sort' => 'asc',
			),
		),
		'Session'
	);

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$conditions = [];
		if (!Configure::check('KoryoEC.Affiliate')) {
			$conditions += array(
				'MailTemplateBase.id NOT IN' => array(6, 7),
			);
		}
		$this->Paginator->settings['conditions'] = $conditions;
		$this->MailTemplateBase->recursive = 0;
		$this->set('mailTemplateBases', $this->Paginator->paginate());
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		if (!$this->MailTemplateBase->exists($id)) {
			throw new NotFoundException(__('Invalid mail template base'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->MailTemplateBase->save($this->request->data)) {
				$this->Flash->success(__('The mail template base has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The mail template base could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $this->MailTemplateBase->find('first', [
				'conditions' => [
					'MailTemplateBase.' . $this->MailTemplateBase->primaryKey => $id,
				],
			]);
		}
	}
}

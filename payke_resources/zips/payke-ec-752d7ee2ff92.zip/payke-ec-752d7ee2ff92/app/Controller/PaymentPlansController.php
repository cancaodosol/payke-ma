<?php
App::uses('AppController', 'Controller');
/**
 * PaymentPlans Controller
 *
 * @property FlashComponent $Flash
 * @property PaymentPlan $PaymentPlan
 * @property RequestHandlerComponent $RequestHandler
 * @property SessionComponent $Session
 */
class PaymentPlansController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Flash',
		'RequestHandler',
		'Session',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// ゲスト（未ログイン）ユーザーに公開するアクション
		$this->Auth->allow([
			'detail',
		]);
	}

/**
 * 分割払い/継続払いの詳細を標準化された形式で返す（参照プランありの場合）。
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function detail($id = null) {
		$paymentPlan = $this->PaymentPlan->find('forDetail', [
			'conditions' => ['PaymentPlan.id' => $id],
		]);
		if (!$paymentPlan) {
			throw new NotFoundException(__('Invalid payment plan'));
		}
		$this->set('details', $this->PaymentPlan->detailReference($paymentPlan));
	}
}

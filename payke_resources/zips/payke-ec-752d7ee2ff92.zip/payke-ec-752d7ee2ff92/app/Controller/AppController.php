<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');
App::uses('CrudControllerTrait', 'Crud.Lib');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		https://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

	use CrudControllerTrait;

/**
 * コントローラで使うコンポーネントをセットする。
 * ここで与えられたクラスはコントローラの中でクラス変数として有効になる (例えば $this->Session) 。
 * 継承された値とマージされる。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$components
 * @link https://book.cakephp.org/2/ja/controllers/components.html#configuring-components
 */
	public $components = array(
		'DebugKit.Toolbar',
		'Flash',
		'Auth',
		'Security' => [
			'className' => 'AppSecurity', // AppSecurityComponent クラスを使用
		],
		'Crud.Crud',
	);

/**
 * コントローラで使うヘルパーをセットする。
 * ここで与えられたクラスはビューの中でオブジェクトへの参照として有効になる (例えば $this->Html) 。
 * 継承された値とマージされる。
 * HtmlHelper 、 FormHelper 、SessionHelper はデフォルトで有効になっている。
 *
 * @var mixed
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$helpers
 * @link https://book.cakephp.org/2/ja/views/helpers.html#configuring-helpers
 */
	public $helpers = array(
		'Auth',
		'Session',
		'Html',
		'Form',
		'Mix',
		'Paginator',
		'Time',
	);

/**
 * コントローラの各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CakeResponse クラスに不足しているステータスコードを追加（Unknown status code 例外になるのを防ぐため）
		$this->httpCodes([
			422 => 'Unprocessable Entity', // https://developer.mozilla.org/ja/docs/Web/HTTP/Status/422
		]);

		// APIで未認証により403エラーとなった場合に認可エラーと区別する
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id10
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#AuthComponent::$ajaxLogin
		$this->Auth->ajaxLogin = 'ajax_unauthenticated';

		// 認可ハンドラの設定 https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id20
		// いずれかのハンドラを通過できるまで順番に呼び出される
		$this->Auth->authorize = [
			'Controller',
			'Crud',
		];
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id11
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#AuthComponent::$authError
		$this->Auth->authError = false;
		if ($this->Auth->loggedIn()) {
			$this->Auth->authError = __('You are not authorized to access that location.');
		}
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#AuthComponent::$unauthorizedRedirect
		// if ($this->request->is('ajax')) { これだとうまくいかない
		if ($this->request->is('json')) { // APIへのリクエスト
			$this->Auth->unauthorizedRedirect = false;
		} else if ($this->request->prefix === 'admin') {
			$this->Auth->unauthorizedRedirect = PE_URL_ADMIN_DASHBOARD;
		}

		if ($this->request->prefix === 'affiliate') {
			// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#AuthComponent::$loginAction
			$this->Auth->loginAction = PE_AFFILIATE_LOGIN_URL;
		}
	}

/**
 * コントローラのアクションの後で、ビューが描画される前に呼ばれる。
 *
 * @return void
 * @link https://book.cakephp.org/2.0/ja/controllers.html#Controller::beforeRender
 */
	public function beforeRender() {
		parent::beforeRender();

		if ($this->request->is('json')) { // APIへのリクエスト
		} else {
			$this->helpers['Html'] = ['className' => 'BoostCake.BoostCakeHtml'];
			$this->helpers['Form'] = ['className' => 'MyForm'];
			$this->helpers['Paginator'] = ['className' => 'BoostCake.BoostCakePaginator'];
			$this->helpers['Time'] = ['className' => 'MyTime'];

			if (!empty($this->request->prefix)) { // admin/affiliate
				// レイアウトをセット
				$this->layout = $this->request->prefix;
			}
		}
	}

/**
 * 該当ユーザーがリクエスト内でリソースにアクセスすることが許可されるかを boolean で返す。
 *
 * @param array $user アクティブなユーザー
 * @return bool 許可されるか
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#controllerauthorize
 * @link https://book.cakephp.org/2/ja/tutorials-and-examples/blog-auth-example/auth.html#id4
 */
	public function isAuthorized($user = null) {
		// adminユーザだけが管理 functions にアクセス可能です。
		if (isset($this->request->params['admin'])) {
			return (bool)($user['role'] === 'admin');
		}
		// affiliateユーザだけがアフィリエイト会員向け functions にアクセス可能です。
		else if (isset($this->request->params['affiliate'])) {
			return (bool)($user['role'] === 'affiliate');
		}

		// デフォルトは拒否
		return false;
	}

/**
 * 認証済みの場合はリダイレクトさせるレスポンスを返す。
 *
 * @return CakeResponse|null
 */
	public function authenticated() {
		if (!$this->Auth->loggedIn()) {
			return;
		}

		$role = $this->Auth->user('role');
		$role2url = [
			'admin' => PE_URL_ADMIN_DASHBOARD,
			'business' => PE_URL_ADMIN_DASHBOARD,
			'affiliate' => PE_URL_AFFILIATE_PRODUCTS,
		];
		if (empty($role2url[$role])) {
			return;
		}
		$url = $role2url[$role];

		$this->Flash->info(__('You are logged in!'));

		return $this->redirect($url, 302, false);
	}

/**
 * APIのレスポンスを設定する。
 *
 * @param array $data データ
 * @param int $code HTTPステータスコード
 * @return void
 */
	protected function _setJsonResponse(array $data, $code = null) {
		$data['_serialize'] = array_keys($data);
		$data['_jsonOptions'] = JSON_NUMERIC_CHECK;
		$this->set($data);

		if ($code) {
			$this->response->statusCode($code);
		}
	}

/**
 * フラッシュメッセージでエラーを表示する。
 *
 * @param string $message メッセージ
 * @param array $fields 詳細メッセージを表示するフィールド
 * @return void
 */
	protected function renderError($message, array $fields = array()) {
		$details = array();
		foreach ($this->{$this->modelClass}->validationErrors as $field => $errors) {
			if (in_array($field, $fields)) {
				$details = array_merge($details, $errors);
			}
		}
		$this->Flash->error($message, array(
			'params' => compact('details'),
		));
	}
}

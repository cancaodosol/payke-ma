<?php
App::uses('AppController', 'Controller');

/**
 * AmazonPayRefunds Controller
 *
 * @property AmazonPayRefund $AmazonPayRefund
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class AmazonPayRefundsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_add method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException 外部APIでのエラー
 * @throws MethodNotAllowedException
 */
	public function admin_add($id = null) {
		$this->request->allowMethod('post');
		$this->AmazonPayRefund->create();
		$refund = $this->AmazonPayRefund->save($this->request->data, ['atomic' => false]);
		if (!$refund) { // Payke ECでのバリデーションエラー
			$message = __('The refund could not be saved. Please, try again.');
			$errors = $this->AmazonPayRefund->validationErrors;
			$this->response->statusCode(422);
			return $this->set(compact('errors', 'message'));
		}
		App::uses('AmazonPayRefund', 'Model');
		$message = AmazonPayRefund::translateStateDescription($refund);
		return $this->set(compact('message', 'refund'));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * PaidyPayments Controller
 */
class PaidyPaymentsController extends AppController {

	/**
	 * {@inheritdoc}
	 */
	public $components = array(
		'RequestHandler',
	);

	/**
	 * admin_view method
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_view($id = null) {
		$this->log([__METHOD__, $id], 'debug');
		$this->PaidyPayment->id = $id;
		$payment = $this->PaidyPayment->get();
		// $this->log([__METHOD__, $payment], 'debug');
		$this->_setJsonResponse(compact('payment'));
	}

	/**
	 * Paidyに払い戻しを依頼する。
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_refund($id = null) {
		$this->log([__METHOD__, $id, $this->request->data], 'debug');
		$this->request->allowMethod('post');
		$this->PaidyPayment->id = $id;
		$this->PaidyPayment->set($this->request->data);
		if (!$this->PaidyPayment->validates()) {
			$message = __('Validation error');
			$errors = $this->PaidyPayment->validationErrors;
			return $this->_setJsonResponse(compact('message', 'errors'), 400);
		}
		try {
			$payment = $this->PaidyPayment->refund();
		} catch (\Exception $ex) {
			$message = __('Error') . " ({$ex->getMessage()})";
			return $this->_setJsonResponse(compact('message'), 400);
		}
		$message = __('Paidy payment refunded');
		$this->_setJsonResponse(compact('message', 'payment'));
	}

}

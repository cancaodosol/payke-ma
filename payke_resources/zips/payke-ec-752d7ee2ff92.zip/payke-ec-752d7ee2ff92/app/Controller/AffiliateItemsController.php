<?php
App::uses('AppController', 'Controller');
/**
 * AffiliateItems Controller
 *
 * @property AffiliateItem $AffiliateItem
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class AffiliateItemsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * 該当ユーザーがリクエスト内でリソースにアクセスすることが許可されるかを boolean で返す。
 *
 * @param array $user アクティブなユーザー
 * @return bool 許可されるか
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#controllerauthorize
 * @link https://book.cakephp.org/2/ja/tutorials-and-examples/blog-auth-example/auth.html#id4
 */
	public function isAuthorized($user = null) {
		// $this->log($user, 'debug');

		// 設定のオーナーは編集や削除ができる
		if (in_array($this->action, array('affiliate_edit', 'affiliate_delete'))) {
			$id = (int) $this->request->params['pass'][0]; // https://book.cakephp.org/2/ja/development/routing.html#passed-arguments
			$result = $this->AffiliateItem->isOwnedBy($id, $user['id']);
			// $this->log($result, 'debug');
			return $result;
		}

		return parent::isAuthorized($user);
	}

/**
 * 商品のデータを読み込む。
 *
 * @return void
 * @throws BadRequestException
 * @throws NotFoundException
 */
	protected function _loadProductData() {
		// 最新の商品情報を取得
		if (empty($this->request->data[$this->AffiliateItem->alias]['product_id'])) {
			throw new BadRequestException(__('Invalid product'));
		}
		$product_id = $this->request->data[$this->AffiliateItem->alias]['product_id'];
		$params = array(
			'conditions' => array(
				$this->AffiliateItem->Product->alias.'.'.$this->AffiliateItem->Product->primaryKey => $product_id,
			),
			'recursive' => 0,
			'fields' => array(
				'name',
				'slug',
				'product_info',
				'product_purchase_url',
			),
		);
		$product = $this->AffiliateItem->Product->find('first', $params);
		if (!$product) {
			throw new NotFoundException(__('Invalid product'));
		}
		$this->request->data = Hash::merge($this->request->data, $product);
	}

/**
 * affiliate_add method
 *
 * @return void
 */
	public function affiliate_add() {
		if ($this->request->is('post')) {
			$this->_loadProductData();
			$this->AffiliateItem->create();
			if ($this->AffiliateItem->save($this->request->data)) {
				$this->Flash->success(__('The affiliate item has been saved.'));
				return $this->redirect(array(
					'controller' => 'products',
					'action' => 'index'
				));
			} else {
				$this->Flash->error(__('The affiliate item could not be saved. Please, try again.'));
			}
		} else {
			if ($this->request->query('product_id')) {
				// 商品一覧からのリクエストはここで処理される
				$affiliateItem = array(
					'affiliate_id' => $this->Auth->user('id'),
					'product_id' => $this->request->query('product_id'),
				);
				$this->request->data[$this->AffiliateItem->alias] = $affiliateItem;
			}
			$this->_loadProductData();
		}
	}

/**
 * affiliate_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function affiliate_edit($id = null) {
		if (!$this->AffiliateItem->exists($id)) {
			throw new NotFoundException(__('Invalid affiliate item'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->AffiliateItem->save($this->request->data)) {
				$this->Flash->success(__('The affiliate item has been saved.'));
				return $this->redirect(array(
					'controller' => 'products',
					'action' => 'index'
				));
			} else {
				$this->Flash->error(__('The affiliate item could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('AffiliateItem.' . $this->AffiliateItem->primaryKey => $id));
			$this->request->data = $this->AffiliateItem->find('first', $options);
		}
	}
}

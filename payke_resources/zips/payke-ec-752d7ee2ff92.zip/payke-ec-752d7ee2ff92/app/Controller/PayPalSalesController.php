<?php
App::uses('AppController', 'Controller');

/**
 * PayPalSales Controller
 */
class PayPalSalesController extends AppController {

	/**
	 * {@inheritdoc}
	 */
	public $components = array(
		'RequestHandler',
	);

	/**
	 * admin_view method
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_view($id = null) {
		$this->log([__METHOD__, $id], 'debug');
		$this->PayPalSale->id = $id;
		$sale = $this->PayPalSale->get();
		// $this->log([__METHOD__, $sale], 'debug');
		$this->_setJsonResponse(compact('sale'));
	}

	/**
	 * 返金する（払い戻す）。
	 *
	 * @param string $id
	 * @return void
	 */
	public function admin_refund($id = null) {
		$this->log([__METHOD__, $id, $this->request->data], 'debug');
		$this->request->allowMethod('post');
		$this->PayPalSale->id = $id;
		$this->PayPalSale->set($this->request->data);
		if (!$this->PayPalSale->validates()) {
			$message = __('Validation error');
			$errors = $this->PayPalSale->validationErrors;
			return $this->_setJsonResponse(compact('message', 'errors'), 400);
		}
		if (!$this->PayPalSale->refund($this->request->data)) {
			$message = __('Error') . " ({$this->PayPalSale->failureReason})";
			return $this->_setJsonResponse(compact('message'), 400);
		}
		$message = __('PayPal sale refunded');
		$sale = $this->PayPalSale->get();
		$this->_setJsonResponse(compact('message', 'sale'));
	}

}

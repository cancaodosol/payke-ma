<?php
App::uses('AppController', 'Controller');

/**
 * StripePrices Controller
 *
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class StripePricesController extends AppController {

/**
 * {@inheritdoc}
 */
	public $components = [
		'Flash',
		'RequestHandler',
		'Session',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// ゲスト（未ログイン）ユーザーに公開するアクション
		$this->Auth->allow('view');
	}

/**
 * view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function view($id = null) {
		$price = $this->StripePrice->read(null, $id);
		$this->set(compact('price'));
	}

/**
 * admin_index method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_index() {
		$filtered = array_only($this->request->query, [
			'active',
			'product',
			'type',
		]);
		$prices = $this->StripePrice->find('all', [
			'conditions' => $filtered,
			'limit' => $this->request->query('limit'),
		]);
		$this->set(compact('prices'));
	}

/**
 * admin_add method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->StripePrice->create();
			$result = $this->StripePrice->save($this->request->data, ['atomic' => false]);
			if (!$result) {
				$message = __('The price could not be saved. Please, try again.');
				$errors = $this->StripePrice->validationErrors;
				$this->response->statusCode(400);
				return $this->set(compact('errors', 'message'));
			}
			$message = __('The price has been saved.');
			$price = $result;
			$this->set(compact('message', 'price'));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_edit($id = null) {
		if ($this->request->is(array('post', 'put'))) {
			$this->StripePrice->id = $id;
			$result = $this->StripePrice->save($this->request->data, ['atomic' => false]);
			if (!$result) {
				$message = __('The price could not be saved. Please, try again.');
				$errors = $this->StripePrice->validationErrors;
				return $this->set(compact('errors', 'message'));
			}
			$message = __('The price has been saved.');
			$price = $result;
			$this->set(compact('message', 'price'));
		} else {
			$price = $this->StripePrice->read(null, $id);
			$this->set(compact('price'));
		}
	}

/**
 * admin_archive method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_archive($id = null) {
		return $this->_activate($id, false);
	}

/**
* admin_unarchive method
*
* @param string $id
* @return void
 * @throws ApiErrorException
*/
	public function admin_unarchive($id = null) {
		return $this->_activate($id);
	}

/**
* _activate method
*
* @param string $id
* @param boolean $active
* @return void
 * @throws ApiErrorException
*/
	protected function _activate($id = null, $active = true) {
		if ($this->request->is(array('post', 'put'))) {
			$this->request->data($this->StripePrice->alias, [
				$this->StripePrice->primaryKey => $id,
				'active' => $active,
			]);
			if ($this->StripePrice->save($this->request->data, ['atomic' => false])) {
				$this->Flash->success(__('The price has been updated.'));
			} else {
				$this->Flash->error(__('The price could not be updated. Please, try again.'));
			}
		}
		return $this->redirect($this->referer());
	}
}

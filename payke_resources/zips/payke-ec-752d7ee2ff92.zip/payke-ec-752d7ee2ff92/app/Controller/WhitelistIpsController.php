<?php
App::uses('AppController', 'Controller');
App::uses('MiddlewareHelper', 'Lib');

/**
 * WhitelistIps Controller
 *
 * @property WhitelistIp $WhitelistIp
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class WhitelistIpsController extends AppController {

	use MiddlewareHelper;

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Flash',
		'RequestHandler',
		'Session',
	];

	public $paginate = [
		'order' => [
			'WhitelistIp.created' => 'asc',
		],
	];

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		// ミドルウェア
		$this->loadModel('Middleware');
		$this->request->data = $this->Middleware->findByName('whitelist');
		$this->set('requestIp', $this->requestIp()); // 現在のIPアドレス

		// NOTE: 現在のIPアドレスを未登録、かつ、ONの状態になってしまった場合は、以下の手順で復旧できる。
		//  1. データベースへ直接接続し、whitelist_ipsテーブルへ自身のIPアドレスのレコードをINSERT
		//  2. キャッシュファイル app/tmp/cache/cake_whitelist_ips を削除

		// 許可IPアドレス
		$this->WhitelistIp->recursive = 0;
		$this->set('whitelistIps', $this->WhitelistIp->find('all', [
			'order' => ['WhitelistIp.id' => 'asc'],
		]));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->WhitelistIp->create();
			if ($this->WhitelistIp->save($this->request->data)) {
				$this->Flash->success(__('The whitelist ip has been saved.'));
				return;
			}
			$message = __('The whitelist ip could not be saved. Please, try again.');
			$errors = $this->WhitelistIp->validationErrors;
			$this->response->statusCode(400);
			$this->set(compact('errors', 'message'));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->WhitelistIp->exists($id)) {
			throw new NotFoundException(__('Invalid whitelist ip'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$this->WhitelistIp->set($this->request->data);
			if (!$this->WhitelistIp->validates()) {
				$message = __('The whitelist ip could not be saved. Please, try again.');
				$errors = $this->WhitelistIp->validationErrors;
				$this->response->statusCode(400);
				$this->set(compact('errors', 'message'));
				return;
			}
			if (!$this->_canSafelyUpdateWhitelist($id)) {
				$message = __('The whitelist ip could not be saved because you cannot access to the admin pages if you update it.');
				$errors = ['ip' => ['変更できません。']];
				$this->response->statusCode(400);
				$this->set(compact('errors', 'message'));
				return;
			}
			$options = ['validate' => false];
			$this->WhitelistIp->save($this->request->data, $options);
			$this->Flash->success(__('The whitelist ip has been saved.'));
		} else {
			$options = array('conditions' => array('WhitelistIp.' . $this->WhitelistIp->primaryKey => $id));
			$this->request->data = $this->WhitelistIp->find('first', $options);
		}
	}

/**
 * admin_delete method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		if (!$this->WhitelistIp->exists($id)) {
			throw new NotFoundException(__('Invalid whitelist ip'));
		}
		$this->request->allowMethod('post', 'delete');

		if (!$this->_canSafelyUpdateWhitelist($id)) {
			$this->Flash->error(__('The whitelist ip could not be deleted because you cannot access to the admin pages if you delete it.'));
		} else if (!$this->WhitelistIp->delete($id)) { // 削除
			$this->Flash->error(__('The whitelist ip could not be deleted. Please, try again.'));
		} else {
			$this->Flash->success(__('The whitelist ip has been deleted.'));
		}

		return $this->redirect(array('action' => 'index'));
	}

/**
 * 許可リストの更新/削除を処理して良いかどうかを調べる。
 *
 * @param string $id
 * @return bool
 */
	protected function _canSafelyUpdateWhitelist($id) {
		$this->loadModel('Middleware');
		if (!$this->Middleware->isEnabled('whitelist')) { // OFFの場合
			return true; // 削除できる
		}

		// 処理後も現在のIPが許可されるかどうか
		$ip = $this->requestIp();
		$ips = $this->WhitelistIp->list();
		if ($this->action === 'admin_edit') { // 更新の場合
			$ips[$id] = $this->request->data('WhitelistIp.ip'); // TODO: 合ってる？
		} elseif ($this->action === 'admin_delete') { // 削除の場合
			unset($ips[$id]);
		}
		$isWhitelisted = MiddlewareHelper::checkIp($ip, $ips);

		return $isWhitelisted;
	}

}

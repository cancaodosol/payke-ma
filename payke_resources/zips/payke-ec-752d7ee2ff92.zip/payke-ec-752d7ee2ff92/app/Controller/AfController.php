<?php
App::uses('AppController', 'Controller');

/**
 * Af Controller
 */
class AfController extends AppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = array('Product');

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Session',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// 未ログインユーザーによるアクセスを許可する
		$this->Auth->allow('index');
	}

/**
 * index method
 *
 * @param string $productId
 * @param string|null $aid
 * @return void
 * @throws BadRequestException
 * @throws NotFoundException
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::redirect
 */
	public function index($productId, $aid = null) {
		if (!$this->Product->exists($productId)) {
			throw new NotFoundException(__('Invalid product'));
		}

		$result = $this->Product->find('first', array(
			'conditions' => array(
				'Product.' . $this->Product->primaryKey => $productId,
				'Product.affiliate_object' => true,
			),
			'recursive' => -1,
			'fields' => array('product_purchase_url'),
		));

		if (empty($result)) {
			throw new BadRequestException(__('Not affiliate object'));
		}

		$url = $result['Product']['product_purchase_url'];
		if (empty($url)) {
			throw new BadRequestException(__('No product purchase URL'));
		}
		if (!empty($aid)) {
			$q = parse_url($url, PHP_URL_QUERY);
			$url = $url . ($q ? '&' : '?') . http_build_query(compact('aid'));
			$this->Session->write('Affiliate.aid', $aid); // セッションへも書き込む
		}

		return $this->redirect($url, 303);
	}

}

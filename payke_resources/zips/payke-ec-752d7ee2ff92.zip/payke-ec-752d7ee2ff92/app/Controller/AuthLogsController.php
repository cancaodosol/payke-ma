<?php
App::uses('AppController', 'Controller');
/**
 * AuthLogs Controller
 *
 * @property AuthLog $AuthLog
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class AuthLogsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Paginator',
		'Search.Prg' => [
			'commonProcess' => [
				'filterEmpty' => true,
			],
		],
		'Session',
		'Flash',
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'contain' => [
			'User' => [
				'fields' => ['name'],
				'Profile' => ['fields' => ['full_name']],
			],
		],
		'order' => [
			'AuthLog.request_time' => 'desc',
		],
		'paramType' => 'querystring',
	];

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = $this->paginate;
		$conditions = $this->AuthLog->parseCriteria($this->Prg->parsedParams());
		$this->Paginator->settings['conditions'] = $conditions;
		$this->set('authLogs', $this->Paginator->paginate());

		// フィルターの選択肢
		$this->set('results', AuthLog::results()); // 結果
		$this->set('users', $this->AuthLog->User->find('groupedList')); // ユーザ
	}
}

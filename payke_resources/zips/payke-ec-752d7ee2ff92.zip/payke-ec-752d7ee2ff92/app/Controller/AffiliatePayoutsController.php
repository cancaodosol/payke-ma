<?php
App::uses('AppController', 'Controller');
/**
 * AffiliatePayouts Controller
 *
 * @property AffiliatePayout $AffiliatePayout
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class AffiliatePayoutsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator',
		'Session',
		'CsvView.CsvView',
	);

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = array(
		'fields' => array(
			'month',
			'affiliate_result_count',
			'reward_amount',
			'payment_status',
		),
		'order' => array(
			'AffiliatePayout.month' => 'desc', // 発生年月の降順
		),
	);

	private $_admin_index_params = array(
		'contain' => array(
			'Affiliate' => array(
				'Profile' => array(
					'fields' => array(
						'full_name',
						'bank_name',
						'bank_branch_name',
						'bank_account_type',
						'bank_account_number',
						'bank_account_name_kana',
					),
				),
			),
		),
		'fields' => array(
			'id',
			'month',
			'affiliate_result_count',
			'reward_amount',
			'payment_status',
		),
		'order' => array(
			'AffiliatePayout.reward_amount' => 'desc',
		),
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_csv',
				'admin_sum',
			],
			'update' => [
				'admin_change_state',
			],
		]);
	}

/**
 * affiliate_index method
 *
 * @return void
 */
	public function affiliate_index() {
		$this->Paginator->settings = $this->paginate;
		$this->Paginator->settings['conditions'] = array(
			'AffiliatePayout.affiliate_id' => $this->Auth->user('id'), // ログインユーザ（アフィリエイト会員）
		);
		$this->set('affiliatePayouts', $this->Paginator->paginate());
	}

/**
 * 管理者向け 支払い管理画面
 *
 * @return void
 */
	public function admin_sum() {
		// https://book.cakephp.org/2/ja/models/virtual-fields.html#sql
		$this->AffiliatePayout->virtualFields = array(
			'affiliateResultCount' => 0,
			'rewardAmount' => 0,
		);
		$this->Paginator->settings = array(
			'contain' => false,
			'fields' => array(
				'month',
				'SUM(affiliate_result_count) AS AffiliatePayout__affiliateResultCount',
				'SUM(reward_amount) AS AffiliatePayout__rewardAmount',
			),
			'group' => array(
				'month',
			),
			'order' => array(
				'month' => 'desc',
			),
		);
		$this->set('affiliatePayouts', $this->Paginator->paginate());
	}

/**
 * 管理者向け 支払い詳細画面
 *
 * @return void
 */
	public function admin_index() {
		$this->Paginator->settings = $this->_admin_index_params;
		if ($month = $this->request->query('month')) {
			$this->Paginator->settings['conditions'] = array(
				'AffiliatePayout.month' => $month,
			);
			$this->set('month', $month);
		}
		$this->set('affiliatePayouts', $this->Paginator->paginate());
	}

/**
 * 管理者向け 支払い詳細画面 CSVダウンロード
 *
 * @return void
 */
	public function admin_csv() {
		$params = $this->_admin_index_params;
		if ($month = $this->request->query('month')) {
			$params['conditions'] = array(
				'AffiliatePayout.month' => $month,
			);
			$filename = 'affiliate_payouts_'.$month.'.csv';
		} else {
			$filename = 'affiliate_payouts.csv';
		}
		$results = $this->AffiliatePayout->find('all', $params);
		$results = $this->_appendLabels($results);

		$_serialize = 'results';
		$_null = '';
		$_header = array(
			'アフィリエイト会員',
			__('Bank Name'),
			__('Bank Branch Name'),
			__('Bank Account Type'),
			__('Bank Account Number'),
			__('Bank Account Name Kana'),
			__('Affiliate Result Count'),
			__('Reward Amount'),
			__('Payment Status'),
		);
		$_extract = array(
			'Affiliate.Profile.full_name',
			'Affiliate.Profile.bank_name',
			'Affiliate.Profile.bank_branch_name',
			'Affiliate.Profile.bank_account_type',
			'Affiliate.Profile.bank_account_number',
			'Affiliate.Profile.bank_account_name_kana',
			'AffiliatePayout.affiliate_result_count',
			'AffiliatePayout.reward_amount',
			'AffiliatePayout.payment_status',
		);

		$this->response->download($filename);
		$this->viewClass = 'ExcelCsv';
		$this->set(compact('results', '_serialize', '_null', '_header', '_extract'));
	}

	// コード値に対応する表示名を得るための情報を付加する。
	private function _appendLabels($results) {
		App::uses('AffiliatePayout', 'Model');
		foreach ($results as $key => $val) {
			$results[$key] = Hash::insert($results[$key], 'Affiliate.Profile.bank_account_type', bank_account_type_description($val['Affiliate']['Profile']['bank_account_type']));
			$results[$key] = Hash::insert($results[$key], 'AffiliatePayout.payment_status', AffiliatePayout::paymentStatusName($val));
		}

		return $results;
	}

/**
 * 管理者向け 支払い詳細画面 支払い状況の変更
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_change_state($id = null, $state = null) {
		$this->AffiliatePayout->id = $id;
		if (!$this->AffiliatePayout->exists()) {
			throw new NotFoundException(__('Invalid affiliate payout'));
		}
		$this->request->allowMethod('post', 'put');
		$data[$this->AffiliatePayout->alias]['payment_status'] = $state;
		if ($this->AffiliatePayout->save($data)) {
			$this->Flash->success(__('The state has been changed.'));
		} else {
			$this->Flash->error(__('The state could not be changed. Please, try again.'));
			if (isset($this->AffiliatePayout->failureReason)) {
				$this->Flash->error($this->AffiliatePayout->failureReason);
			}
		}
		return $this->redirect($this->referer());
	}
}

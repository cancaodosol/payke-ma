<?php
App::uses('AppController', 'Controller');
/**
 * AffiliateResults Controller
 *
 * @property AffiliateResult $AffiliateResult
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class AffiliateResultsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator',
		'Session',
		'Search.Prg' => array(
			'commonProcess' => array(
				'filterEmpty' => true,
			),
		),
	);

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = array(
		'contain' => array(
			'AffiliatePayout' => array(
				'fields' => array(
					'payment_status',
				),
			),
			'Order' => array(
				'fields' => array(
					'id',
					'product_id',
					'payment_method_id',
					'name',
					'paid_date',
					'quantity',
					'amount',
				),
			),
		),
		'fields' => array(
			'id', // for debug
			'date',
			'name',
			'reward',
			'approval_status',
		),
		'order' => array(
			'Order.paid_date' => 'desc', // 支払開始日時の降順
			'AffiliateResult.id' => 'desc', // IDの降順
		),
		'paramType' => 'querystring',
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_csv',
			],
		]);
	}

/**
 * affiliate_index method
 *
 * @return void
 */
	public function affiliate_index() {
		$this->Paginator->settings = $this->paginate;
		$this->Paginator->settings['conditions'] = array(
			'AffiliateResult.affiliate_id' => $this->Auth->user('id'), // ログインユーザ（アフィリエイト会員）
			'NOT' => array(
				'Order.paid_date' => null,
			),
		);
		$this->Paginator->settings['order'] = array(
			'AffiliateResult.date' => 'desc', // 発生日時の降順
		);
		$this->set('affiliateResults', $this->Paginator->paginate());
		$this->set('products', $this->AffiliateResult->Order->Product->find('list'));
		$this->set('paymentMethods', $this->AffiliateResult->Order->PaymentMethod->find('list'));
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = $this->paginate;
		$this->Paginator->settings['conditions'] = $this->AffiliateResult->parseCriteria($this->Prg->parsedParams());

		$affiliateResults = $this->Paginator->paginate();

		// 紹介者
		$affiliates = $this->AffiliateResult->Affiliate->find('list', array(
			'conditions' => array('role' => 'affiliate'),
			'contain' => array('Profile'),
			'fields' => array('Profile.full_name'),
			'order' => array('Profile.full_name'),
		));

		$products = $this->AffiliateResult->Order->Product->find('list');
		$paymentMethods = $this->AffiliateResult->Order->PaymentMethod->find('list');

		$this->set(compact('affiliateResults', 'affiliates', 'products', 'paymentMethods'));
	}

	/**
	 * 管理者向け アフィリエイト成果 CSVダウンロード
	 *
	 * @return void
	 */
	public function admin_csv() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = $this->paginate;
		$this->Paginator->settings['conditions'] = $this->AffiliateResult->parseCriteria($this->Prg->parsedParams());
		$this->Paginator->settings['limit'] = PHP_INT_MAX;
		$this->Paginator->settings['maxLimit'] = PHP_INT_MAX;

		$results = $this->Paginator->paginate();
		$results = $this->_formatValues($results);

		$_serialize = 'results';
		$_null = '';
		$_header = array(
			__('Id'),
			'発生日時',
			__('Reward'),
		);
		$_extract = array(
			'AffiliateResult.id',
			'AffiliateResult.date',
			'AffiliateResult.reward',
		);

		$this->response->download('affiliate_results.csv');
		$this->viewClass = 'ExcelCsv';
		$this->set(compact('results', '_serialize', '_null', '_header', '_extract'));
	}

	/**
	 * 値の整形を行う。
	 * @param array $rows 全行
	 * @return array 全行
	 */
	protected function _formatValues($rows) {
		$timeFormatter = function ($value) {
			return CakeTime::format($value, CAKETIME_FORMAT);
		};

		$formatters = array(
			'AffiliateResult.date' => $timeFormatter,
		);

		foreach ($rows as $index => $row) {
			foreach ($formatters as $path => $formatter) {
				$value = Hash::get($row, $path);
				if (is_callable($formatter)) {
					$value = $formatter($value);
				}
				$row = Hash::insert($row, $path, $value);
				$rows[$index] = $row;
			}
		}

		return $rows;
	}

}

<?php
App::uses('AppController', 'Controller');
App::uses('StripeWebhookEvent', 'Model');

/**
 * StripeEvents Controller
 *
 * @property StripeEvent $StripeEvent
 * @property RequestHandlerComponent $RequestHandler
 * @link https://stripe.com/docs/webhooks
 * @link https://stripe.com/docs/webhooks/quickstart
 * @link https://stripe.com/docs/webhooks/signatures
 * @link https://stripe.com/docs/webhooks/best-practices
 * @link https://stripe.com/docs/billing/subscriptions/build-subscription?ui=checkout#provision-and-monitor
 */
class StripeEventsController extends AppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'StripeWebhookEvent',
		'Config',
	];

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'RequestHandler',
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// Stripe が未認証の POST リクエストを送信できるように、パブリックアクセス可能な状態にする
		$this->Auth->allow('process');

		// CSRF 保護から除外 https://stripe.com/docs/webhooks/best-practices#csrf-protection
		// [指定したアクションの CSRF とデータバリデーションの無効化](https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id12)
		$this->Security->unlockedActions = [
			'process'
		];
	}

/**
 * 署名を検証する。
 *
 * @return void
 * @throws BadRequestException
 * @throws ForbiddenException
 */
	protected function _verifySignature() {
		$payload = @file_get_contents('php://input');
		$sigHeader = env('HTTP_STRIPE_SIGNATURE');
		$endpointSecret = $this->Config->get('stripe_webhook_secret');
		$event = null;
		try {
			$event = \Stripe\Webhook::constructEvent(
				$payload, $sigHeader, $endpointSecret
			);
		} catch(\Stripe\UnexpectedValueException $e) {
			// Invalid payload
			throw new BadRequestException($e->getMessage());
		} catch(\Stripe\Exception\SignatureVerificationException $e) {
			// Invalid signature
			// NOTE: 以下で403エラーにしているのを参考にした。
			// https://stripe.com/docs/billing/subscriptions/build-subscription?ui=checkout#provision-and-monitor
			throw new ForbiddenException($e->getMessage());
		}
		$this->log('Event: ' . \json_encode($event), 'stripe-webhook');
	}

/**
 * Stripe からのリクエストを処理する。
 * - Webhookイベントが生成された順序で配信されるとは限らない。https://stripe.com/docs/webhooks/best-practices#event-ordering
 * - Stripeの1アカウントを複数のPayke ECや別システム等で共用する運用はあり得る。
 *
 * @return void
 * @throws BadRequestException
 * @throws ForbiddenException
 * @throws InternalErrorException
 * @throws MethodNotAllowedException
 */
	public function process() {
		$this->request->allowMethod('post');

		// 署名を検証
		$this->_verifySignature();

		// 処理対象か否かを確認
		$type = $this->request->data('type');
		if (empty(StripeWebhookEvent::handler($type))) {
			$message = "Unsupported event type: {$type}";
			$this->log($message, 'warning');
			return $this->set(compact('message'));
		}

		// 既存を確認
		$id = $this->request->data('id');
		if ($this->StripeWebhookEvent->exists($id)) { // 過去に受信して保存済の場合
			$message = 'The webhook event is redundant';
			$this->log($message, 'info');
			return $this->set(compact('message'));
		}

		// 保存
		$this->StripeWebhookEvent->create();
		if (!$this->StripeWebhookEvent->save($this->request->data)) {
			$this->log($this->StripeWebhookEvent->validationErrors);
			throw new InternalErrorException('The webhook event could not be saved.');
		}

		// 処理結果
		$message = $this->StripeWebhookEvent->field('status');

		$this->set(compact('message'));
	}
}

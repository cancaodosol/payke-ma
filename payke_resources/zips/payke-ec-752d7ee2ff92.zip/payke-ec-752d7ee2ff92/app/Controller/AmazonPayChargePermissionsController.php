<?php
App::uses('AppController', 'Controller');

/**
 * AmazonPayChargePermissions Controller
 *
 * @property AmazonPayChargePermission $AmazonPayChargePermission
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 * @link https://amazonpay-onboarding.com/specification/api/charge-permission/
 * @link https://developer.amazon.com/ja/docs/amazon-pay-api-v2/charge-permission.html
 */
class AmazonPayChargePermissionsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id) {
		$this->AmazonPayChargePermission->read(null, $id);
		$this->AmazonPayChargePermission->updateReference(); // Charge Permission の状態を保持するオブジェクトへ反映
		$chargePermission = $this->AmazonPayChargePermission->modifiedData(); // 表示用に編集したデータを取得
		$this->set(compact('chargePermission'));
	}

/**
 * admin_close method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 * @throws MethodNotAllowedException
 */
	public function admin_close($id = null) {
		$this->request->allowMethod('post');

		// バリデーション
		$this->AmazonPayChargePermission->set($this->request->data);
		$valid = $this->AmazonPayChargePermission->validates([
			'fieldList' => ['closureReason', 'cancelPendingCharges'],
		]);
		if (!$valid) {
			$this->Flash->error(__('The Charge Permission could not be closed. Please, try again.'));
			return;
		}

		// クローズ
		$this->AmazonPayChargePermission->id = $id;
		$this->AmazonPayChargePermission->close($this->request->data);
		$this->AmazonPayChargePermission->updateReference(); // Charge Permission の状態を保持するオブジェクトへ反映
		$this->request->data = $this->AmazonPayChargePermission->modifiedData(); // 表示用に編集したデータを取得
		$this->Flash->success(__('The Charge Permission has been closed.'));
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * CustomFields Controller
 *
 * @property CustomField $CustomField
 * @property PaginatorComponent $Paginator
 */
class CustomFieldsController extends AppController {

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_values',
			],
		]);
	}

/**
 * 値の一覧を表示する。
 *
 * @param string $id フィールドのID
 * @return void
 * @throws NotFoundException
 */
	public function admin_values($id = null) {
		if (!$this->CustomField->exists($id)) {
			throw new NotFoundException(__('Invalid custom field'));
		}
		$contain = [
			'CustomFieldValue' => [
				'conditions' => [
					'LENGTH(TRIM(CustomFieldValue.value)) > ' => 0,
				],
				'fields' => ['value'],
			],
		];
		if ($this->request->query('fixed')) { // デフォルト項目の場合
			$name = $this->request->query('name'); // 項目名
			$contain = [
				'Questionnaire' => [
					'QuestionnaireAnswer' => [
						'Order' => [
							'conditions' => [
								"LENGTH(TRIM(Order.{$name})) > " => 0,
							],
							'fields' => [$name],
						],
					],
				],
			];
		}
		$options = [
			'conditions' => [
				"{$this->CustomField->alias}.{$this->CustomField->primaryKey}" => $id,
			],
			'contain' => $contain,
			'fields' => ['id', 'name', 'label', 'fixed'],
		];
		$this->set('customField', $this->CustomField->find('first', $options));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * Orders Controller
 *
 * @property Order $Order
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 * @property CartManager $CartManager
 */
class OrdersController extends AppController {

/**
 * このコントローラが使うクラスの名前の配列。
 *
 * @var bool|array
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::$uses
 */
	public $uses = [
		'Order',
		'Payment',
	];

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator',
		'RequestHandler',
		'Session',
		'Search.Prg' => array(
			'commonProcess' => array(
				'filterEmpty' => true,
			),
		),
		'CartManager',
		'CsvView.CsvView',
	);

	protected $_contain = array(
		'AffiliateResult' => array(
			'Affiliate' => array(
				'fields' => array(
				),
				'Profile' => array(
					'fields' => array(
						'full_name',
					),
				),
			),
			'fields' => array(
				'id',
				'approval_status',
			),
		),
		'CustomFieldValue' => array(
			'fields' => array('value'),
		),
		'OrderReference' => [
			'fields' => ['type', 'state', 'state_reasons'],
		],
		'Payment' => [
			'fields' => ['paid_date', 'amount'],
		],
		'PaymentMethod' => array(
			'fields' => array(
				'name',
			),
		),
		'Product' => array(
			'fields' => array(
				'name',
				'affiliate_object',
				'affiliate_reward',
			),
		),
		'QuestionnaireAnswer' => [
			'fields' => ['id', 'answered'],
		],
	);

/**
 * beforeFilter callback
 *
 * @return void
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// ゲスト（未ログイン）ユーザーに公開するアクション
		$this->Auth->allow([
			'add',
			'edit',
			'confirm',
			'complete',
			'set_reference',
			'cancel',
		]);

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_csv',
				'admin_list_products',
				'admin_payments',
			],
			'update' => [
				'admin_cancel_booking',
				'cancel',
			],
		]);

		// CSRF トークンの有効期限をビューへ渡す
		$this->set('csrfExpires', strtotime($this->Security->csrfExpires));
	}

/**
 * add method
 *
 * @param string|null $slug スラッグ
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function add($slug = null) {
		if ($this->request->is(array('post', 'put'))) {
			$this->log('Creating order', 'debug');
			$this->CartManager->loadProduct();
			$this->CartManager->calculate();
			$this->CartManager->setPaymentDetails();
			$this->RequestModifier = $this->Components->load('RequestModifier');
			$this->RequestModifier->initialize($this);
			$this->RequestModifier->modify([
				'Order.customer_first_name_kana' => 'convert_kana',
				'Order.customer_last_name_kana' => 'convert_kana',
			]);

			// 購入可能な商品であるかチェック
			$this->Order->create();
			if(!$this->_canOrderProduct($this->request->data)) {
				$this->set([
						'title' => 'ご購入いただけない商品です。',
						'message' => $this->request->data['Product']['message_for_unorderable'],
						'sctaNotation' => [
							'id' => NULL,
						],
					]);
				return $this->render('error');
			}

			// 注文を作成
			if ($this->Order->saveDraft($this->request->data)) {
				// 確認画面へリダイレクト
				return $this->redirect([
					'action' => 'confirm',
					'uuid' => $this->Order->field('uuid'),
				]);
			} else {
				$this->Flash->error('入力内容をご確認ください。');
			}
		} else {
			$this->CartManager->add($slug);
			$this->CartManager->checkInStock();
		}
		$this->CartManager->loadProduct();
		$this->CartManager->calculate();
		$this->CartManager->loadPurchaseData(true);
	}

/**
 * edit method
 *
 * @param string $uuid UUID
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function edit($uuid) {
		$data = $this->CartManager->loadOrder($uuid);
		if ($this->request->is(array('post', 'put'))) {
			$this->log('Updating order', 'debug');
			$this->CartManager->loadProduct();
			$this->CartManager->calculate();
			$this->CartManager->setPaymentDetails();
			$this->RequestModifier = $this->Components->load('RequestModifier');
			$this->RequestModifier->initialize($this);
			$this->RequestModifier->modify([
				'Order.customer_first_name_kana' => 'convert_kana',
				'Order.customer_last_name_kana' => 'convert_kana',
			]);
			// 購入可能な商品であるかチェック
			if(!$this->_canOrderProduct($this->request->data)) {
				$this->set([
						'title' => 'ご購入いただけない商品です。',
						'message' => $this->request->data['Product']['message_for_unorderable'],
					]);
				return $this->render('error');
			}
			// 注文を更新
			if ($this->Order->saveDraft($this->request->data)) {
				// 確認画面へリダイレクト
				return $this->redirect([
					'action' => 'confirm',
					'uuid' => $this->Order->field('uuid'),
				]);
			} else {
				$this->Flash->error('入力内容をご確認ください。');
			}
		} else {
			$this->request->data = $data;
		}
		if ($this->CartManager->isStatusEmpty()) {
			$this->CartManager->loadProduct();
			$this->CartManager->calculate();
		}
		$this->CartManager->loadPurchaseData(true);
	}

/**
 * この商品を購入できるか判定する。
 * 1. 複数購入禁止の商品の場合、以前にも購入しているかチェックする。
 * 
 * @param array $data リクエストデータ
 * @return bool 購入できる商品ならtrue
 */
	protected function _canOrderProduct(array $data)
	{
		if($data['Product']['can_order_only_once'] != 1) return true;

		$customer_phone = 
			empty($data['Order']['customer_phone']) ? '' : format_phone_number($data['Order']['customer_phone']);
		
		$option_or = [["{$this->Order->alias}.customer_email" => $data['Order']['customer_email']]];
		if($customer_phone != '')
		{
			$option_or[] = ["{$this->Order->alias}.customer_phone" => $customer_phone];
		}

		$options = [
			'conditions' => [
				"{$this->Order->alias}.product_id" => $data['Order']['product_id'],
				'NOT' => [
					'status' => NULL
				],
				'OR' => $option_or,
			],
		];
		$orders_count = $this->Order->find('count', $options);
		
		return $orders_count == 0;
	}

/**
 * confirm method
 *
 * @param string|null $uuid UUID
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function confirm($uuid = null) {
		$data = $this->CartManager->loadOrder($uuid);
		if ($this->request->data('checkout')) { // 確認ページに設置した支払いボタンが押された場合
			$baseUrl = Router::url([], true); // 戻り先となるURL
			if ($approvalUrl = $this->Order->checkout($data, $baseUrl)) {
				// 決済サービスのURLへリダイレクト
				$this->log('Redirecting to payment service URL to check out', 'debug');
				return $this->redirect($approvalUrl);
			} else {
				if (!empty($this->Order->data['failure_reason'])) {
					$this->Flash->error("エラーが発生しました。({$this->Order->data['failure_reason']})");
				}
			}
		} elseif ($this->request->data('book')) { // 決済前予約登録
			if ($this->Order->book($this->request->data)) {
				// 完了画面へリダイレクト
				return $this->redirect([
					'action' => 'complete',
					$this->Order->id,
				]);
			} else {
				$this->Flash->error('入力内容をご確認ください。');
			}
		} elseif ($this->request->is(array('post', 'put'))) {
			// 注文を確定
			if ($this->Order->place($this->request->data, $data)) {
				// 注文確定後のリダイレクト
				$url = $this->CartManager->redirectUrl($data);
				return $this->redirect($url);
			} else {
				if (!empty($this->Order->data['failure_reason'])) {
					$this->Flash->error($this->Order->data['failure_reason']);
					if (!empty($this->Order->data['order_reference_state'])) {
						$this->set('orderReferenceState', $this->Order->data['order_reference_state']);
					}
				}
				foreach ($this->Order->validationErrors as $modelName => $fields) {
					foreach ($fields as $fieldName => $message) {
						$this->Flash->error($message);
					}
				}
			}
		} else {
			// クエリーパラメータを処理
			$this->CartManager->detectCheckout($data);
		}
		$this->request->data = Hash::merge($data, $this->request->data);
		$this->CartManager->loadPurchaseData();
	}

/**
 * complete method
 *
 * @param string $id ID
 * @return CakeResponse
 * @throws NotFoundException
 */
	public function complete($id = null) {
		if (!$this->Order->exists($id)) {
			throw new NotFoundException(__('Invalid order'));
		}
		$this->set('order', $this->Order->read(['status'], $id));
	}

/**
 * Authorizeされた決済データを検証して決済IDを保存する。
 *
 * @param string $uuid 注文のUUID
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws NotFoundException
 * @throws ForbiddenException
 */
	public function set_reference($uuid) {
		// $this->log([__METHOD__, $uuid, $this->request->data], 'debug');
		$this->request->allowMethod('post');
		$this->loadModel('PaidyPayment');
		$this->PaidyPayment->id = $this->request->data('id');
		$payment = $this->PaidyPayment->get();
		$data = $this->Order->find('first', [
			'conditions' => ['Order.uuid' => $uuid],
			'contain' => false,
			'fields' => ['id', 'amount'],
		]);
		if ($payment['amount'] != $data[$this->Order->alias]['amount']) {
			$message = 'Invalid amount.';
			return $this->_setJsonResponse(compact('message'), 400);
		}
		$this->Order->id = $data[$this->Order->alias]['id'];
		$result = $this->Order->saveField('reference_id', $payment['id']);
		if (!$result) {
			$message = 'Failed to set payment id to reference_id.';
			return $this->_setJsonResponse(compact('message'), 400);
		}
		$message = 'Authorized payment verified.';
		$this->_setJsonResponse(compact('message'));
	}

/**
 * 顧客によるキャンセル。
 * GETの場合、キャンセル用ページを表示する。
 * PUTの場合、キャンセルを行う。
 *
 * @param string $uuid 注文の UUID 。推測されやすい ID ではなく UUID で受け付ける。
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws MethodNotAllowedException
 * @throws NotFoundException
 * @link https://crud.readthedocs.io/en/cake3/configuration.html
 * @link https://crud.readthedocs.io/en/cake3/actions/edit.html
 */
	public function cancel($uuid) {
		$id = $this->Order->primaryKeyValue(compact('uuid')); // 引数をもとにIDを取得

		// Crud.Edit アクションをベースにカスタマイズ
		$this->Crud->mapAction($action = 'cancel', $settings = [
			'className' => 'Crud.Edit', // Crud.EditCrudAction を使う
			'findMethod' => 'forCancel', // デフォルトの find('first') の替わりに find('forCancel') を使う（GETの場合）
			'saveMethod' => 'cancel', // デフォルトの saveAssociated() の替わりに cancel() を使う（PUTの場合）
			'relatedModels' => false, // 選択肢用の関連モデルを取得しない（GETの場合）
			'messages' => [
				'success' => [
					'element' => 'Flash/success',
					'text' => __('The order has been canceled.'),
				],
				'error' => [
					'element' => 'Flash/error',
					'text' => __('The order could not be canceled.'),
				],
			],
		]);

		// cancel() 前処理（PUTの場合）
		$this->Crud->on('beforeSave', function(CakeEvent $event) {
			$this->request->data("{$this->Order->alias}.is_canceled_by_customer", true);
		});

		// cancel() 後処理（PUTの場合）
		$this->Crud->on('afterSave', function(CakeEvent $event) use ($id) {
			if (!$event->subject->success) { // 失敗した場合
				$this->request->data = $this->Order->find('forCancel', [
					'conditions' => [
						"{$this->Order->alias}.{$this->Order->primaryKey}" => $id,
					],
				]);
			}
		});

		// cancel() 成功後のリダイレクト前処理（PUTの場合）
		$this->Crud->on('beforeRedirect', function(CakeEvent $event) {
			$event->subject->url = $this->request->referer();
		});

		return $this->Crud->execute(null, [$id]);
	}

/**
 * admin_index method
 *
 * @return CakeResponse|null
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = array(
			'conditions' => $this->Order->parseCriteria($this->Prg->parsedParams()),
			'contain' => $this->_contain,
			'fields' => array(
				'id',
				'customer_name',
				'quantity',
				'amount',
				'amount_received',
				'payment_cycles',
				'payment_method_id',
				'payment_plan_id',
				'status',
				'checkout_session_id',
				'reference_id',
				'order_date',
				'paid_date',
				'created',
			),
			'order' => array(
				'Order.created' => 'desc',
			),
			'paramType' => 'querystring',
		);
		$this->Order->addVirtualFields(['amount_received']);

		$orders = $this->Paginator->paginate();
		$affiliates = $this->Order->AffiliateResult->Affiliate->find('list', array(
			'fields' => array('Profile.full_name'),
			'conditions' => array('role' => 'affiliate'),
			'contain' => array('Profile'),
			'order' => array('Profile.full_name'),
		));
		$paymentMethods = $this->Order->PaymentPlan->PaymentMethod->find('list');
		$paymentMethods['null'] = '空白';

		$this->set(compact('orders', 'affiliates', 'paymentMethods'));
	}

/**
 * admin_csv method
 *
 * @return void
 */
	public function admin_csv() {
		$this->_contain += array(
			'ProductOption' => array(
				'fields' => array(
					'name',
				),
			),
		);
		if ($this->request->query('purchase_type') == PE_PURCHASE_TYPE_BUNDLE) {
			// 子商品も含める
			$this->_contain += [
				'OrderItem' => [
					'fields' => [
						'product_id', 'name', 'price', 'quantity', 'amount', 'is_tax_reduced',
					],
				],
			];
			$this->_contain['Product'] += ['Item' => ['fields' => ['id']]]; // 子商品の情報
		}
		$this->Prg->commonProcess();
		$params = array(
			'conditions' => $this->Order->parseCriteria($this->Prg->parsedParams()),
			'contain' => $this->_contain,
			'order' => array(
				'created' => 'desc',
			),
		);
		$this->Order->addVirtualFields(['amount_received']);
		$orders = $this->Order->find('all', $params);
		$orders = $this->_appendLabels($orders);
		$orders = $this->_formatValues($orders);
		if ($this->request->query('purchase_type') == PE_PURCHASE_TYPE_BUNDLE) {
			// 子商品も含める
			$this->_reorderOrderItems($orders); // 明細の再配置
		}

		$_serialize = 'orders';
		$_null = '';
		// $_bom = true;
		$_header = array(
			__('Order ID'),
			__('Order UUID'),
			__('Product'),
			__('Product Option'),
			__('Customer Name'),
			__('Customer Name Kana'),
			__('Customer Email'),
			__('Customer Zip Code'),
			__('Customer Prefecture'),
			__('Customer Address'),
			__('Customer Phone'),
			__('Customer Gender'),
			__('Customer Birth Date'),
			'arg1',
			'arg2',
			'arg3',
			'arg4',
			'arg5',
			__('Quantity'),
			__('Is Tax Reduced'),
			__('Base Amount'),
			__('Tax Amount'),
			__('Amount'),
			__('Amount Received'),
			__('Payment Method'),
			__('Cycles'),
			__('Reference ID'),
			__('Status'),
			__('Order Date'),
			__('Payment Start Date'),
			__('Cancel Date'),
		);
		$_extract = array(
			'Order.id',
			'Order.uuid',
			'Product.name',
			'ProductOption.name',
			'Order.customer_name',
			'Order.customer_name_kana',
			'Order.customer_email',
			'Order.customer_zip_code',
			'Order.customer_prefecture',
			'Order.customer_address',
			'Order.customer_phone',
			'Order.customer_gender',
			'Order.customer_birth_date',
			'Order.arg1',
			'Order.arg2',
			'Order.arg3',
			'Order.arg4',
			'Order.arg5',
			'Order.quantity',
			'Order.is_tax_reduced',
			'Order.base_amount',
			'Order.tax_amount',
			'Order.amount',
			'Order.amount_received',
			'PaymentMethod.name',
			'payment_cycles',
			'Order.reference_id',
			'Status.name',
			'Order.order_date',
			'Order.paid_date',
			'Order.cancel_date',
		);

		if (Configure::check('KoryoEC.Affiliate')) {
			// アフィリエイト
			array_push($_header,
				'紹介者',
				__('Approval Status')
			);
			array_push($_extract,
				'AffiliateResult.0.Affiliate.Profile.full_name',
				'AffiliateStatus.name'
			);
		}

		if ($this->request->query('purchase_type') == PE_PURCHASE_TYPE_BUNDLE) {
			// 子商品も含める
			$maxNumOfItems = array_reduce($orders, function ($carry, $order) {
				return max($carry, count($order['Product']['Item']));
			}, 0);
			for ($i = 0, $n = 1; $i < $maxNumOfItems; $i++, $n++) {
				$_header[] = "商品名{$n}";
				$_header[] = "単価{$n}";
				$_header[] = "軽減税率適用{$n}";
				$_header[] = "数量{$n}";
				$_header[] = "小計{$n}";
				$_extract[] = "OrderItem.{$i}.name";
				$_extract[] = "OrderItem.{$i}.price";
				$_extract[] = "OrderItem.{$i}.is_tax_reduced";
				$_extract[] = "OrderItem.{$i}.quantity";
				$_extract[] = "OrderItem.{$i}.amount";
			}
		}

		// カスタムフィールド
		$maxNumOfCustomFieldValues = array_reduce($orders, function ($carry, $order) {
			return max($carry, count($order['CustomFieldValue']));
		}, 0);
		for ($i = 0, $n = 1; $i < $maxNumOfCustomFieldValues; $i++, $n++) {
			$_header[] = "値{$n}";
			$_extract[] = "CustomFieldValue.{$i}.value";
		}

		// 分割
		$_header[] = 'メモ';
		$_extract[] = 'Order.payment_memo';
		for ($i = 0, $n = 1; $n <= PE_ORDER_NUM_OF_PAYMENTS_MAX; $i++, $n++) {
			$_header[] = "決済方法{$n}";
			$_header[] = "支払日{$n}";
			$_header[] = "支払額{$n}";
			$_extract[] = "Payment.{$i}.PaymentMethod.name";
			$_extract[] = "Payment.{$i}.paid_date";
			$_extract[] = "Payment.{$i}.amount";
		}

		$this->response->download('orders.csv');
		$this->viewClass = 'ExcelCsv';
		// $this->set(compact('orders', '_serialize', '_bom', '_extract'));
		$this->set(compact('orders', '_serialize', '_null', '_header', '_extract'));
	}

/**
 * コード値に対応する表示名を付加する。
 *
 * @param array $results 検索結果
 * @return array
 */
	protected function _appendLabels($results) {
		App::uses('AffiliateResult', 'Model');

		foreach ($results as $key => $val) {
			$results[$key] = Hash::insert($results[$key], 'Status.name', Util::statusName($val['Order']));
			$results[$key] = Hash::insert($results[$key], 'AffiliateStatus.name', AffiliateResult::translateStatus(Hash::get($val, 'AffiliateResult.0')));
			$results[$key] = Hash::insert($results[$key], 'payment_cycles', order_payment_cycles_desc($val));
		}

		return $results;
	}

/**
 * 数値、日付、日時などを整形する。
 *
 * @param array $rows 検索結果
 * @return array
 */
	protected function _formatValues($rows) {
		$boolFormatter = function ($value) {
			return is_bool($value) ? var_export($value, true) : $value;
		};
		$timeFormatter = function ($value) {
			return CakeTime::format($value, CAKETIME_FORMAT);
		};
		$dateFormatter = function ($value) {
			return CakeTime::format($value, CAKEDATE_FORMAT);
		};

		$formatters = array(
			'Order.is_tax_reduced' => $boolFormatter,
			'Order.amount_received' => 'intval',
			'Order.order_date' => $timeFormatter,
			'Order.paid_date' => $timeFormatter,
			'Order.cancel_date' => $timeFormatter,
			'Order.customer_birth_date' => $dateFormatter,
			'OrderItem.{n}.is_tax_reduced' => $boolFormatter,
			'Payment.{n}.paid_date' => $dateFormatter,
		);

		foreach ($rows as $index => $row) {
			foreach ($formatters as $path => $formatter) {
				$values = Hash::extract($row, $path);
				if (empty($values)) { // 値が NULL の場合
					$values = [null]; // Hash::extract の戻り値が [] になってしまう問題への回避策
				}
				foreach ($values as $n => $value) {
					if (is_callable($formatter)) {
						$value = $formatter($value);
					}
					$actualPath = str_replace('{n}', "$n", $path);
					$row = Hash::insert($row, $actualPath, $value);
				}
				$rows[$index] = $row;
			}
		}

		return $rows;
	}

/**
 * 子商品の定義順に従い、明細の配列の要素を再配置する。
 *
 * @param array &$rows 検索結果
 * @return void
 */
	protected function _reorderOrderItems(array &$rows) {
		array_walk($rows, function (&$row) {
			$orderItems = $row['OrderItem'];
			if (empty($orderItems)) {
				return;
			}
			$reorderd = [];
			foreach ($row['Product']['Item'] as $item) { // 子商品の定義順
				$reorderd[] = my_array_search($orderItems, [
					'product_id' => $item['id'],
				]);
			}
			$row['OrderItem'] = $reorderd;
		});
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_view($id = null) {
		if (!$this->Order->exists($id)) {
			throw new NotFoundException();
		}
		$this->Order->id = $id;
		$this->request->data = $this->Order->find('forEdit');
		$affiliates = $this->Order->AffiliateResult->Affiliate->listAffiliates();
		$paymentMethods = $this->Order->PaymentPlan->PaymentMethod->find('list');
		$this->set(compact('affiliates', 'paymentMethods'));
		if ($this->Auth->user('role') === 'admin') { // 管理者
			// 変更ログ一覧
			$this->set('changeLogs', $this->Order->ChangeLog->find('forModel', [
				'conditions' => ['model' => $this->Order->alias, 'foreign_key' => $id],
			]));
		}
	}

/**
 * admin_edit method
 *
 * @param string $id ID
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->Order->exists($id)) {
			throw new NotFoundException(__('Invalid order'));
		}
		if ($this->request->is(array('post', 'put'))) {
			// 更新
			if ($this->Order->updateAssociated($this->request->data)) {
				$this->Flash->success(__('The order has been saved.'));
				return $this->redirect([
					'action' => 'view',
					$id,
				]);
			} else {
				$this->Flash->error(__('The order could not be saved. Please, try again.'));
			}
		}
		$this->Order->id = $id;
		$order = $this->Order->find('forEdit');
		$this->request->data = Hash::merge($order, $this->request->data);
		$affiliates = $this->Order->AffiliateResult->Affiliate->listAffiliates();
		$paymentMethods = $this->Order->PaymentPlan->PaymentMethod->find('list');
		$this->set(compact('affiliates', 'paymentMethods'));
		if ($this->Auth->user('role') === 'admin') { // 管理者
			// 変更ログ一覧
			$this->set('changeLogs', $this->Order->ChangeLog->find('forModel', [
				'conditions' => ['model' => $this->Order->alias, 'foreign_key' => $id],
			]));
		}
	}

/**
 * admin_delete method
 *
 * @param string $id ID
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		$this->Order->id = $id;
		if (!$this->Order->exists()) {
			throw new NotFoundException(__('Invalid order'));
		}
		$this->request->allowMethod('post', 'delete');
		$data = $this->Order->find('first', [
			'conditions' => ['Order.id' => $id],
			'contain' => false,
		]);
		if (!Order::isDeletable($data)) {
			$this->Flash->error(__('%s is not the state that can be deleted.', $id));
		} elseif ($this->Order->delete()) {
			$this->Flash->success(__('The order has been deleted.'));
		} else {
			$this->Flash->error(__('The order could not be deleted. Please, try again.'));
		}
		return $this->redirect(PE_URL_ADMIN_ORDERS);
	}

/**
 * admin_payments method
 *
 * @param string $id ID
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function admin_payments($id = null) {
		if (!$this->Order->exists($id)) {
			throw new NotFoundException(__('Invalid order'));
		}
		$message = null;
		if ($this->request->is(['post', 'put'])) {
			// $this->log([__METHOD__, $id, $this->request->data], 'debug');
			if (!$this->Order->savePayments($this->request->data)) {
				$message = __('The payments could not be saved. Please, try again.');
				$errors = $this->Order->validationErrors;
				return $this->_setJsonResponse(compact('message', 'errors'), 400);
			}
			// $this->log($this->Order->getDataSource()->getLog(), 'debug');
			$message = __('The payments have been saved.');
			$event = new CakeEvent('Controller.Orders.installmentPayment', $this, [
				'notifType' => $this->request->data('notify') ? 'InstallmentPaymentMail' : null,
			]);
			$this->getEventManager()->dispatch($event);
			if (!empty($event->result)) {
				$message = __('The payment has been saved and the email has been sent.');
			}
		}
		$options = [
			'conditions' => [
				"{$this->Order->alias}.{$this->Order->primaryKey}" => $id,
			],
			'contain' => [
				'Payment' => [
					'fields' => [
						'id', 'payment_method_id', 'amount', 'summary',
						'due_date', 'paid_date', 'paid_notified',
					],
					'order' => [
						'Payment.due_date' => 'asc',
						'Payment.paid_date' => 'asc',
					],
				],
			],
			'fields' => ['id', 'amount'],
		];
		$order = $this->Order->find('first', $options);
		// $this->log($this->Order->getDataSource()->getLog(), 'debug');
		$this->_setJsonResponse(compact('message', 'order'));
	}

/**
 * admin_cancel_booking method
 *
 * @return CakeResponse|null
 */
	public function admin_cancel_booking() {
		$this->request->allowMethod('post');

		App::uses('OrderShell', 'Console/Command');
		$shell = new OrderShell();
		$shell->initialize();
		$shell->startup(); // 必要？
		$task = $shell->Tasks->load('CancelBooking');
		if ($task->execute()) {
			$this->Flash->success(__('CancelBooking command has been executed.'));
		} else {
			$this->Flash->error(__('CancelBooking command could not be executed. Please, see the error log.'));
		}

		return $this->redirect($this->referer());
	}

/**
 * 管理者向け商品選択肢の取得。
 *
 * @return void
 */
	public function admin_list_products() {
		// NOTE: 全件取得後にフィルタリングする。
		// カート内商品のdiscontinuedはセットされておらず、conditionsで絞り込もうとしても、
		// find('threaded')の戻り値が期待するものにならないため。
		$query = [
			'contain' => false,
			'fields' => ['id', 'name', 'parent_id', 'discontinued'],
			'order' => ['created' => 'desc'],
		];
		$products = $this->Order->Product->find('threaded', $query); // 全件取得
		$discontinued = $this->request->query('discontinued');
		if (isset($discontinued)) {
			// フィルタリング
			$filtered = [];
			foreach ($products as $product) {
				if ($product[$this->Order->Product->alias]['discontinued'] == $discontinued) {
					$filtered[] = $product;
				}
			}
			$products = $filtered;
		}
		// $this->log($products, LOG_DEBUG);
		return $this->_setJsonResponse(compact('products'));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * PayPalSubscriptionPlans Controller
 */
class PayPalSubscriptionPlansController extends AppController {

/**
 * {@inheritdoc}
 */
	public $components = [
		'RequestHandler',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// ゲスト（未ログイン）ユーザーに公開するアクション
		$this->Auth->allow('view');
	}

/**
 * view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function view($id = null) {
		$plan = $this->PayPalSubscriptionPlan->read(null, $id);
		$this->set(compact('plan'));
	}

/**
 * admin_index method
 *
 * @return void
 * @throws ApiErrorException
 */
	public function admin_index() {
		$plans = $this->PayPalSubscriptionPlan->find('all', [
			'conditions' => [
				'product_id' => $this->request->query('product_id'),
			],
		]);
		$this->set(compact('plans'));
	}
}

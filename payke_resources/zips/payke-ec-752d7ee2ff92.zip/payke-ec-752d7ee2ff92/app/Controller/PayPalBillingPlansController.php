<?php
App::uses('AppController', 'Controller');
/**
 * PayPalBillingPlans Controller
 *
 * @property PayPalBillingPlan $PayPalBillingPlan
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class PayPalBillingPlansController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'Paginator' => array(
			'order' => array(
				'create_time' => 'desc',
			),
		),
		'Session',
		'Search.Prg' => array(
			'commonProcess' => array(
				'filterEmpty' => true,
			),
		),
	);

/**
 * admin_refresh method
 *
 * @return void
 */
	public function admin_refresh() {
		$this->request->allowMethod('post');

		if ($this->request->data('show_processing')) {
			$this->log(__METHOD__.': Show processing', 'debug');
			return;
		}

		App::uses('PayPalCacheShell', 'Console/Command');
		$shell = new PayPalCacheShell();
		$shell->initialize();
		$shell->startup(); // 必要？
		$task = $shell->Tasks->load('Refresh');
		if (!$task->execute()) {
			$this->Flash->error(__('The billing plans list could not be refreshed. Please, see the error log.'));
		}

		$this->redirect(array('action' => 'index'));
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->PayPalBillingPlan->recursive = 0;
		$this->Prg->commonProcess();
		$this->Paginator->settings['conditions'] = $this->PayPalBillingPlan->parseCriteria($this->Prg->parsedParams());
		$this->set('payPalBillingPlans', $this->Paginator->paginate());
		if (isset($this->PayPalBillingPlan->failureReason)) {
			$this->Flash->error($this->PayPalBillingPlan->failureReason);
		}
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_view($id = null) {
		if (!$this->PayPalBillingPlan->exists($id)) {
			throw new NotFoundException(__('Invalid paypal billing plan'));
		}
		$options = array('conditions' => array('PayPalBillingPlan.' . $this->PayPalBillingPlan->primaryKey => $id));
		$this->set('payPalBillingPlan', $this->PayPalBillingPlan->find('refresh', $options));
		if (isset($this->PayPalBillingPlan->failureReason)) {
			$this->Flash->error($this->PayPalBillingPlan->failureReason);
		}
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			if ($this->request->data('op_plan') === 'change_type') {
				$this->log('Changing BillingPlan.type', 'debug');
				return;
			}
			switch ($this->request->data('op_trial')) {
				case 'add':
					$this->request->data[$this->PayPalBillingPlan->PayPalPaymentDefinition->alias][] = array(
						'type' => 'TRIAL',
						'name' => __('Trial Payments'),
					);
					return;
				case 'remove':
					unset($this->request->data[$this->PayPalBillingPlan->PayPalPaymentDefinition->alias][1]);
					return;
			}
			if ($this->PayPalBillingPlan->savePlanAndAssociated($this->request->data)) {
				$this->Flash->success(__('The billing plan has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The billing plan could not be saved. Please, try again.'));
				if (isset($this->PayPalBillingPlan->failureReason)) {
					$this->Flash->error($this->PayPalBillingPlan->failureReason);
				}
			}
		} else {
			// フォームデータにデフォルト値をセット
			$this->request->data[$this->PayPalBillingPlan->alias]['type'] = 'FIXED';
			if (empty($this->request->data[$this->PayPalBillingPlan->PayPalPaymentDefinition->alias])) {
				$this->request->data[$this->PayPalBillingPlan->PayPalPaymentDefinition->alias][] = array(
					'type' => 'REGULAR',
					'name' => __('Regular Payments'),
				);
			}
		}
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		if (!$this->PayPalBillingPlan->exists($id)) {
			throw new NotFoundException(__('Invalid billing plan'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->request->data('op_plan') === 'change_type') {
				$this->log('Changing BillingPlan.type', 'debug');
				return;
			}
			if ($this->PayPalBillingPlan->savePlanAndAssociated($this->request->data)) {
				$this->Flash->success(__('The billing plan has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The billing plan could not be saved. Please, try again.'));
				if (isset($this->PayPalBillingPlan->failureReason)) {
					$this->Flash->error($this->PayPalBillingPlan->failureReason);
				}
			}
		} else {
			$options = array('conditions' => array('PayPalBillingPlan.' . $this->PayPalBillingPlan->primaryKey => $id));
			$this->request->data = $this->PayPalBillingPlan->find('refresh', $options);
			if (isset($this->PayPalBillingPlan->failureReason)) {
				$this->Flash->error($this->PayPalBillingPlan->failureReason);
			}
		}
	}

/**
 * admin_change_state method
 *
 * @throws NotFoundException
 * @param string $id
 * @param string $state
 * @return void
 */
	public function admin_change_state($id = null, $state = null) {
		$this->PayPalBillingPlan->id = $id;
		if (!$this->PayPalBillingPlan->exists()) {
			throw new NotFoundException(__('Invalid billing plan'));
		}
		$this->request->allowMethod('post', 'put');
		if ($this->PayPalBillingPlan->changeState($state)) {
			$this->Flash->success(__('The state has been changed.'));
		} else {
			$this->Flash->error(__('The state could not be changed. Please, try again.'));
			if (isset($this->PayPalBillingPlan->failureReason)) {
				$this->Flash->error($this->PayPalBillingPlan->failureReason);
			}
		}
		return $this->redirect(array('action' => 'index'));
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		$this->PayPalBillingPlan->id = $id;
		if (!$this->PayPalBillingPlan->exists()) {
			throw new NotFoundException(__('Invalid billing plan'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($count = $this->PayPalBillingPlan->countPaymentPlans()) {
			$this->Flash->error(__('The billing plan could not be deleted because it has some payment plans.'));
		} else if ($this->PayPalBillingPlan->delete()) {
			$this->Flash->success(__('The billing plan has been deleted.'));
		} else {
			$this->Flash->error(__('The billing plan could not be deleted. Please, try again.'));
			if (isset($this->PayPalBillingPlan->failureReason)) {
				$this->Flash->error($this->PayPalBillingPlan->failureReason);
			}
		}
		return $this->redirect(array('action' => 'index'));
	}
}

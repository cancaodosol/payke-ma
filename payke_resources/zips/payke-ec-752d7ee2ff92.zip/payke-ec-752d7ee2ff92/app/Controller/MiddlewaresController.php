<?php
App::uses('AppController', 'Controller');
App::uses('MiddlewareHelper', 'Lib');

/**
 * Middlewares Controller
 *
 * @property Middleware $Middleware
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class MiddlewaresController extends AppController {

	use MiddlewareHelper;

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session', 'Flash');

/**
 * admin_edit method
 *
 * @param string $id
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->Middleware->exists($id)) {
			throw new NotFoundException(__('Invalid middleware'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if (
				boolval($this->request->data('Middleware.enabled')) &&
				!$this->isWhitelisted()
			) { // ONにする前に「許可IPアドレス」に現在のIPアドレスを追加してください
				$this->Flash->error(__('Please add your current IP to the white list to enable the Whitelist middleware.'));
			} else if (!$this->Middleware->save($this->request->data)) { // 更新
				$this->Flash->error(__('The middleware could not be saved. Please, try again.'));
			} else {
				$this->Flash->success(__('The middleware has been saved.'));
			}
			return $this->redirect($this->referer());
		} else {
			$options = array('conditions' => array('Middleware.' . $this->Middleware->primaryKey => $id));
			$this->request->data = $this->Middleware->find('first', $options);
		}
	}
}

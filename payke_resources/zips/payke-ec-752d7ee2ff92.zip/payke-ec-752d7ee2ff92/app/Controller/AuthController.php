<?php
App::uses('AppController', 'Controller');
/**
 * Auth Controller
 *
 * @property AuthServerComponent $AuthServer
 */
class AuthController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'AuthServer',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// クライアントが未認証の POST リクエストを送信できるように、パブリックアクセス可能な状態にする
		$this->Auth->allow('token');

		// CSRF 保護から除外 https://stripe.com/docs/webhooks/best-practices#csrf-protection
		// [指定したアクションの CSRF とデータバリデーションの無効化](https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id12)
		$this->Security->unlockedActions = [
			'token',
		];
	}

/**
 * アクセストークンを発行する。
 *
 * @return CakeResponse
 * @throws MethodNotAllowedException
 * @link https://book.cakephp.org/2/ja/controllers.html#id3
 */
	public function token() {
		$this->request->allowMethod('post');

		return $this->AuthServer->issueToken();
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * Payments Controller
 *
 * @property Payment $Payment
 * @property PaginatorComponent $Paginator
 * @property RequestHandlerComponent $RequestHandler
 * @property Search.PrgComponent $Search.Prg
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class PaymentsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		'Paginator',
		'RequestHandler',
		'Search.Prg' => [
			'commonProcess' => [
				'filterEmpty' => true,
			],
		],
		'Session',
		'Flash',
	];

/**
 * ページ制御のデフォルトとして使われるクエリ条件。
 *
 * @var array
 * @link https://book.cakephp.org/2/ja/core-libraries/components/pagination.html
 */
	public $paginate = [
		'contain' => [
			'Order' => [
				'fields' => [
					'name', 'product_id', 'customer_name', 'payment_method_id', 'payment_cycles',
				],
			],
			'PaymentMethod' => ['fields' => ['name']],
		],
		// 'fields' => [],
		'order' => [
			'Payment.paid_date' => 'desc',
			'Payment.amount' => 'desc',
			'Payment.paid_notified' => 'desc',
		],
		'paramType' => 'querystring',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'update' => [
				'admin_demand',
				'admin_fresh',
			],
		]);
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings = $this->paginate;
		$this->Paginator->settings['conditions'] = $this->Payment->parseCriteria($this->Prg->parsedParams());
		$productQuery = [];
		if ('0' === $this->request->query('paid')) { // 未入金一覧の場合
			$order = [
				// 'is_null_due_date' => 'desc', // due_date が NULL の行を最初にする
				'Payment.due_date' => 'desc',
				'Order.id' => 'desc',
			];
			$this->Paginator->settings['order'] = $order;
			$productQuery = [
				'conditions' => [
					'Product.purchase_type' => [
						PE_PURCHASE_TYPE_PAYMENT, // 一括/分割
						PE_PURCHASE_TYPE_BUNDLE, // 一括（カート商品）
						PE_PURCHASE_TYPE_SUBSCRIPTION, // 継続
					],
				],
			];
		} else {
			$purchaseType = $this->request->query('purchase_type');
			if ($purchaseType) {
				$productQuery = [
					'conditions' => [
						'Product.purchase_type' => $purchaseType,
					],
				];
			}
		}
		$this->set('payments', $this->Paginator->paginate());
		$this->set('products', $this->Payment->Order->Product->find('list', $productQuery));
		$this->set('paymentMethods', $this->Payment->PaymentMethod->find('list', [
			'conditions' => ['PaymentMethod.id <>' => PE_PAYMENT_METHOD_FAST_PAY], // FastPay以外
		]));
	}

/**
 * _view method
 *
 * @throws NotFoundException
 * @param string $id
 * @param string $message
 * @return void
 */
	protected function _view($id = null, $message = null) {
		$payment = $this->Payment->find('first', [
			'conditions' => ["{$this->Payment->alias}.{$this->Payment->primaryKey}" => $id],
			'contain' => false,
		]);
		$links = [
			'edit' => Router::url([
				'prefix' => 'admin',
				'controller' => 'payments',
				'action' => 'edit',
				$id,
			]),
		];
		$this->_setJsonResponse(compact('message', 'payment', 'links'));
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->Payment->create();
			if (!$this->Payment->save($this->request->data)) {
				$message = __('The payment could not be saved. Please, try again.');
				$errors = $this->Payment->validationErrors;
				return $this->_setJsonResponse(compact('message', 'errors'), 400);
			}
			$message = __('The payment has been saved.');
			$event = new CakeEvent('Controller.Payment.save', $this, [
				'notifType' => $this->request->data('notify') ? 'RecurringPaymentMail' : null,
			]);
			$this->getEventManager()->dispatch($event);
			if (!empty($event->result)) {
				$message = __('The payment has been saved and the email has been sent.');
			}
			$this->_view($this->Payment->getInsertID(), $message);
		}
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		if (!$this->Payment->exists($id)) {
			throw new NotFoundException(__('Invalid payment'));
		}
		$message = null;
		if ($this->request->is(['post', 'put'])) {
			if (!$this->Payment->save($this->request->data)) {
				$message = __('The payment could not be saved. Please, try again.');
				$errors = $this->Payment->validationErrors;
				return $this->_setJsonResponse(compact('message', 'errors'), 400);
			}
			$message = __('The payment has been saved.');
			$event = new CakeEvent('Controller.Payment.save', $this, [
				'notifType' => $this->request->data('notify') ? 'RecurringPaymentMail' : null,
			]);
			$this->getEventManager()->dispatch($event);
			if (!empty($event->result)) {
				$message = __('The payment has been saved and the email has been sent.');
			}
		}
		$this->_view($id, $message);
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		if (!$this->Payment->exists($id)) {
			throw new NotFoundException(__('Invalid payment'));
		}
		$this->request->allowMethod('post', 'delete');
		$this->Payment->softDelete(false); // ソフトデリートを無効にする
		if ($this->Payment->delete($id)) {
			$this->Flash->success(__('The payment has been deleted.'));
		} else {
			$this->Flash->error(__('The payment could not be deleted. Please, try again.'));
		}
		$this->Payment->softDelete(true); // ソフトデリートを有効にする

		return $this->redirect($this->referer());
	}

/**
 * admin_demand method
 *
 * @throws NotFoundException
 * @param  string  $id
 * @return void
 */
	public function admin_demand($id = null) {
		$this->Payment->id = $id;
		$event = new CakeEvent('Controller.Payment.demand', $this, [
			'notifType' => 'DemandPaymentMail',
		]);
		$this->getEventManager()->dispatch($event);
		if (empty($event->result)) {
			$this->Flash->error(__('The demand payment email clould not be sent.'));
		} else {
			$this->Flash->success(__('The demand payment email has been sent.'));
		}
		return $this->redirect($this->referer());
	}

/**
 * admin_fresh method
 *
 * @return void
 */
	public function admin_fresh() {
		$this->request->allowMethod('post');

		App::uses('PaymentShell', 'Console/Command');
		$shell = new PaymentShell();
		$shell->initialize();
		$shell->startup(); // 必要？
		$task = $shell->Tasks->load('DueDate');
		if ($task->execute()) {
			$this->Flash->success(__('The unpaid list has been freshed.'));
		} else {
			$this->Flash->error(__('The unpaid list could not be freshed. Please, see the error log.'));
		}

		return $this->redirect($this->referer());
	}
}

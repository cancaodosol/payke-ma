<?php
App::uses('AppController', 'Controller');

/**
 * UnivapaySubscriptions Controller
 *
 * @property UnivapaySubscription $UnivapaySubscription
 * @property FlashComponent $Flash
 * @property RequestHandler $RequestHandler
 * @property SessionComponent $Session
 */
class UnivapaySubscriptionsController extends AppController {

/**
 * コントローラで使うコンポーネントをセットする。
 *
 * @var array
 */
	public $components = [
		'RequestHandler',
	];

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id) {
		$subscription = $this->UnivapaySubscription->read(null, $id);
		$this->set(compact('subscription'));
	}

/**
 * admin_delete method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_delete($id = null) {
		$this->request->allowMethod('post', 'delete');

		// 定期課金の削除は物理削除ではなくcanceled状態（永久停止）への移行
		$deleted = $this->UnivapaySubscription->delete($id, false);
		if ($deleted) {
			$this->Flash->success(__('The UnivaPay Subscription has been canceled.'));
		} else {
			$this->Flash->error(__('The UnivaPay Subscription could not be canceled. Please, try again.'));
		}

		$subscription = $this->UnivapaySubscription->read(null, $id); // 最新状況を取得

		$this->set(compact('deleted', 'subscription'));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * StripeSubscriptions Controller
 */
class StripeSubscriptionsController extends AppController {

/**
 * {@inheritdoc}
 */
	public $components = [
		'RequestHandler',
	];

/**
 * {@inheritdoc}
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'update' => [
				'admin_cancel',
			],
		]);
	}

/**
 * admin_view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 * @throws ApiErrorException
 * @link https://stripe.com/docs/api/subscriptions/retrieve
 */
	public function admin_view($id = null) {
		$subscription = $this->StripeSubscription->read(null, $id);
		$this->set(compact('subscription'));
	}

/**
 * キャンセルする。
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 * @link https://stripe.com/docs/api/subscriptions/cancel
 */
	public function admin_cancel($id = null) {
		$this->request->allowMethod('post');
		$this->StripeSubscription->id = $id;
		$this->StripeSubscription->cancel();
		$message = __('The subscription canceled');
		$subscription = $this->StripeSubscription->data[$this->StripeSubscription->alias];
		$this->set(compact('message', 'subscription'));
	}
}

<?php
App::uses('AppController', 'Controller');

/**
 * PayPalSubscriptions Controller
 */
class PayPalSubscriptionsController extends AppController {

/**
 * {@inheritdoc}
 */
	public $components = [
		'RequestHandler',
	];

/**
 * {@inheritdoc}
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'update' => [
				'admin_cancel',
			],
		]);
	}

/**
 * admin_view method
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_view($id = null) {
		$subscription = $this->PayPalSubscription->read(null, $id);
		$this->set(compact('subscription'));
	}

/**
 * キャンセルする。
 *
 * @param string $id
 * @return void
 * @throws ApiErrorException
 */
	public function admin_cancel($id = null) {
		$this->request->allowMethod('post');
		$this->PayPalSubscription->id = $id;
		$this->PayPalSubscription->set($this->request->data);
		if (!$this->PayPalSubscription->validates()) {
			$message = __('Validation error');
			$errors = $this->PayPalSubscription->validationErrors;
			$this->response->statusCode(400);
			return $this->set(compact('errors', 'message'));
		}
		$this->PayPalSubscription->cancel($this->request->data);
		$message = __('PayPal subscription canceled');
		$subscription = $this->PayPalSubscription->read();
		$this->set(compact('message', 'subscription'));
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * ChangeLogs Controller
 *
 * @property ChangeLog $ChangeLog
 * @property PaginatorComponent $Paginator
 */
class ChangeLogsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		// https://book.cakephp.org/2/ja/controllers.html#Controller::$paginate
		'Paginator' => [
			'contain' => [
				'User' => [
					'fields' => ['id', 'username'],
				],
				'Order' => [
					'fields' => ['id'],
				],
				'Product' => [
					'fields' => ['id'],
				],
				'Questionnaire' => [
					'fields' => ['id'],
				],
			],
			'order' => ['ChangeLog.created' => 'DESC'],
			'paramType' => 'querystring',
		],
		'Search.Prg' => [
			'commonProcess' => [
				'filterEmpty' => true,
			],
		],
	];

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings['conditions'] = $this->ChangeLog->parseCriteria($this->Prg->parsedParams());
		$this->set('changeLogs', $this->Paginator->paginate());
	}
}

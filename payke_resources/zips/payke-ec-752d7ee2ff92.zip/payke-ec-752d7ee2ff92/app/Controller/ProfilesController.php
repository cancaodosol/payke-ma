<?php
App::uses('AppController', 'Controller');
/**
 * Profiles Controller
 *
 * @property Profile $Profile
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class ProfilesController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session', 'Flash');

/**
 * アフィリエイトを停止/停止解除する。
 *
 * @param string $id プロフィールのID
 * @return void
 * @throws NotFoundException
 */
	public function admin_disable_affiliate($id = null) {
		if (!$this->Profile->exists($id)) {
			throw new NotFoundException(__('Invalid profile'));
		}
		$this->request->allowMethod('post');
		$this->Profile->id = $id;
		$name = $this->Profile->field('full_name');
		$disabled = $this->request->data('Profile.affiliate_disabled');
		if ($this->Profile->save($this->request->data)) {
			$message = $disabled
				? __("%s's affiliate has been disabled.", $name)
				: __("%s's affiliate has been enabled.", $name);
			$this->Flash->success($message);
		} else {
			$message = $disabled
				? __("%s's affiliate could not be disabled.", $name)
				: __("%s's affiliate could not be enabled.", $name);
			$this->Flash->error($message);
		}
		return $this->redirect($this->referer());
	}
}

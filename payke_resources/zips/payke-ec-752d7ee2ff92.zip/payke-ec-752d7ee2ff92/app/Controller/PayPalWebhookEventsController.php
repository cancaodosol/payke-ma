<?php
App::uses('AppController', 'Controller');
App::uses('PayPalWebhookEvent', 'Model');

/**
 * PayPalWebhookEvents Controller
 *
 * @property PayPalWebhookEvent $PayPalWebhookEvent
 */
class PayPalWebhookEventsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array(
		'RequestHandler',
		'PayPalSignatureVerifier', // RequestHandlerより後に処理させる
	);

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		$this->Auth->allow('process');

		// [指定したアクションの CSRF とデータバリデーションの無効化](https://book.cakephp.org/2/ja/core-libraries/components/security-component.html#id12)
		$this->Security->unlockedActions = array(
			'process'
		);
	}

/**
 * PayPal からのリクエストを処理する。
 *
 * @return void
 * @throws MethodNotAllowedException
 */
	public function process() {
		$message = null;

		if ($this->request->is('post')) {
			// 処理対象か否かを確認
			$type = $this->request->data('event_type');
			if (empty(PayPalWebhookEvent::handler($type))) {
				$message = "Unsupported event type: {$type}";
				$this->log($message, 'warning');
				return $this->_setJsonResponse(compact('message'));
			}

			// 既存を確認
			$exists = (bool)$this->PayPalWebhookEvent->find('count', [
				'conditions' => ['event_id' => $this->request->data('id')],
				'recursive' => -1,
				'callbacks' => false,
			]);
			if (!$exists) {
				// 保存
				$this->PayPalWebhookEvent->create();
				if ($this->PayPalWebhookEvent->save($this->request->data)) {
					$message = 'The webhook event has been saved.';
					return $this->_setJsonResponse(compact('message'));
				} else {
					$this->log($this->PayPalWebhookEvent->validationErrors);
					throw new InternalErrorException('The webhook event could not be saved.');
				}
			} else {
				// 過去に受信して保存済の場合は無視
				$message = 'The webhook event is redundant.';
				$this->log($message, 'info');
				return $this->_setJsonResponse(compact('message'));
			}
		}

		throw new MethodNotAllowedException();
	}
}

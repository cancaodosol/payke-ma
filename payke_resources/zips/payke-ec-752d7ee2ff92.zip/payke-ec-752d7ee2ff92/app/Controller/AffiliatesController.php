<?php
App::uses('UsersUsersController', 'Users.Controller');
/**
 * アフィリエイト会員に対する認証やCRUDなど。
 */
class AffiliatesController extends UsersUsersController {

/**
 * Controller name
 *
 * @var string
 */
	public $name = 'Affiliates';

/**
 * Setup components based on plugin availability
 *
 * @return void
 */
	protected function _setupComponents() {
		$this->components['Search.Prg'] = [
			'commonProcess' => [
				'filterEmpty' => true,
			],
		];
	}

/**
 * Sets the default from email config
 *
 * @return void
 */
	protected function _setDefaultEmail() {
	}

/**
 * Sets the default pagination settings up
 *
 * Override this method or the index action directly if you want to change
 * pagination settings.
 *
 * @return void
 */
	protected function _setupPagination() {
	}

/**
 * Sets the default pagination settings up
 *
 * Override this method or the index() action directly if you want to change
 * pagination settings. admin_index()
 *
 * @return void
 */
	protected function _setupAdminPagination() {
		$this->Paginator->settings = [
			'conditions' => [
				'role' => 'affiliate',
			],
			'contain' => [
				'Profile' => [
					'fields' => [
						'id',
						'aid',
						'full_name',
						'registration_date',
						'affiliate_disabled',
					],
				],
			],
			'fields' => [
				'id',
				'email',
				'affiliate_result_count',
				'locked',
			],
			'order' => [
				'Profile.registration_date' => 'desc',
			],
			'paramType' => 'querystring',
		];
		$this->Prg->commonProcess();
		$this->Paginator->settings = $this->paginate;
		$conditions = $this->User->parseCriteria($this->Prg->parsedParams());
		$this->Paginator->settings['conditions'] += $conditions;
	}

/**
 * Setup Authentication Component
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#authcomponent-api
 */
	protected function _setupAuth() {
		$this->Auth->allow([
			'affiliate_add',
			'affiliate_confirm',
			'affiliate_login',
			'affiliate_logout',
			'guest',
		]);

		// https://slywalker.github.io/cakephp-plugin-boost_cake/
		$this->Auth->flash = [
			'element' => 'alert',
			'key' => 'auth',
			'params' => [
				'plugin' => 'BoostCake',
				'class' => 'alert-error'
			],
		];

		$this->Auth->authenticate = [
			'PaykeForm' => [
				'passwordHasher' => 'Blowfish',
				'fields' => ['username' => 'email'],
			],
		];
		$this->Auth->loginAction = PE_AFFILIATE_LOGIN_URL;
		$this->Auth->loginRedirect = PE_URL_AFFILIATE_PRODUCTS;
	}

/**
 * 該当ユーザーがリクエスト内でリソースにアクセスすることが許可されるかを boolean で返す。
 *
 * @param array $user アクティブなユーザー
 * @return bool 許可されるか
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#controllerauthorize
 * @link https://book.cakephp.org/2/ja/tutorials-and-examples/blog-auth-example/auth.html#id4
 */
	public function isAuthorized($user = null) {
		// ユーザは自身の情報を編集できる
		if (in_array($this->action, ['admin_edit', 'affiliate_edit'])) {
			if ($user['role'] === 'admin') {
				$this->log(__METHOD__ . ': role=admin', 'debug');
				return true;
			}
			$id = $this->request->params['pass'][0]; // https://book.cakephp.org/2/ja/development/routing.html#passed-arguments
			$this->log(__METHOD__ . ': checking... (target id=' . $id . ', current id=' . $user['id'] . ')', 'debug');
			return $id === $user['id'];
		}

		return parent::isAuthorized($user);
	}

/**
 * クエリ文字列に商品グループ指定があれば認証済みユーザーと紐づける。
 *
 * @return mixed
 * @throws NotFoundException
 * @link https://book.cakephp.org/2/ja/models/saving-your-data.html#habtm
 */
	protected function _saveProductGroupsUserIfNeeded() {
		if (!$this->request->query('pgs')) {
			return;
		}

		// 商品グループの指定があれば商品グループを特定
		$this->ProductGroupsDetector = $this->Components->load('ProductGroupsDetector');
		$this->ProductGroupsDetector->initialize($this);
		$groups = $this->ProductGroupsDetector->detect();
		$groupIds = Hash::extract($groups, '{n}.id');

		// 既に紐づけられた商品グループを取得
		$results = $this->User->ProductGroup->ProductGroupsUser->find('list', [
			'conditions' => ['ProductGroupsUser.user_id' => $this->Auth->user('id')],
			'fields' => ['ProductGroupsUser.product_group_id'],
		]);
		$oldGroupIds = array_values($results);

		// 商品グループと認証済みユーザーを紐づける
		$newGroupIds = array_values(array_unique(array_merge($oldGroupIds, $groupIds)));
		$data = [
			$this->User->alias => [
				'id' => $this->Auth->user('id'),
			],
			$this->User->ProductGroup->alias => [
				$this->User->ProductGroup->alias => $newGroupIds,
			],
		];
		$saved = $this->User->save($data, [
			'validate' => false,
		]);

		return $saved;
	}

/**
 * affiliate_login action
 *
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function affiliate_login() {
		// 既に認証済みの場合はリダイレクトさせる
		if ($response = $this->authenticated()) {
			$this->_saveProductGroupsUserIfNeeded();
			return $response;
		}
		if ($this->request->is('post')) {
			if ($this->Auth->login()) {
				// 認証成功
				$this->_saveProductGroupsUserIfNeeded();
				return $this->redirect($this->Auth->redirectUrl());
			}
			$this->Flash->error(__('You could not log in.'));
		} else {
			$this->Session->delete('Auth.redirect');
		}
	}

/**
 * affiliate_logout action
 *
 * @return CakeResponse|null
 * @link https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id18
 */
	public function affiliate_logout() {
		return $this->redirect($this->Auth->logout());
	}

/**
 * Guest action
 *
 * @return CakeResponse|null
 */
	public function guest() {
		if ($this->request->is('post')) {
			$this->loadModel('Config');
			$signupViewPassword = $this->Config->get('signup_view_password');
			if ($signupViewPassword === $this->request->data('password')) {
				$this->log('guest authenticated', 'debug');
				$this->Session->write('Affiliate.signup.allowed', true);
				return $this->redirect(array(
					'action' => 'add',
					'prefix' => 'affiliate',
					'affiliate' => true,
					'?' => $this->request->query,
				));
			}
			$this->Flash->error('正しいパスワードを入力してください。');
		}
	}

/**
 * アフィリエイト会員向け登録アクション。
 *
 * @return CakeResponse|null
 * @throws BadRequestException
 * @throws NotFoundException
 */
	public function affiliate_add() {
		// 登録画面へのアクセスが制限されている場合はパスワード入力へリダイレクト
		$this->loadModel('Config');
		if ($this->Config->get('signup_view_restricted')) {
			$this->log('Affiliate.signup.allowed=' . $this->Session->read('Affiliate.signup.allowed'), 'debug');
			if (!$this->Session->read('Affiliate.signup.allowed')) {
				return $this->redirect(array(
					'action' => 'guest',
					'prefix' => null,
					'affiliate' => null,
					'?' => $this->request->query,
				));
			}
		}

		if ($this->request->is('post')) {
			// 複数のモデルのバリデーション
			// https://book.cakephp.org/2/ja/models/data-validation/validating-data-from-the-controller.html
			if ($this->User->saveAll($this->request->data, array('validate' => 'only'))) {
				// フォームデータをセッションに保存
				$this->log('Storing SignUp data to Session', 'debug');
				$this->Session->write('SignUp', $this->request->data);
				// 確認画面へリダイレクト
				return $this->redirect([
					'action' => 'confirm',
					'?' => $this->request->query,
				]);
			} else {
				$this->Flash->error('入力内容をご確認ください。');
			}
		} else {
			if ($this->Session->check('SignUp')) {
				// フォームデータをセッションから復元
				$this->log('Restoring SignUp data from Session', 'debug');
				$this->request->data = $this->Session->read('SignUp');
			} elseif ($this->request->query('pgs')) {
				// 商品グループの指定があれば商品グループを特定
				$this->ProductGroupsDetector = $this->Components->load('ProductGroupsDetector');
				$this->ProductGroupsDetector->initialize($this);
				$groups = $this->ProductGroupsDetector->detect();
				$this->request->data($this->User->ProductGroup->alias, $groups);
			} else {
				// 上記以外はリクエストエラーとする
				throw new BadRequestException();
			}
		}

		$this->set('productGroups', $this->User->ProductGroup->listSelectable());
	}

/**
 * affiliate_confirm method
 *
 * @return CakeResponse|null
 * @throws BadRequestException
 */
	public function affiliate_confirm() {
		if (!$this->Session->check('SignUp')) {
			throw new BadRequestException();
		}
		// フォームデータをセッションから復元
		$this->log('Restoring SignUp data from Session', 'debug');
		$this->request->data = $this->Session->read('SignUp');

		if ($this->request->is('post')) {
			if ($this->User->registerAffiliate($this->request->data)) {
				$this->Flash->success('登録有難う御座いました。メールを送信しておりますのでご確認ください。');
				// フォームデータをセッションに保存
				$this->log('Storing SignUp data to Session', 'debug');
				$this->request->data('registered', true);
				$this->Session->write('SignUp', $this->request->data);
				// 自身にリダイレクト
				return $this->redirect($this->referer());
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			if ($this->request->data('registered')) {
				// フォームデータをセッションから削除
				$this->Session->delete('SignUp');
				$this->Session->delete('Affiliate.signup.allowed');
				$this->log('Deleted SignUp data from Session', 'debug');
			}
		}
	}

/**
 * affiliate_edit method
 *
 * @param string $id ユーザーのID
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function affiliate_edit($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->User->saveAssociated($this->request->data)) {
				if ($this->Auth->login()) {
					$this->Flash->success(__('The user has been saved.'));
					return $this->redirect($this->referer());
				}
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$options = array(
				'conditions' => array('User.' . $this->User->primaryKey => $id),
				'contain' => array(
					'Profile',
				),
			);
			$this->request->data = $this->User->find('first', $options);
			unset($this->request->data[$this->User->alias]['password']); // パスワードを除外
		}
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->_setupAdminPagination();
		$this->set('affiliates', $this->Paginator->paginate());
	}

/**
 * Admin add
 *
 * @return void
 * @throws NotFoundException
 */
	public function admin_add() {
		throw new NotFoundException();
	}

/**
 * admin_edit method
 *
 * @param string $id ユーザーのID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		$affiliate = $this->User->find('first', [
			'conditions' => [
				"{$this->User->alias}.{$this->User->primaryKey}" => $id,
			],
			'contain' => [
				'Profile',
				'ProductGroup' => [
					'fields' => ['id', 'name'],
				],
			],
		]);
		unset($affiliate[$this->User->alias]['password']); // パスワードを除外

		if ($this->request->is(['post', 'put'])) {
			// FIXME: `Couldn't find Aro node ...`エラーへの回避策としてモデルからACLビヘイビアを外している。
			$this->User->Behaviors->unload('Acl');
			if ($this->User->saveAssociated($this->request->data)) {
				$this->Flash->success(__('The user has been saved.'));
				return $this->redirect(['action' => 'admin_index']);
			} else {
				$this->Flash->error(__('The user could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $affiliate;
		}

		// 商品グループの選択肢
		$this->set('productGroups', $this->User->ProductGroup->listSelectable());
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * ProductGroups Controller
 *
 * @property ProductGroup $ProductGroup
 * @property PaginatorComponent $Paginator
 * @property FlashComponent $Flash
 * @property SessionComponent $Session
 */
class ProductGroupsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator', 'Session');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->ProductGroup->recursive = 0;
		$this->set('productGroups', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->ProductGroup->exists($id)) {
			throw new NotFoundException(__('Invalid product group'));
		}
		$options = array('conditions' => array('ProductGroup.' . $this->ProductGroup->primaryKey => $id));
		$this->set('productGroup', $this->ProductGroup->find('first', $options));
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->ProductGroup->recursive = 0;
		$this->set('productGroups', $this->Paginator->paginate());
	}

/**
 * admin_add method
 *
 * @return void
 */
	public function admin_add() {
		if ($this->request->is('post')) {
			$this->ProductGroup->create();
			if ($this->ProductGroup->save($this->request->data)) {
				$this->Flash->success(__('The product group has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The product group could not be saved. Please, try again.'));
			}
		}
	}

/**
 * admin_edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_edit($id = null) {
		if (!$this->ProductGroup->exists($id)) {
			throw new NotFoundException(__('Invalid product group'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->ProductGroup->save($this->request->data)) {
				$this->Flash->success(__('The product group has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The product group could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('ProductGroup.' . $this->ProductGroup->primaryKey => $id));
			$this->request->data = $this->ProductGroup->find('first', $options);
		}
	}

/**
 * admin_delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function admin_delete($id = null) {
		$this->ProductGroup->id = $id;
		if (!$this->ProductGroup->exists()) {
			throw new NotFoundException(__('Invalid product group'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($count = $this->ProductGroup->countProducts()) {
			$this->Flash->error(__('The product group could not be deleted because it has some products.'));
		} else if ($this->ProductGroup->delete()) {
			$this->Flash->success(__('The product group has been deleted.'));
		} else {
			$this->Flash->error(__('The product group could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
}

<?php
App::uses('AppController', 'Controller');
/**
 * QuestionnaireAnswers Controller
 *
 * @property QuestionnaireAnswer $QuestionnaireAnswer
 * @property PaginatorComponent $Paginator
 * @property SessionComponent $Session
 * @property FlashComponent $Flash
 */
class QuestionnaireAnswersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = [
		// https://book.cakephp.org/2/ja/controllers.html#Controller::$paginate
		'Paginator' => [
			'contain' => [
				'Order' => [
					'fields' => [
						'id', 'name', 'customer_name', 'payment_cycles',
						'payment_method_id', 'status', 'deleted'
					],
				],
				'Questionnaire' => [
					'fields' => ['name'],
				],
			],
			'order' => [
				'QuestionnaireAnswer.created' => 'desc',
			],
			'paramType' => 'querystring',
		],
		'Search.Prg' => [
			'commonProcess' => [
				'filterEmpty' => true,
			],
		],
		'Session',
		'Flash',
	];

/**
 * 各アクションの前に実行される。
 *
 * @return void
 * @link https://book.cakephp.org/2/ja/controllers.html#Controller::beforeFilter
 */
	public function beforeFilter() {
		parent::beforeFilter();

		// 未ログインユーザーに許可するアクション
		$this->Auth->allow('edit', 'complete');

		// CrudAuthorize を使う場合のアクションのマッピング
		// https://book.cakephp.org/2/ja/core-libraries/components/authentication.html#id26
		$this->Auth->mapActions([
			'read' => [
				'admin_add', // 表示確認用アクションのためread扱いにする
				'admin_csv',
			],
		]);
	}

/**
 * edit method
 *
 * @param string $uuid 回答のUUID
 * @return void
 * @throws NotFoundException
 */
	public function edit($uuid) {
		if (!$this->QuestionnaireAnswer->existsUuid($uuid)) {
			throw new NotFoundException(__('Invalid questionnaire answer'));
		}
		$this->_checkPeriods($uuid);
		if ($this->request->is(array('post', 'put'))) {
			if ($this->request->data('disabled')) { // 期限切れ
				;
			} elseif ($this->request->data('save')) { // 保存リクエストの場合
				if ($this->QuestionnaireAnswer->saveByCustomer($this->request->data)) { // 保存
					$this->Flash->success(__('The questionnaire answer has been saved.'));
					return $this->redirect($this->QuestionnaireAnswer->redirectUrl);
				} else {
					$this->Flash->error(__('The questionnaire answer could not be saved. Please, try again.'));
				}
			} elseif ($this->request->data('confirm')) { // 確認リクエストの場合
				$this->RequestModifier = $this->Components->load('RequestModifier');
				$this->RequestModifier->initialize($this);
				$this->RequestModifier->modify([
					'Order.customer_first_name_kana' => 'convert_kana',
					'Order.customer_last_name_kana' => 'convert_kana',
				]);
				$this->QuestionnaireAnswer->Order->modifyValidatorForCustomField([
					'fieldable_id' => $this->request->data('QuestionnaireAnswer.questionnaire_id'),
					'fieldable_type' => 'Questionnaire',
				]);
				// 複数のモデルのバリデーション https://book.cakephp.org/2/ja/models/data-validation/validating-data-from-the-controller.html
				if ($this->QuestionnaireAnswer->saveAll(
					$this->request->data, ['validate' => 'only']
				)) {
					$this->Flash->info(__('Submit a form if good.'));
					$this->request->data('confirmed', true); // 確認済み
				} else {
					$this->Flash->error('入力内容をご確認ください。');
				}
			}
		} else {
			$data = $this->QuestionnaireAnswer->find('forEdit', [
				'conditions' => ['QuestionnaireAnswer.uuid' => $uuid],
			]);
			$this->request->data = Hash::merge($data, $this->request->data);
		}
		$questionnaireId = $this->request->data('QuestionnaireAnswer.questionnaire_id');
		$questionnaire = $this->QuestionnaireAnswer->Questionnaire->find('forAnswer', [
			'conditions' => ['Questionnaire.id' => $questionnaireId],
		]);
		$this->set(compact('questionnaire'));
	}

/**
 * 回答期間や編集期限をチェックする。
 *
 * @param string $uuid UUID
 * @return void
 */
	protected function _checkPeriods($uuid) {
		$data = $this->QuestionnaireAnswer->find('first', [
			'conditions' => ['QuestionnaireAnswer.uuid' => $uuid],
			'contain' => [
				'Questionnaire' => [
					'fields' => ['start_date', 'end_date', 'edit_deadline'],
				],
			],
			'fields' => ['answered'],
		]);

		$start = $data['Questionnaire']['start_date'];
		$end = $data['Questionnaire']['end_date'];
		$deadline = $data['Questionnaire']['edit_deadline'];
		$answered = $data['QuestionnaireAnswer']['answered'];

		if ($start && \Cake\Chronos\Chronos::parse($start)->isFuture()) {
			$this->Flash->warning('現在は受け付けておりません。');
			$this->request->data('disabled', true);
		} elseif ($end && \Cake\Chronos\Chronos::parse($end)->isPast()) {
			$this->Flash->warning('現在は受け付けておりません。');
			$this->request->data('disabled', true);
		} elseif (boolval($answered)
			&& $deadline && \Cake\Chronos\Chronos::parse($deadline)->isPast()) {
			$this->Flash->warning('内容を修正できる期限が過ぎました。');
			$this->request->data('disabled', true);
		}
	}

/**
 * complete method
 *
 * @return void
 */
	public function complete() {
	}

/**
 * admin_index method
 *
 * @return void
 */
	public function admin_index() {
		$this->Prg->commonProcess();
		$this->Paginator->settings['conditions'] = $this->QuestionnaireAnswer->parseCriteria($this->Prg->parsedParams());
		$this->set('questionnaireAnswers', $this->Paginator->paginate());
		$this->set('questionnaires', $this->QuestionnaireAnswer->Questionnaire->find('list'));
		$this->set('paymentMethods', $this->QuestionnaireAnswer->Order->PaymentMethod->find('list'));
	}

/**
 * CSVファイルにエクスポートする。
 *
 * @return void
 */
	public function admin_csv() {
		$this->Prg->commonProcess();
		$params = [
			'conditions' => $this->QuestionnaireAnswer->parseCriteria($this->Prg->parsedParams()),
			'contain' => [
				'Order' => [
					'PaymentMethod' => [
						'fields' => ['name'],
					],
					'Product' => ['Item' => ['fields' => ['id']]],
					'OrderItem' => [
						'fields' => [
							'product_id', 'name', 'price', 'quantity', 'amount',
							'is_tax_reduced',
						],
					],
					'fields' => [
						'id', 'name', 'customer_name', 'customer_name_kana',
						'customer_email', 'customer_zip_code', 'customer_prefecture',
						'customer_address', 'customer_phone', 'customer_gender',
						'customer_birth_date', 'payment_method_id',
						'payment_cycles', 'status',
					],
				],
				'CustomFieldValue' => [
					'fields' => ['custom_field_id', 'value'],
				],
			],
			'fields' => ['uuid', 'answered'],
			'order' => [
				'QuestionnaireAnswer.created' => 'desc',
			],
		];
		$results = $this->QuestionnaireAnswer->find('all', $params);
		reorder_order_items($results, 'Order.Product.Item', 'Order.OrderItem'); // 明細の再配置

		$questionnaireId = $this->request->query('questionnaire_id');
		$questionnaire = $this->QuestionnaireAnswer->Questionnaire->find('forAnswer', [
			'conditions' => ['Questionnaire.id' => $questionnaireId],
		]);

		$formUrlFormat = Router::url([
			'admin' => false,
			'controller' => 'questionnaire_answers',
			'action' => 'edit',
			'uuid' => '%s',
		], true);

		$_serialize = 'results';
		$_null = '';
		$columns = [
			__('Order ID') => 'Order.id',
			'商品' => 'Order.name',
		];
		$columns = array_merge($columns, make_items_columns( // 子商品
			$results, 'Order.Product.Item', 'Order.OrderItem'
		));
		$columns = array_merge($columns, [
			'フォームURL' => ['QuestionnaireAnswer.uuid', $formUrlFormat],
			__('Customer Name') => 'Order.customer_name',
			__('Customer Name Kana') => 'Order.customer_name_kana',
			__('Customer Email') => 'Order.customer_email',
			__('Customer Zip Code') => 'Order.customer_zip_code',
			__('Customer Prefecture') => 'Order.customer_prefecture',
			__('Customer Address') => 'Order.customer_address',
			__('Customer Phone') => 'Order.customer_phone',
			__('Customer Gender') => 'Order.customer_gender',
			__('Customer Birth Date') => 'Order.customer_birth_date',
			__('Payment Method') => 'Order.PaymentMethod.name',
			__('Cycles') => 'payment_cycles',
			__('Order Status') => 'status_name',
			'回答日時' => 'QuestionnaireAnswer.answered',
		]);

		// カスタムフィールド
		foreach ($questionnaire['CustomField'] as $field) {
			$header = $field['label'];
			$extract = "CustomFieldValue.{n}[custom_field_id={$field['id']}].value"; // Hashクラスのマッチャーを利用
			$columns[$header] = $extract;
		}

		$this->response->download('questionnaire_answers.csv');
		$this->viewClass = 'ExcelCsv';
		$this->_appendLabels($results); // 追加
		$this->_formatValues($results); // 整形
		$_header = array_keys($columns);
		$_extract = array_values($columns);
		$this->set(compact('results', '_serialize', '_null', '_header', '_extract'));
	}

/**
 * コード値に対応する表示名を追加する。
 *
 * @param array &$rows 行データ
 * @return void
 */
	protected function _appendLabels(array &$rows) {
		foreach ($rows as $index => &$row) {
			$row['payment_cycles'] = order_payment_cycles_desc($row);
			$row['status_name'] = order_status_desc($row);
			$rows[$index] = $row;
		}
	}

/**
 * 数値、日付、日時などを整形する。
 *
 * @param array &$rows 行データ
 * @return void
 */
	protected function _formatValues(array &$rows) {
		App::uses('CakeTime', 'Utility');

		$timeFormatter = function ($value) {
			return CakeTime::format($value, CAKETIME_FORMAT);
		};

		$formatters = [
			'QuestionnaireAnswer.answered' => $timeFormatter,
		];

		foreach ($rows as $index => $row) {
			foreach ($formatters as $path => $formatter) {
				$values = Hash::extract($row, $path);
				if (empty($values)) { // 値が NULL の場合
					$values = [null]; // Hash::extract の戻り値が [] になってしまう問題への回避策
				}
				foreach ($values as $n => $value) {
					if (is_callable($formatter)) {
						$value = $formatter($value);
					}
					$actualPath = str_replace('{n}', "$n", $path);
					$row = Hash::insert($row, $actualPath, $value);
				}
				$rows[$index] = $row;
			}
		}
	}

/**
 * admin_add method
 *
 * @return void
 * @throws BadRequestException
 */
	public function admin_add() {
		// NOTE: 回答フォームの表示のみとし、作成はさせない。
		$questionnaireId = $this->request->query('questionnaireId');
		if (empty($questionnaireId)) {
			throw new BadRequestException(__('Invalid questionnaireId'));
		}
		$questionnaire = $this->QuestionnaireAnswer->Questionnaire->find('forAnswer', [
			'conditions' => ['Questionnaire.id' => $questionnaireId],
		]);
		$this->set(compact('questionnaire'));
		$this->request->data('QuestionnaireAnswer', [
			'questionnaire_id' => $questionnaire['Questionnaire']['id'],
			'name' => $questionnaire['Questionnaire']['name'],
		]);
		$this->request->data('Order', [
			'customer_email' => 'user@example.com',
			'customer_name' => '姓 名',
		]);
		$this->request->data('CustomFieldValue', []);
	}

/**
 * admin_edit method
 *
 * @param string $id ID
 * @return void
 * @throws NotFoundException
 */
	public function admin_edit($id = null) {
		if (!$this->QuestionnaireAnswer->exists($id)) {
			throw new NotFoundException(__('Invalid questionnaire answer'));
		}
		if ($this->request->is(array('post', 'put'))) {
			$this->QuestionnaireAnswer->Order->modifyValidatorForCustomField([
				'fieldable_id' => $this->request->data('QuestionnaireAnswer.questionnaire_id'),
				'fieldable_type' => 'Questionnaire',
			]);
			if ($this->QuestionnaireAnswer->saveAssociated($this->request->data)) {
				$this->Flash->success(__('The questionnaire answer has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The questionnaire answer could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $this->QuestionnaireAnswer->find('forEdit', [
				'conditions' => ['QuestionnaireAnswer.id' => $id],
			]);
		}
		$questionnaireId = $this->request->data('QuestionnaireAnswer.questionnaire_id');
		$questionnaire = $this->QuestionnaireAnswer->Questionnaire->find('forAnswer', [
			'conditions' => ['Questionnaire.id' => $questionnaireId],
		]);
		$this->set(compact('questionnaire'));
	}

/**
 * admin_delete method
 *
 * @param string $id ID
 * @return CakeResponse|null
 * @throws NotFoundException
 */
	public function admin_delete($id = null) {
		if (!$this->QuestionnaireAnswer->exists($id)) {
			throw new NotFoundException(__('Invalid questionnaire answer'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->QuestionnaireAnswer->delete($id)) {
			$this->Flash->success(__('The questionnaire answer has been deleted.'));
		} else {
			$this->Flash->error(__('The questionnaire answer could not be deleted. Please, try again.'));
		}
		return $this->redirect($this->referer());
	}
}

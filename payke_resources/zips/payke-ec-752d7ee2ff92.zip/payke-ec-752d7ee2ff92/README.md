## Requirements

- PHP 7.1+
- MySQL

## Some Handy Links

- [CookBook](https://book.cakephp.org/2.0/ja/)
- [API](https://api.cakephp.org/2.10/)
- [PHP マニュアル](https://www.php.net/manual/ja/)
- [PHPUnit 5](https://phpunit.de/manual/5.7/ja/index.html)
- [CakePHP Chronos 2.x](https://book.cakephp.org/chronos/2/ja/index.html)
- [CakeDC Migrations Plugin](https://github.com/CakeDC/migrations/blob/master/Docs/Home.md)
- [CakeDC Search Plugin](https://github.com/CakeDC/search/blob/master/Docs/Home.md)
- [CakeDC Users Plugin 2.x](https://github.com/CakeDC/users/blob/2.x/Docs/Home.md)
- [CakeDC Utils Plugin](https://github.com/CakeDC/utils)
- [Friends of Cake CRUD Plugin](https://crud.readthedocs.io/en/cake3/contents.html)
- [Twig Documentation](https://twig.symfony.com/doc/2.x/)


## 開発

### セットアップ

```
$ git clone https://bitbucket.org/koryo/payke-ec.git
$ cd payke-ec/app/
```

### 開発環境（PHP、Composer、Nodeが使える場合）

NOTE: PHP 7の導入が難しくなってきたため、こちらよりも後述のDocker開発環境が推奨。

#### ビルド（パッケージのインストールやアセットのコンパイル）

```
$ composer install
$ npm install
$ npx mix (または npx mix watch)
```

#### CakePHP開発用ウェブサーバーの起動

```
$ ./Console/cake server --help	# ヘルプ
$ ./Console/cake server --host 127.0.0.1 --port 8765	# 起動例

Welcome to CakePHP v2.10.* Console
---------------------------------------------------------------
App : app
Path: ... /payke-ec/app/
DocumentRoot: ... /payke-ec/app/webroot
---------------------------------------------------------------
built-in server is running in http://127.0.0.1:8765/
```

### Docker開発環境

事前に、Host OS(Windows/Mac)でDockerとdocker-composeコマンドが使える状態にします。

#### OSイメージの作成
```
$ docker-compose build
```

#### 初回起動

初回起動は、DBサーバの初期設定が走るため、起動に時間がかります。
このため、[-d]オプションなしで起動して、DBサーバの初期設定が完了して、待機状態になるまで待ちます。

```
$ docker-compose up
```
待機状態になりましたら、以下のコマンドでvenderを構築します。

```
$ docker-compose exec web /bin/bash -c "cd payke/app/ && composer install"
$ docker-compose exec web /bin/bash -c "cd payke/app/ && npm install"
$ docker-compose exec web /bin/bash -c "cd payke/app/ && npx mix watch"
```

DBサーバが待機状態になったことを確認したら、次回からは、[-d]オプションを付けてバックグラウンドモードで起動します。

```
$ docker-compose up -d
```

#### 稼働サービス

* http://127.0.0.1/payke => webサーバ
* http://127.0.0.1:8033  => phpmyadmin(id: web / pw: web)
* http://127.0.0.1:8025  => mailhog(※メール受信チェック用サーバ id: payke_user / pw: payke_password)

#### Paykeの初期設定

http://127.0.0.1/payke/install にアクセスして指示に従う。

DBサーバは以下の設定を使用する
```
host: db
user: web
password: web
table: web
```

#### ssl化

https状態で開発・テストする場合に使用する

````
$ docker-compose  exec web /bin/bash
````
を実行して、webサーバ上のログインシェルに入る。

```
$ cd /var/www/html/payke
```
に移動して、
```
$ mkdir ssl
```
でSSLディレクトリを作成する。

以下のコマンドで証明書を作成する

```
$ cd ssl

$ openssl genrsa -aes128 2048 > server.key
$ openssl req -new -key server.key > server.csr
$ openssl x509 -days 3650 -req -extfile ../subjectnames.txt -signkey server.key < server.csr > server.crt
$ mv server.key server.key.org
$ openssl rsa -in server.key.org > server.key
```

作成したファイルをdocker/web配下にコピーする
Chromeには、以下を参考にしてserver.crtをインポートする
https://jp.globalsign.com/support/ssl/config/cert-import-chrome.html

### インストール画面

http://127.0.0.1:8765/install にアクセスして指示に従う。

MySQLにはデータベースを予め作成しておく必要がある。

インストールが完了すると *app/Config/install.php* ファイル内の `installed` の値が `true` にセットされ、インストール画面は見れなくなる。
この値を `false` に変更すればインストール画面を再表示することはできる。
`false` のままでは Payke EC は正常に動作しないので、インストールを完了する必要がある。

### ログイン画面

https://127.0.0.1:8765/payke/admin/users/login

### コンソールアプリケーション

app/Console/Command/ 配下にあるクラスは、通常は、シェルから実行させたり、 cron ジョブとして実行させる。

参考: [シェルとタスクとコンソール](https://book.cakephp.org/2/ja/console-and-shells.html)

#### シェルからの実行

例えば、 Amazon Pay の継続払いの2回目以降の課金を処理するコマンドは、RecurringPaymentShell クラスと ProcessNextChargeTask クラスで構成されていて、以下のようなコマンドで実行できる。

```
$ ./Console/cake recurring_payment process_next_charge

$ ./Console/cake recurring_payment process_next_charge --time=20230401090000    # 現在日時を2023/04/01 9:00とみなして実行させる場合（動作確認用）
```

#### cron ジョブとして実行

通常は、シェルスクリプト app/Console/cake 経由で実行させるが、 cron を実行するユーザの環境によって実行できない場合があるので注意。
例えば、エックスサーバーでは php コマンドのパスが異なり app/Console/cake だとエラーになるため、替わりに用意した app/Console/cake-for-Xserver を使う。

参考: https://www.xserver.ne.jp/manual/man_program_cron.php

### ユニットテスト

TODO: 余力があれば追加する

ユニットテスト用に空のデータベースを予め作成しておく必要がある。接続情報は *app/Config/.env.php* ファイルを直接編集して設定する。
マイグレーションは不要。フィクスチャを設定することで必要なテーブルがテスト開始時に作成され、テスト終了時に削除されるため。

参考: [テスト](https://book.cakephp.org/2/ja/development/testing.html)

#### ブラウザからの実行

http://127.0.0.1:8765/test.php にアクセスし、実行したいテストケースのリンクをクリックする。

#### コマンドラインからの実行（推奨）

こちらの方が、テストで例外が発生したときのエラー情報の表示がわかりやすい。

```
$ ./Console/cake test app Controller/Component/AccessLoggerComponent 2> /dev/null	# 実行例（標準エラー出力を捨てる場合）
```

- [コマンドラインからのテスト実行](https://book.cakephp.org/2/ja/development/testing.html#run-tests-from-command-line)

### データベース マイグレーション

Migrations プラグインのコマンドを使う。
*app/Config/Migration/* ディレクトリにマイグレーションファイルが生成され、 *app/Config/Schema/schema.php* ファイルも更新される。
マイグレーションの状況は `schema_migrations` テーブルで管理される。

#### マイグレーション状況の確認

```
$ ./Console/cake migrations.migration status  # マイグレーション状況の確認
$ ./Console/cake migrations.migration run status  # マイグレーション状況の一覧
```

#### データベースを変更してからマイグレーションを作成する場合の作業フロー（推奨）

1. データベースのテーブルを直接変更する。
2. マイグレーションファイルを生成する。
3. 生成されたマイグレーションファイルを必要に応じて編集する。
4. マイグレーションのロールバックを確認する。
5. マイグレーションの実行を再確認する。

```
$ ./Console/cake migrations.migration generate -f	# マイグレーションファイルを生成
$ ./Console/cake migrations.migration run down	# ロールバック
$ ./Console/cake migrations.migration run up	# 実行
```

#### マイグレーションを作成してからデータベースに適用する場合の作業フロー（未検証）

```
$ ./Console/cake migrations.migration generate add_message_to_products message:text	# マイグレーションの生成（例）
$ ./Console/cake migrations.migration run up	# 実行
$ ./Console/cake schema generate -f	# スキーマファイルの更新
```

#### Tips:

- 1つのマイグレーションの中で、あるカラムの名前変更と属性変更を行う場合、alter_field、rename_fieldの順だとエラーになる。逆順でやるとうまくいく。
- データ移行は、公式ドキュメントのようなモデルクラス経由ではやらずに、直接SQLを使った方が良い。モデルクラスに変更などがあった場合、過去のマイグレーションが想定通りに動かなくなってしまう可能性があるため。

### ローカライズ

#### POTファイルの更新

```
$ ./Console/cake i18n extract --exclude=Vendor --no-location
```

*app/Locale/default.pot* ファイルが更新される。

- [I18N シェル](https://book.cakephp.org/2/ja/console-and-shells/i18n-shell.html)

#### [Poedit](https://poedit.net/) での作業

1. *app/Locale/ja_JP/LC_MESSAGES/default.po* ファイルを開く。
2. メニューの [カタログ] > [POTファイルから更新] で *app/Locale/default.pot* ファイルを指定する。
3. 必要な翻訳を行い保存する。

### リリース

*app/Config/constants.php* ファイル内の `$config['app.version']` の値を更新しておく。

#### 通常の場合

1. リリースしたいコミットから `staging` ブランチを作成して Bitbucket に push する。
2. `staging` ブランチに push されると、Bitbucket Pipelines によりビルド、アーカイブ作成、ダウンロードページへの配備が行われる。
3. Bitbucket のダウンロードページから最新のアーカイブをダウンロードしてリリース。
4. サーバ上の新しいディレクトリにアーカイブを解凍してもらい、インストール画面から実行してもらう。

ビルド、アーカイブ作成、ダウンロードページへの配備は、 *bitbucket-pipelines.yml* ファイルと Bitbucket Pipelines ページでの設定に基づいて行われる。

#### 変更ファイルのみリリースする場合

変更ファイルがごく少数で、マイグレーションやパッケージの更新も無い場合は、こちらの方法をとることが多い。

1. 変更ファイル（相対パス）の一覧を *list* ファイルに記述しておき、以下のコマンドでアーカイブを作成してリリース。
2. アーカイブに含まれるファイルで、サーバ上のファイルを上書きしてもらう。

```
$ zip payke-ec-fix-1.2.3.zip -@ < list	# アーカイブを作成
```
